#!/usr/bin/python3

import sys
import syslog
from sonic_py_common import logger

try:
    from swsscommon.swsscommon import SonicV2Connector, ConfigDBConnector
except ImportError:
    from swsssdk import SonicV2Connector, ConfigDBConnector

DEFAULT_NAMESPACE = ''

REDIS_HOSTIP = "127.0.0.1"

SYSLOG_ID = "bcm_autoneg_speed_reconfig"

def log_info(msg):
    syslog.openlog(SYSLOG_ID)
    syslog.syslog(syslog.LOG_INFO, msg)
    syslog.closelog()


def log_error(msg):
    syslog.openlog(SYSLOG_ID)
    syslog.syslog(syslog.LOG_ERR, msg)
    syslog.closelog()


def log_notice(msg):
    syslog.openlog(SYSLOG_ID)
    syslog.syslog(syslog.LOG_NOTICE, msg)
    syslog.closelog()


def get_port_oid_mapping():
    ''' Returns dictionary of all ports interfaces and their OIDs.
    Format: { <port>: <oid> }
    '''
    db = SonicV2Connector(host=REDIS_HOSTIP)
    db.connect(db.COUNTERS_DB)

    port_oid_map = db.get_all(db.COUNTERS_DB, 'COUNTERS_PORT_NAME_MAP')

    db.close(db.COUNTERS_DB)

    return port_oid_map


def main():

    asic_db = SonicV2Connector(host=REDIS_HOSTIP)
    asic_db.connect(asic_db.ASIC_DB)
    port_oid_map = get_port_oid_mapping()

    config_db = ConfigDBConnector(use_unix_socket_path=True,namespace=DEFAULT_NAMESPACE)

    config_db.connect()
    port_dict = config_db.get_table('PORT')

    for port in port_dict.keys():
        speed = port_dict[port].get('speed', None)
        if speed is None:
            log_error('no speed set in CONFIG DB, exiting with 101, port {} speed {}'.format(port, speed))
            sys.exit(101)
        autoneg_val = port_dict[port].get('autoneg', None)
        if autoneg_val is not None and str(autoneg_val) in ['1', 'on']:
            asic_db_kvp = asic_db.get_all(asic_db.ASIC_DB, 'ASIC_STATE:SAI_OBJECT_TYPE_PORT:{}'.format(port_oid_map[port]))
            if asic_db_kvp is not None:
                speed_val = asic_db_kvp.get('SAI_PORT_ATTR_SPEED', None)
                if speed_val is None:
                    log_notice('no speed set in ASIC DB, setting speed for port {} to speed {}'.format(port, speed))
                    asic_db.set(asic_db.ASIC_DB, 'ASIC_STATE:SAI_OBJECT_TYPE_PORT:{}'.format(port_oid_map[port]), 'SAI_PORT_ATTR_SPEED', speed)
            else:
                # asic_db with this OID is completely empty should not have
                log_error('no kvp found in ASIC DB for port {}, exiting with 102'.format(port))
                sys.exit(102)

    asic_db.close(asic_db.ASIC_DB)
    config_db.close(config_db.CONFIG_DB)


if __name__ == "__main__":
    main()
