#!/usr/bin/env python

import arista.platforms
from arista.core.utils import flatten

def iterComponent(parent, filtr):
   if filtr(parent):
      yield parent
   col = parent.components
   cmps = flatten(col.values()) if isinstance(col, dict) else col
   for c in cmps:
      for s in iterComponent(c, filtr):
         yield s

def clearFaults(u):
   print('Clearing faults for %s' % u)
   with u.drivers['UcdI2cDevDriver'] as drv:
      drv.clearFaults()

platform = arista.core.platform.getPlatform()
for ucd in iterComponent(platform, lambda c: isinstance(c, arista.components.dpm.Ucd)):
   clearFaults(ucd)
