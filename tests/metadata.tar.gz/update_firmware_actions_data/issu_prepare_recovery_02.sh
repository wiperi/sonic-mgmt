#!/bin/bash
#
# Copyright (c) 2024 NVIDIA CORPORATION & AFFILIATES.
# Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

# how to use:
# Note! this script suitable only for upgrade SW version from 201911 to 202205 (FW 2008 to FW 2010) using warm reboot on SPC1
# supported FW versions: 2008.2424, 2008.2508, 2008.3224, 2008.3226, 2008.3358, 2008.3382, 2008.3388 
# ./issu_prepare_recovery_02.sh &

# Initialize variables
mst_dev="/dev/mst/mt52100_pciconf0"

fw_version_major_addr_spc1="0x88024.16"
fw_version_minor_addr="0"

current_version="0"
new_version="0x000007da"   # 2010
fw_minor_2008="0x000007d8" # 2008

fw_major_current="0"
fw_major_spc1="0x0000000d" # 13 - SPC1

busy_bitmask_0_2008_addr_sp="0"

module_mng_init_2008_addr_sp="0"
phy2module_2008_addr_sp="0"
cable_info_2008_addr_sp="0"

busy_bitmask_0_2008_value="0x00000000"

function debug()
{
    if [[ x"${VERBOSE}" == x"yes" ]]; then
        echo $(date) $@
    fi
    logger "$@"
}

if [ "$(sudo mcra $mst_dev $fw_version_major_addr_spc1)" == "$fw_major_spc1" ]; then
    # echo "The ASIC is SPC1"
    fw_major_current=$(sudo mcra $mst_dev $fw_version_major_addr_spc1)
    #fw minor addr SPC1
    fw_version_minor_addr="0x88028.16"
    busy_bitmask_0_2008_addr_sp="0xae348.0"
    module_mng_init_2008_addr_sp="0xab708.0:4"
    phy2module_2008_addr_sp="0xab208.0:4"
    cable_info_2008_addr_sp="0xaba10.0:4"
else
    debug "This script suitable only for SPC1"
    exit 0
fi

current_version=$(sudo mcra $mst_dev $fw_version_minor_addr)
if [ "$current_version" == "$fw_minor_2008" ]; then
    # echo "FW version minor is 2008"
    busy_bitmask_0_2008_value=$(sudo mcra $mst_dev $busy_bitmask_0_2008_addr_sp)
    # wait until ISSU started
    while [[ $busy_bitmask_0_2008_value == "0x00000000" && "$current_version" == "$fw_minor_2008" ]];
    do
        busy_bitmask_0_2008_value=$(sudo mcra $mst_dev $busy_bitmask_0_2008_addr_sp)
        current_version=$(sudo mcra $mst_dev $fw_version_minor_addr)
    done
    # echo "busy_bitmask_0: $busy_bitmask_0_2008_value"
    #wait 7 sec
    sleep 7

    #check if the ISSU prepare finished
    busy_bitmask_0_2008_value=$(sudo mcra $mst_dev $busy_bitmask_0_2008_addr_sp)
    current_version=$(sudo mcra $mst_dev $fw_version_minor_addr)
    # echo "busy_bitmask_0: $busy_bitmask_0_2008_value"
    # echo "current version: $current_version"

    if [[ $busy_bitmask_0_2008_value == "0x00000000" || "$current_version" != "$fw_minor_2008" ]]; then
        if [[ $busy_bitmask_0_2008_value == "0x00000000" ]]; then
            debug "Warm reboot prepare done"
        fi
        if [[ "$current_version" != "$fw_minor_2008" ]]; then
            debug "Warm reboot done the current FW version is $current_version"
        fi
        exit 0
    fi
    # if ISSU prepare failed, start recovery
    sudo mcra $mst_dev $module_mng_init_2008_addr_sp 0
    sudo mcra $mst_dev $phy2module_2008_addr_sp 0
    sudo mcra $mst_dev $cable_info_2008_addr_sp 0
    sudo mcra $mst_dev $busy_bitmask_0_2008_addr_sp 0
    debug "Warm reboot prepare recovery done"
    exit 0
else
    debug "This script suitable only for SW upgrade from 201911 (FW 2008)"
    exit 0
fi
