import asyncio
from contextlib import contextmanager
import os
import re


try:
    import argparse
    import subprocess
    import sys
    import time
    import traceback
    import sonic_platform.platform
    from sonic_py_common import device_info, logger, multi_asic
    from swsscommon import swsscommon
    import sonic_platform_base.sonic_sfp.sfputilhelper
except ImportError as e:
    sys.exit(1)

SYSLOG_IDENTIFIER = "cmis_fwutil"

ERROR_IMPORT_MODULES = 1
ERROR_NON_SUDO = 2
ERROR_INVALID_COMMAND = 3
ERROR_LOAD_PLATFORM_SFPUTIL = 4
ERROR_INVALID_LPORT = 5
ERROR_LOAD_PORT_CONFIG = 6
ERROR_INVALID_NAMESPACE = 7
ERROR_INVALID_PPORT = 8
ERROR_INVALID_FIRST_LPORT_OF_PPORT = 9
ERROR_GET_SFP_INIT = 10
ERROR_CMIS_FW_UTIL_INSTANCE_CREATE = 11
ERROR_PRE_REQ_OS_CHECK = 12
ERROR_PRE_REQ_INTERFACE_CHECK = 13
ERROR_PRE_REQ_FW_PATH_CHECK = 14
ERROR_PRE_REQ_PRESENCE_CHECK = 15
ERROR_PRE_REQ_FWUPGRADE_SUPPORT = 16
ERROR_PRE_REQ_GOLD_FIRMWARE_VERSION_CHECK = 17
ERROR_DOM_DISABLE = 18
ERROR_DOM_ENABLE = 19
ERROR_CDB_COMMAND_ACCESS_CHECK = 20
ERROR_REMOTE_SIDE_FW_UPGRADE_SUPPORT_CHECK = 21
ERROR_EXISTING_FW_DOWNLOAD_DB_UPDATE = 22
ERROR_FW_DOWNLOAD_VERIFICATION = 23
ERROR_FW_DOWNLOAD = 24
ERROR_FIRMWARE_RUN = 25
ERROR_FIRMWARE_COMMIT = 26
ERROR_FW_ACTIVATE_VERIFICATION = 27
ERROR_DOM_STATUS_CHECK = 28
ERROR_ADMIN_STATUS_CHECK = 29
ERROR_SHUTDOWN_INTERFACE = 30
ERROR_SHUTDOWN_INTERFACE_VERIFICATION = 31
ERROR_EXISTING_FW_ACTIVATE_DB_UPDATE = 32
ERROR_SFPUTIL_RESET = 33
ERROR_STARTUP_INTERFACE = 34
ERROR_GET_FW_VERSION = 35
ERROR_TARGET_FW_DOWNLOAD_EXCEPTION = 36
ERROR_LOCAL_FW_DOWNLOAD_TARGET_RESTORE = 37
ERROR_TARGET_FW_ACTIVATE_EXCEPTION  = 38
ERROR_LOCAL_FW_ACTIVATE_TARGET_RESTORE = 39
ERROR_EXISTING_FW_RUN_AND_COMMIT_DB_UPDATE = 40
ERROR_CMIS_TERMINAL_STATE_VERIFICATION = 41
ERROR_INACTIVE_FW_NOT_GOLD_FW = 42
ERROR_SINGLE_BANK_CHECK = 43
ERROR_SET_OPTOE_WRITE_TIMEOUT = 44
ERROR_SET_OPTOE_WRITE_TIMEOUT_DEFAULT = 45

CMIS_FWUTIL_INVALID_COMMAND = 0
CMIS_FWUTIL_DOWNLOAD_COMMAND = 1
CMIS_FWUTIL_ACTIVATE_COMMAND = 2
CMIS_FWUTIL_GETACTIVE_FW_VERSION_COMMAND = 3
CMIS_FWUTIL_GETINACTIVE_FW_VERSION_COMMAND = 4
CMIS_FWUTIL_CDB_ACCESS_COMMANDS_SET = {CMIS_FWUTIL_DOWNLOAD_COMMAND, CMIS_FWUTIL_ACTIVATE_COMMAND}
CMIS_FWUTIL_GET_FIRWAMRE_FROM_DB_COMMANDS_SET = {CMIS_FWUTIL_GETACTIVE_FW_VERSION_COMMAND, CMIS_FWUTIL_GETINACTIVE_FW_VERSION_COMMAND}

MAX_FIRMWARE_DOWNLOAD_ATTEMPTS = 3
MAX_FIRMWARE_RUN_ATTEMPTS = 3
MAX_FIRMWARE_COMMIT_ATTEMPTS = 3
MAX_GET_FW_VERSION_ATTEMPTS = 3

DOM_CONFIG_ENABLE_WAIT_TIME = 5
I2C_WAIT_TIME_AFTER_RESET = 5
INTERFACE_LINK_DOWN_TIMEOUT = 5
INTERFACE_LINK_POLL_INTERVAL = 1
INTERFACE_CMIS_TERMINAL_STATE_WAIT_TIME = 190
INTERFACE_CMIS_TERMINAL_STATE_POLL_INTERVAL = 1

LOCAL_SIDE_FW_UPGRADE_TARGET = 0
DEFAULT_TARGET_LIST = [2, 1, LOCAL_SIDE_FW_UPGRADE_TARGET]

SINGLE_BANK_MODEL_PATTERN = [r"DEF8504-2C\d{2}-MB3"]

VENDOR_PN_TO_OPTOE_WRITE_TIMEOUT_DICT = {
    r"DEF8504-2C\d{2}-MB3": 90
}
DEFAULT_OPTOE_WRITE_TIMEOUT = 25

DEFAULT_NAMESPACE = ''

TRANSCEIVER_INFO_TABLE = 'TRANSCEIVER_INFO'
TRANSCEIVER_STATUS_TABLE = 'TRANSCEIVER_STATUS'
TRANSCEIVER_FIRMWARE_INFO_TABLE = 'TRANSCEIVER_FIRMWARE_INFO'
TARGET_ACTIVE_FIRMWARE_VERSION_STRING_DICT = {
            0: 'active_firmware',
            1: 'e1_active_firmware',
            2: 'e2_active_firmware',
        }
TARGET_INACTIVE_FIRMWARE_VERSION_STRING_DICT = {
            0: 'inactive_firmware',
            1: 'e1_inactive_firmware',
            2: 'e2_inactive_firmware',
        }

SUPPORTED_DB_LIST = ['CONFIG_DB', 'STATE_DB']

INVALID_FW_VERSION = "0.0.0"

CMIS_TERMINAL_STATES = {
                        'FAILED',
                        'READY',
                        'REMOVED'
                        }

helper_logger = logger.Logger(SYSLOG_IDENTIFIER)

def dump_command_errors_to_log_file(stdout):
    if stdout is not None:
        for line in stdout.splitlines():
            helper_logger.log_error(line)

class SonicPyAPIXcvrUtility(object):
    """
    A utility class that provides helper functions to access transceiver information using Python based APIs.
    """

    def __init__(self, lport):
        self.lport = lport
        self.namespace = DEFAULT_NAMESPACE
        self.pport = None
        self.sfp = None
        self.platform_sfputil = None

        if not self.load_sfputilhelper():
            helper_logger.log_error("Failed to load sfputil helper for {}".format(self.lport))
            sys.exit(ERROR_LOAD_PLATFORM_SFPUTIL)

        self.initialize_db_config()

        if not self.load_port_config():
            helper_logger.log_error("Failed to load port config for {}".format(self.lport))
            sys.exit(ERROR_LOAD_PORT_CONFIG)

        # Check if the logical port is valid
        if not self.platform_sfputil.is_logical_port(self.lport):
            helper_logger.log_error("Invalid logical port {}".format(self.lport))
            sys.exit(ERROR_INVALID_LPORT)

        self.namespace = self.get_namespace(self.lport)
        if self.namespace is None:
            helper_logger.log_error("Failed to get namespace for {}".format(self.lport))
            sys.exit(ERROR_INVALID_NAMESPACE)

        self.pport = self.get_pport()
        if self.pport < 0:
            helper_logger.log_error("Failed to get physical port for logical port {}".format(self.lport))
            sys.exit(ERROR_INVALID_PPORT)

        self.first_lport_of_pport = self.get_first_lport_of_pport()
        if self.first_lport_of_pport is None:
            helper_logger.log_error("Failed to get first logical port of physical port {}".format(self.pport))
            sys.exit(ERROR_INVALID_FIRST_LPORT_OF_PPORT)

        # Get platform chassis and SFP object
        try:
            self.platform_chassis = sonic_platform.platform.Platform().get_chassis()
            self.sfp = self.platform_chassis.get_sfp(self.pport)
            if self.sfp is None:
                helper_logger.log_error("Failed to get SFP object for {}".format(self.lport))
                sys.exit(ERROR_GET_SFP_INIT)
        except Exception as e:
            helper_logger.log_error("Failed to initialize sfp object with exception {} for {}".format(repr(e), self.lport))
            sys.exit(ERROR_GET_SFP_INIT)

    # Instantiate SfpUtilHelper class
    def load_sfputilhelper(self):
        self.platform_sfputil = sonic_platform_base.sonic_sfp.sfputilhelper.SfpUtilHelper()
        if not self.platform_sfputil:
            helper_logger.log_error("Failed to load SfpUtilHelper class for {}".format(self.lport))
            return False

        return True

    # Load port config
    def load_port_config(self):
        try:
            if multi_asic.is_multi_asic():
                # For multi ASIC platforms we pass DIR of port_config_file_path and the number of asics
                (_, hwsku_path) = device_info.get_paths_to_platform_and_hwsku_dirs()

                # Load platform module from source
                self.platform_sfputil.read_all_porttab_mappings(hwsku_path, multi_asic.get_num_asics())
            else:
                # For single ASIC platforms we pass port_config_file_path and the asic_inst as 0
                port_config_file_path = device_info.get_path_to_port_config_file()
                self.platform_sfputil.read_porttab_mappings(port_config_file_path, 0)
        except Exception as e:
            helper_logger.log_error("Error reading port info ({}), port {}".format(str(e), self.lport))
            return False

        return True

    def get_pport(self):
        """
        Gets the physical port corresponding to the logical port.
        Returns
            Physical port if successful
            -1 otherwise.
        """
        if self.platform_sfputil.is_logical_port(self.lport):
            pport_list = self.platform_sfputil.get_logical_to_physical(self.lport)
            if pport_list is not None and len(pport_list) == 1:
                return pport_list[0]
            else:
                helper_logger.log_error("Get pport: Invalid pport list {} for {}".format(pport_list, self.lport))
                return -1
        else:
            helper_logger.log_error("Get pport: Invalid logical port {}".format(self.lport))
            return -1

    def get_namespace(self, interface_name):
        """
        Gets the namespace of the given interface.
        @return: String representing the namespace. In case of error, None is returned.
        """
        try:
            return multi_asic.get_namespace_for_port(interface_name)
        except:
            return None

    def get_first_lport_of_pport(self):
        """
        Gets the first logical port corresponding to the physical port.
        For breakout ports, the first subport is returned.
        For non-breakout ports, the corresponding logical port itself is returned.
        Returns
            Logical port if successful
            None otherwise.
        """
        lport_list = self.platform_sfputil.get_physical_to_logical(self.pport)
        if lport_list is not None and len(lport_list) > 0:
            return lport_list[0]
        else:
            helper_logger.log_error("Get first lport of pport: Invalid lport list {} for {}".format(lport_list, self.lport))
            return None

    def initialize_db_config(self):
        if multi_asic.is_multi_asic():
            # Load the namespace details first from the database_global.json file.
            swsscommon.SonicDBConfig.initializeGlobalConfig()

    def get_transceiver_remote_side_fw_upgrade_support(self):
        """
        Checks if the module is capable of firmware upgrade on remote sides from local side itself
        Returns
            [bool, list]
            bool return values:
                None if error is encountered
                True if module is capable of remote firmware upgrade on remote sides from local side itself
                False otherwise.

            list return values:
                list of integers with each number representing the local/remote target on which firmware upgrade is supported
        """
        try:
            api = self.sfp.get_xcvr_api()
            if api is None:
                helper_logger.log_error("Transceiver remote side fw upgrade support: Unable to get XCVR API".format(self.lport))
                return None, None
            if hasattr(api, 'set_firmware_download_target_end'):
                return True, DEFAULT_TARGET_LIST
            else:
                return False, None
        except Exception as e:
            helper_logger.log_error("Transceiver remote side fw upgrade support: Failed with exception {} for port {}".format(repr(e), self.lport))
            return None, None

    def is_transceiver_present(self):
        """
        Checks if the transceiver is present
        Returns
            True if transceiver is present
            False if transceiver is not present
            None otherwise.
        """
        try:
            return self.sfp.get_presence()
        except Exception as e:
            helper_logger.log_error("Transceiver presence: Failed to get transceiver presence with exception {} for {}".format(repr(e), self.lport))
            return None

    def set_optoe_write_timeout(self, timeout):
        """
        Sets the optoe write_timeout value
        Returns True on success, False otherwise.
        """
        try:
            self.sfp.set_optoe_write_timeout(timeout)
        except Exception as e:
            helper_logger.log_error("Set optoe write timeout: Failed to set optoe "
                                    "write timeout {} with exception {} "
                                    "for {}".format(timeout, repr(e), self.lport))
            return False

        return True

    def get_firmware_versions_for_all_sides(self):
        """
        Get active and inactive firmware versions for all sides
        Returns a dictionary with firmware versions or None if an error occurs.
        """
        try:
            return self.sfp.get_transceiver_info_firmware_versions()
        except Exception as e:
            helper_logger.log_error("Get FW versions for all sides: Failed "
                                    "to get firmware version with "
                                    "exception {} for {}".format(repr(e), self.lport))
        return None

    def get_active_inactive_firmware_version_by_target(self, target=LOCAL_SIDE_FW_UPGRADE_TARGET):
        """
        Get firmware version based on target
        Returns
            Tuple of active firmware version and inactive firmware version if successful
            None otherwise.
        """
        firmware_versions_dict = self.get_firmware_versions_for_all_sides()
        if firmware_versions_dict is None:
            helper_logger.log_error("Get active inactive FW version by target {}: "
                                    "Failed to get firmware version for {}".format(target, self.lport))
            return None, None

        active_fw_key = TARGET_ACTIVE_FIRMWARE_VERSION_STRING_DICT.get(target)
        inactive_fw_key = TARGET_INACTIVE_FIRMWARE_VERSION_STRING_DICT.get(target)
        if active_fw_key in firmware_versions_dict and inactive_fw_key in firmware_versions_dict:
            return firmware_versions_dict[active_fw_key], firmware_versions_dict[inactive_fw_key]
        else:
            helper_logger.log_error("Get active inactive FW version by target {}: "
                                    "Failed to get firmware version for {}".format(target, self.lport))
            return None, None

    def get_image_bank_by_field(self, field):
        """
        Get image bank based on field
        Field can either be running or committed
        Returns
            string - image bank
            None otherwise.
        """
        if field not in ['running', 'committed']:
            helper_logger.log_error("Get image bank by field: Invalid field {}".format(field))
            return None

        try:
            api = self.sfp.get_xcvr_api()
            if api is None:
                helper_logger.log_error("Get image bank by field: Unable to get XCVR API".format(self.lport))
                return None

            info_dict = api.get_module_fw_info()
            if info_dict is None or 'info' not in info_dict:
                helper_logger.log_error("Get image bank by field: Unable to get FW info {} for {}".format(info_dict, self.lport))
                return None
            else:
                output_to_search = "Running Image:" if field == 'running' else "Committed Image:"
                for line in info_dict['info'].splitlines():
                    if output_to_search in line:
                        return line.split(':')[1].strip()
                return None
        except Exception as e:
            helper_logger.log_error("Get image bank by field: Failed to get FW info with exception {} for {}".format(repr(e), self.lport))
            return None

class SonicPyAPIAndCommandsUtility(SonicPyAPIXcvrUtility):
    """
    A utility class that provides helper functions for executing and parsing various SONiC commands.
    """

    def __init__(self, lport):
        super().__init__(lport)

    def run_command(self, command):
        """
        Runs the given command on SONiC device.
        @param command: The command to be run on the SONiC device.
        @return: A tuple of return code, stdout and stderr.
        """
        try:
            process = subprocess.Popen(command, stdout=subprocess.PIPE, stdin=subprocess.PIPE, shell=True)
            stdout, stderr = process.communicate()
        except Exception as e:
            helper_logger.log_error("run command: Found {} exception while executing".format(repr(e)))
            return [None, None, None]
        else:
            return process.returncode, stdout, stderr

    def get_os_version(self):
        """
        Gets the SONiC OS version running on the device.
        @return: String representing OS version. In case of error, None is returned.
        """
        ret_code, stdout, _ = self.run_command("sonic-cfggen -y /etc/sonic/sonic_version.yml -v build_version")
        if ret_code != 0:
            helper_logger.log_error("get os version: Failed to get OS version "\
                                    "with ret code {}".format(ret_code))
            return None

        return stdout.decode('utf-8').split('.')[0].strip()

    def wait_until(self, timeout, interval, delay, condition, *args, **kwargs):
        """
        @summary: Wait until the specified condition is True or timeout.
        @param timeout: Maximum time to wait
        @param interval: Poll interval
        @param delay: Delay time
        @param condition: A function that returns False or True
        @param *args: Extra args required by the 'condition' function.
        @param **kwargs: Extra args required by the 'condition' function.
        @return: If the condition function returns True before timeout, return True. If the condition function raises an
            exception, log the error and keep waiting and polling.
        """
        helper_logger.log_debug("Wait until %s is True, timeout is %s seconds, checking interval is %s, delay is %s seconds" %
                 (condition.__name__, timeout, interval, delay))

        if delay > 0:
            helper_logger.log_debug("Delay for %s seconds first" % delay)
            time.sleep(delay)

        start_time = time.time()
        elapsed_time = 0
        while elapsed_time < timeout:
            helper_logger.log_debug("Time elapsed: %f seconds" % elapsed_time)

            try:
                check_result = condition(*args, **kwargs)
            except Exception as e:
                exc_info = sys.exc_info()
                details = traceback.format_exception(*exc_info)
                helper_logger.log_error(
                    "Exception caught while checking {}:{}, error:{}".format(
                        condition.__name__, "".join(details), e
                    )
                )
                check_result = False

            if check_result:
                helper_logger.log_debug("%s is True, exit early with True" % condition.__name__)
                return True
            else:
                helper_logger.log_debug("%s is False, wait %d seconds and check again" % (condition.__name__, interval))
                time.sleep(interval)
                elapsed_time = time.time() - start_time

        if elapsed_time >= timeout:
            helper_logger.log_error("%s is still False after %d seconds, exit with False" % (condition.__name__, timeout))
            return False

    def get_value_from_db_by_field(self, db, key, field, lport):
        """
        Gets the value from db for the given key and field.
        Returns
            Value of field if successful
            None otherwise.
        """
        if db not in SUPPORTED_DB_LIST:
            helper_logger.log_error("Get value from db by field: Invalid db {} for {}".format(db, lport))
            return None
        ret_code, stdout, _ = self.run_command("sonic-db-cli -n '{}' {} HGET \"{}|{}\" {}".format(self.namespace, db, key, lport, field))
        if ret_code != 0:
            helper_logger.log_error("Get value from db by field: Failed to get value with ret code {} "\
                                    "from db {} for {}".format(ret_code, db, lport))
            return None

        return stdout.decode('utf-8').strip()

    def update_transceiver_firmware_info_to_state_db(self):
        """
        Updates the transceiver active and inactive firmware info to STATE_DB.
        Returns
            True if successful
            False otherwise.
        """
        fw_version_dict = self.get_firmware_versions_for_all_sides()
        if fw_version_dict is None:
            helper_logger.log_error("Update transceiver firmware info to state db: "
                                    "Failed to get firmware versions for {}".format(self.lport))
            return False

        for key, value in fw_version_dict.items():
            ret_code, _, _ = self.run_command("sonic-db-cli -n '{}' STATE_DB HSET \"{}|{}\" {} {}".format(self.namespace, TRANSCEIVER_FIRMWARE_INFO_TABLE, self.lport, key, value))
            if ret_code != 0:
                helper_logger.log_error("Update transceiver firmware info to state db: Failed to update {} "\
                                        "info for {} with ret code {}".format(key, self.lport, ret_code))
                return False

        return True

    async def is_cmis_sm_in_terminal_state(self):
        """
        Checks if the CMIS state machine is in any of the CMIS_TERMINAL_STATES
        Returns
            True if CMIS state machine is in terminal state
        """
        while True:
            cmis_state = self.get_value_from_db_by_field('STATE_DB', TRANSCEIVER_STATUS_TABLE, 'cmis_state', self.lport)
            if cmis_state is None:
                helper_logger.log_error("Is CMIS SM in terminal state: Failed to get CMIS state for {}".format(self.lport))
                return False

            helper_logger.log_notice("Is CMIS SM in terminal state: CMIS state is {} for {}".format(cmis_state, self.lport))
            if cmis_state in CMIS_TERMINAL_STATES:
                return True
            await asyncio.sleep(INTERFACE_CMIS_TERMINAL_STATE_POLL_INTERVAL)

    def is_transceiver_cmis_compliant(self):
        """
        Checks if the transceiver is CMIS compliant
        Returns
                True if transceiver is CMIS compliant
                False otherwise.
        """

        return bool(self.get_value_from_db_by_field('STATE_DB', TRANSCEIVER_INFO_TABLE, 'cmis_rev', self.lport))

    def is_transceiver_with_single_bank(self):
        """
        Checks if the transceiver has single bank
        Returns
                True if transceiver has single bank
                False otherwise.
                None if an error occurs.
        """
        model = self.get_value_from_db_by_field('STATE_DB', TRANSCEIVER_INFO_TABLE, 'model', self.lport)
        if model is None or model == "":
            helper_logger.log_error("Is transceiver with single bank: Failed to get model {} for {}".format(model, self.lport))
            return None

        for pattern in SINGLE_BANK_MODEL_PATTERN:
            if re.match(pattern, model):
                return True
        return False

    def set_port_dom_config(self, dom_enable):
        """
        Set the DOM configuration for the first logical port of the physical port.
        @param dom_enable: True to enable DOM, False to disable DOM
        @return: True on success, False otherwise.
        """
        if dom_enable:
            ret_code, _, _ = self.run_command("config interface -n \"{}\" transceiver dom {} enable".format(self.namespace, self.first_lport_of_pport))
        else:
            ret_code, _, _ = self.run_command("config interface -n \"{}\" transceiver dom {} disable".format(self.namespace, self.first_lport_of_pport))
        if ret_code != 0:
            helper_logger.log_error("Set port dom config: Invalid ret code {} received "
                                    "while setting DOM to {} for {}".format(ret_code, dom_enable, self.lport))
            return False

        return True

    def get_port_dom_config(self):
        """
        Get the DOM config for the first logical port of the physical port.
        @return: String representing the DOM status. In case of error, None is returned.
        """
        return self.get_value_from_db_by_field('CONFIG_DB', swsscommon.CFG_PORT_TABLE_NAME, 'dom_polling', self.first_lport_of_pport)

    def get_interface_oper_status(self):
        """
        Returns interface oper status as string and returns None in case of error.
        """
        ret_code, stdout, _ = self.run_command("show interfaces status {}".format(self.lport))
        if ret_code != 0:
            helper_logger.log_error("Get interface oper status: Failed to get interface oper status with "\
                                    "ret code {} for {}".format(ret_code, self.lport))
            return None

        return stdout.decode('utf-8').splitlines()[2].split()[7]

    def is_link_status_down(self):
        """
        Returns True if link status is down, False otherwise.
        """
        oper_status = self.get_interface_oper_status()
        if oper_status is None:
            helper_logger.log_error("is link status down: Failed to get interface oper status for {}".format(self.lport))
            return False

        return oper_status == "down"

    def get_interface_admin_status(self):
        """
        Returns interface admin status as string and returns None in case of error.
        """
        ret_code, stdout, _ = self.run_command("show interfaces status {}".format(self.lport))
        if ret_code != 0:
            helper_logger.log_error("Get interface admin status: Failed to get interface admin status with "\
                                    "ret code {} for {}".format(ret_code, self.lport))
            return None

        interface_admin_status = stdout.decode('utf-8').splitlines()[2].split()[8]
        if interface_admin_status == "up" or interface_admin_status == "down":
            return interface_admin_status
        else:
            helper_logger.log_error("get interface admin status: Invalid interface admin status {} received for {}".format(interface_admin_status, self.lport))
            return None

    def execute_interface_shutdown(self):
        """
        Executes interface shutdown
        Returns True on success, False otherwise.
        """
        ret_code, _, _ = self.run_command("config interface -n \"{}\" shutdown {}".format(self.namespace, self.lport))
        if ret_code != 0:
            helper_logger.log_error("execute interface shutdown: Failed to shutdown interface with "\
                                    "ret code {} for {}".format(ret_code, self.lport))
            return False

        return True

    def execute_interface_startup(self):
        """
        Executes interface startup
        Returns True on success, False otherwise.
        """
        ret_code, _, _ = self.run_command("config interface -n \"{}\" startup {}".format(self.namespace, self.lport))
        if ret_code != 0:
            helper_logger.log_error("execute interface startup: Failed to startup interface with "\
                                    "ret code {} for {}".format(ret_code, self.lport))
            return False

        return True

    def execute_sfputil_reset(self):
        """
        Executes sfputil reset
        Returns True on success, False otherwise.
        """
        ret_code, stdout, _ = self.run_command("sfputil reset {}".format(self.lport))
        if ret_code != 0:
            helper_logger.log_error("execute sfputil reset: Failed to reset interface with "\
                                    "ret code {} for {}".format(ret_code, self.lport))
            return False

        return "OK" in stdout.decode('utf-8')

    def set_firmware_target(self, target):
        """
        Sets the firmware target
        Returns True on success, False otherwise.
        """
        ret_code, stdout, _ = self.run_command("sfputil firmware target {} {}".format(self.lport, target))
        if ret_code != 0:
            helper_logger.log_error("set firmware target: Failed to set firmware target with "\
                                    "ret code {} for {}".format(ret_code, self.lport))
            return False

        return "Target Mode set to {}".format(target) in stdout.decode('utf-8')

    def firmware_download(self, fw_path, target):
        """
        Downloads firmware to the transceiver for the given target
        Also ensures that the inactive firmware version is updated after download
        Returns (bool, string)
        bool - True on success, False otherwise
        string - CLI output
        """
        _, original_inactive_fw_version = self.get_active_inactive_firmware_version_by_target(target=target)
        if original_inactive_fw_version is None:
            helper_logger.log_error("download firmware: Failed to get inactive firmware version for {}".format(self.lport))
            return False, None

        if target != LOCAL_SIDE_FW_UPGRADE_TARGET and not self.set_firmware_target(target):
            helper_logger.log_error("download firmware: Failed to set firmware target {} for {}".format(target, self.lport))
            return False, None

        ret_code, stdout, _ = self.run_command("sfputil firmware download {} \"{}\"".format(self.lport, fw_path))
        if ret_code is None:
            helper_logger.log_error("download firmware: Failed to download firmware for {}".format(self.lport))
            return False, None
        if ret_code != 0:
            helper_logger.log_error("download firmware: Non-zero ({}) ret code for interface {}".format(ret_code, self.lport))
            return False, stdout.decode('utf-8')

        # Ensure that the inactive firmware version is updated
        _, new_inactive_fw_version = self.get_active_inactive_firmware_version_by_target(target=target)
        if new_inactive_fw_version is None:
            helper_logger.log_error("download firmware: Failed to get new inactive firmware version for {}".format(self.lport))
            return False, stdout.decode('utf-8')
        elif new_inactive_fw_version == original_inactive_fw_version:
            helper_logger.log_error("download firmware: New inactive firmware version {} orig inactive firmware version {} is not updated after download for {}".format(
                                        new_inactive_fw_version, original_inactive_fw_version, self.lport))
            return False, stdout.decode('utf-8')

        return "Firmware download complete success" in stdout.decode('utf-8'), stdout.decode('utf-8')

    def firmware_run(self, target, single_bank):
        """
        Runs firmware on the transceiver so that the inactive firmware becomes active
        Also ensures that the running image bank is updated after firmware run
        If target is not LOCAL_SIDE_FW_UPGRADE_TARGET, it sets the firmware target to target before running firmware
        and restores the firmware target to LOCAL_SIDE_FW_UPGRADE_TARGET after running firmware
        Returns (bool, string)
        bool - True on success, False otherwise
        string - CLI output
        """
        if target != LOCAL_SIDE_FW_UPGRADE_TARGET and not self.set_firmware_target(target):
            helper_logger.log_error("firmware run: Failed to set firmware target {} for {}".format(target, self.lport))
            return False, None

        if not single_bank:
            original_running_image_bank = self.get_image_bank_by_field("running")
            if original_running_image_bank is None:
                helper_logger.log_error("firmware run: Failed to get running image bank for {}".format(self.lport))
                return False, None

        ret_code, stdout, _ = self.run_command("sfputil firmware run {}".format(self.lport))
        if ret_code is None:
            helper_logger.log_error("firmware run: Failed to firmware run for {}".format(self.lport))
            return False, None
        elif ret_code != 0:
            helper_logger.log_error("firmware run: Non-zero ({}) ret code for interface {}".format(ret_code, self.lport))
            return False, stdout.decode('utf-8')

        if target != LOCAL_SIDE_FW_UPGRADE_TARGET and not self.set_firmware_target(target):
            helper_logger.log_error("firmware run: Failed to set firmware target after run {} for {}".format(target, self.lport))
            return False, None

        if not single_bank:
            # Ensure that the running image bank is updated
            new_running_image_bank = self.get_image_bank_by_field("running")
            if new_running_image_bank is None:
                helper_logger.log_error("firmware run: Failed to get new running image bank for {}".format(self.lport))
                return False, stdout.decode('utf-8')
            elif new_running_image_bank == original_running_image_bank:
                helper_logger.log_error("firmware run: New running image bank {} orig image bank {} is not updated after firmware run for {}".format(
                                            new_running_image_bank, original_running_image_bank, self.lport))
                return False, stdout.decode('utf-8')

        if target != LOCAL_SIDE_FW_UPGRADE_TARGET and not self.set_firmware_target(LOCAL_SIDE_FW_UPGRADE_TARGET):
            helper_logger.log_error("firmware run: Failed to restore firmware target to 0 for {} {}".format(target, self.lport))
            return False, None

        return "Firmware run in mode=0 success" in stdout.decode('utf-8'), stdout.decode('utf-8')

    def firmware_commit(self, target, single_bank):
        """
        Commits firmware on the transceiver
        Also ensures that the committed image bank is updated after firmware commit
        Returns (bool, string)
        bool - True on success, False otherwise
        string - CLI output
        """
        if target != LOCAL_SIDE_FW_UPGRADE_TARGET and not self.set_firmware_target(target):
            helper_logger.log_error("firmware commit: Failed to set firmware target {} for {}".format(target, self.lport))
            return False, None

        if not single_bank:
            original_committed_image_bank = self.get_image_bank_by_field("committed")
            if original_committed_image_bank is None:
                helper_logger.log_error("firmware commit: Failed to get committed image bank for {}".format(self.lport))
                return False, None

        ret_code, stdout, _ = self.run_command("sfputil firmware commit {}".format(self.lport))
        if ret_code is None:
            helper_logger.log_error("firmware commit: Failed to firmware run for {}".format(self.lport))
            return False, None
        elif ret_code != 0:
            helper_logger.log_error("firmware commit: Non-zero ({}) ret code for interface {}".format(ret_code, self.lport))
            return False, stdout.decode('utf-8')

        if target != LOCAL_SIDE_FW_UPGRADE_TARGET and not self.set_firmware_target(target):
            helper_logger.log_error("firmware commit: Failed to set firmware target after commit {} for {}".format(target, self.lport))
            return False, None

        if not single_bank:
            # Ensure that the committed image bank is updated
            new_committed_image_bank = self.get_image_bank_by_field("committed")
            if new_committed_image_bank is None:
                helper_logger.log_error("firmware commit: Failed to get new committed image bank for {}".format(self.lport))
                return False, stdout.decode('utf-8')
            elif new_committed_image_bank == original_committed_image_bank:
                helper_logger.log_error("firmware commit: New committed image bank {} orig image bank {} is not updated after firmware commit for {}".format(
                                            new_committed_image_bank, original_committed_image_bank, self.lport))
                return False, stdout.decode('utf-8')

        if target != LOCAL_SIDE_FW_UPGRADE_TARGET and not self.set_firmware_target(LOCAL_SIDE_FW_UPGRADE_TARGET):
            helper_logger.log_error("firmware commit: Failed to restore firmware target to 0 for {} {}".format(target, self.lport))
            return False, None

        return "Firmware commit successful" in stdout.decode('utf-8'), stdout.decode('utf-8')

class CMISFWUtilFactory(object):
    """
    A factory class that provides the appropriate CMISFWUtilSingleTarget instance based on the given lport.
    """
    def __init__(self, lport, fw_path, gold_fw_version):
        self.lport = lport
        self.fw_path = fw_path
        self.gold_fw_version = gold_fw_version
        self.utility = SonicPyAPIAndCommandsUtility(lport)

    def _verify_non_port_related_prerequisites(self):
        """
        1. Ensure OS version supports CMIS firmware upgrade
        2. Ensure firmware is present at the path specified if download is required
        3. Ensure gold firmware version is valid

        Returns 0 on success, error code otherwise
        """
        # 1. Ensure OS version supports CMIS FW upgrade
        os_version = self.utility.get_os_version()
        if os_version is None:
            helper_logger.log_error("verify non-port prerequisites: Failed to get OS version, port {}".format(self.lport))
            return ERROR_PRE_REQ_OS_CHECK
        if os_version < "202305":
            helper_logger.log_error("verify non-port prerequisites: CMIS FW upgrade is not supported "
                                    "on {} OS version, port {}".format(os_version, self.lport))
            return ERROR_PRE_REQ_OS_CHECK

        # 2. Ensure firmware is present at the path specified if download is required
        if self.fw_path is not None and not os.path.isfile(self.fw_path):
            helper_logger.log_error("verify non-port prerequisites: Firmware {} is not present for lport {}".format(self.fw_path, self.lport))
            return ERROR_PRE_REQ_FW_PATH_CHECK

        # 3. Ensure gold firmware version is valid (FW version should be of format <major>.<minor>.<patch>)
        if self.gold_fw_version is not None and not re.match(r'^\d+\.\d+\.\d+$', self.gold_fw_version):
            helper_logger.log_error("verify non-port prerequisites: Invalid gold firmware version {} for lport {}".format(self.gold_fw_version, self.lport))
            return ERROR_PRE_REQ_GOLD_FIRMWARE_VERSION_CHECK

        helper_logger.log_notice("Verified non-port related prerequisites on OS version {} for {}".format(os_version, self.lport))
        return 0

    def _verify_port_related_prerequisites(self):
        """
        1. Ensure transceiver is present
        2. Ensure transceiver is CMIS compliant

        Returns 0 on success, error code otherwise
        """

        # 1. Ensure transceiver is present
        is_transceiver_present = self.utility.is_transceiver_present()
        if is_transceiver_present is None:
            helper_logger.log_error("verify port prerequisites: Failed to get transceiver presence for {}".format(self.lport))
            return ERROR_PRE_REQ_PRESENCE_CHECK
        if not is_transceiver_present:
            helper_logger.log_error("verify port prerequisites: Transceiver is not present for {}".format(self.lport))
            return ERROR_PRE_REQ_PRESENCE_CHECK

        # 2. Ensure transceiver is CMIS compliant
        transceiver_cmis_compliance_status = self.utility.is_transceiver_cmis_compliant()
        if not transceiver_cmis_compliance_status:
            helper_logger.log_notice("verify port prerequisites: Transceiver is not CMIS compliant for {}".format(self.lport))
            return ERROR_PRE_REQ_FWUPGRADE_SUPPORT

        helper_logger.log_notice("Verified port related prerequisites on for {}".format(self.lport))
        return 0

    def verify_prerequisites_and_create_instance(self):
        """
        Verifies the prerequisites and creates the appropriate CMISFWUtil instance based on the given lport.
        Returns [int, CMISFWUtilSingleTarget]
        int - 0 on success, error code otherwise
        CMISFWUtilSingleTarget - CMISFWUtilSingleTarget or child instance on success, None otherwise
        """

        return_value = self._verify_non_port_related_prerequisites()
        if return_value != 0:
            helper_logger.log_error("Failed to verify non-port related prerequisite for {}".format(self.lport))
            return return_value, None

        return_value = self._verify_port_related_prerequisites()
        if return_value != 0:
            helper_logger.log_error("Failed to verify port related prerequisite for {}".format(self.lport))
            return return_value, None

        is_remote_side_fw_upgrade_supported, remote_fw_upgrade_target_list = self.utility.get_transceiver_remote_side_fw_upgrade_support()
        if is_remote_side_fw_upgrade_supported is None:
            helper_logger.log_error("Failed to get remote firmware upgrade support for port {}".format(self.lport))
            return ERROR_REMOTE_SIDE_FW_UPGRADE_SUPPORT_CHECK, None

        if is_remote_side_fw_upgrade_supported:
            helper_logger.log_notice("Remote side firmware upgrade is supported for {}".format(self.lport))
            return 0, CMISFWUtilMultipleTargets(self.lport, self.fw_path, self.gold_fw_version, self.utility, remote_fw_upgrade_target_list)
        else:
            is_transceiver_with_single_bank = self.utility.is_transceiver_with_single_bank()
            helper_logger.log_notice("Single bank support is {} for {}".format(is_transceiver_with_single_bank, self.lport))
            if is_transceiver_with_single_bank is None:
                helper_logger.log_error("Failed to get single bank status for port {}".format(self.lport))
                return ERROR_SINGLE_BANK_CHECK, None
            else:
                helper_logger.log_notice("Remote side firmware upgrade is not supported for {}".format(self.lport))
                return 0, CMISFWUtilSingleTarget(self.lport, self.fw_path, self.gold_fw_version, self.utility, single_bank=is_transceiver_with_single_bank)

class CMISFWUtilSingleTarget(object):
    def __init__(self, lport, fw_path, gold_fw_version, utility, single_bank=False):
        self.lport = lport
        self.fw_path = fw_path
        self.gold_fw_version = gold_fw_version
        self.utility = utility
        self.single_bank = single_bank

    def shutdown_interface_and_verify_link_down(self):
        """
        1. Shutdown interface
        2. Verify interface oper status down

        Returns 0 on success, error code otherwise
        """
        if self.utility.execute_interface_shutdown() is False:
            helper_logger.log_error("shutdown and verify: Failed to shutdown interface {}".format(self.lport))
            return ERROR_SHUTDOWN_INTERFACE
        helper_logger.log_notice("Interface shutdown successful for {}".format(self.lport))

        if self.utility.wait_until(INTERFACE_LINK_DOWN_TIMEOUT, INTERFACE_LINK_POLL_INTERVAL, 0, self.utility.is_link_status_down) is False:
            helper_logger.log_error("shutdown and verify: Failed to verify interface oper status down for {}".format(self.lport))
            return ERROR_SHUTDOWN_INTERFACE_VERIFICATION
        helper_logger.log_notice("Interface oper status down verified for {}".format(self.lport))

        return 0

    def verify_cdb_command_access(self):
        # Dump the firmware version to ensure that the
        # CDB commands are working
        active_fw_version, inactive_fw_version = self.utility.get_active_inactive_firmware_version_by_target()
        if None in (active_fw_version, inactive_fw_version):
            helper_logger.log_error("Verify CDB access: Failed to get firmware version active FW {}, inactive FW {} "
                                    "for {}".format(active_fw_version, inactive_fw_version, self.lport))
            return ERROR_CDB_COMMAND_ACCESS_CHECK

        helper_logger.log_notice("Verify CDB access: Firmware version for local side: active FW {}, inactive FW {} for {}".format(active_fw_version, inactive_fw_version, self.lport))
        return 0

    def execute_firmware_download(self, target=LOCAL_SIDE_FW_UPGRADE_TARGET):
        """
        Download firmware to the transceiver if active firmware version is not gold firmware version
        Ensure that the inactive firmware version is gold firmware version after download
        Return 0 on success, error code otherwise
        """

        _, inactive_fw_version = self.utility.get_active_inactive_firmware_version_by_target(target=target)
        if inactive_fw_version == self.gold_fw_version:
            helper_logger.log_notice("Gold firmware version {} is already downloaded for "
                                     "target {} {}".format(self.gold_fw_version, target, self.lport))
            if not self.utility.update_transceiver_firmware_info_to_state_db():
                helper_logger.log_error("execute firmware download: Failed to update transceiver firmware info to state db for {}".format(self.lport))
                return ERROR_EXISTING_FW_DOWNLOAD_DB_UPDATE
            return 0

        for attempt_count in range(MAX_FIRMWARE_DOWNLOAD_ATTEMPTS):
            helper_logger.log_notice("Downloading firmware version {} for target {} {} "
                                     "attempt {}".format(self.gold_fw_version, target, self.lport, attempt_count))
            ret, stdout = self.utility.firmware_download(self.fw_path, target)
            if not ret:
                if attempt_count == MAX_FIRMWARE_DOWNLOAD_ATTEMPTS - 1:
                    helper_logger.log_error("Download firmware: Failed to download firmware for target {} {} "
                                            "with below failure log".format(target, self.lport))
                    dump_command_errors_to_log_file(stdout)
                    return ERROR_FW_DOWNLOAD
                else:
                    helper_logger.log_notice("Download firmware: Failed to download firmware for target {} {} "
                                             "with below failure log. Retrying download "
                                             "with attempt {}".format(target, self.lport, attempt_count))
                    dump_command_errors_to_log_file(stdout)
                    continue
            else:
                helper_logger.log_notice("Download firmware: Firmware download successful for target {} port "
                                         "{} with attempt {}".format(target, self.lport, attempt_count))
                break

        active_fw_version, inactive_fw_version = self.utility.get_active_inactive_firmware_version_by_target(target=target)
        helper_logger.log_notice("Firmware version after download: active FW {}, inactive FW {} "
                                 "target {} for {}".format(active_fw_version, inactive_fw_version, target, self.lport))
        if inactive_fw_version != self.gold_fw_version:
            helper_logger.log_error("Download firmware: Failed to verify gold FW version {} after download inactive FW version {} for target {} {}".format(
                                    self.gold_fw_version, inactive_fw_version, target, self.lport))
            return ERROR_FW_DOWNLOAD_VERIFICATION

        return 0

    def execute_firmware_run_and_commit(self, target=LOCAL_SIDE_FW_UPGRADE_TARGET):
        """
        1. Verify that active firmware version is not gold firmware version
        2. Run the firmware
        3. Commit the firmware
        4. Verify that active firmware version is gold firmware version

        Return 0 on success, error code otherwise
        """

        helper_logger.log_notice("Running and committing firmware for target {} {}".format(target, self.lport))
        # For local side, the caller should ensure that the active firmware version is not gold firmware version
        # This is ensure that the transceiver does not go through reset
        if target != LOCAL_SIDE_FW_UPGRADE_TARGET:
            active_fw_version, inactive_fw_version = self.utility.get_active_inactive_firmware_version_by_target(target=target)
            if active_fw_version == self.gold_fw_version:
                helper_logger.log_notice("fw run and commit: Gold firmware version {} is already running for "
                                         "target {} {}".format(self.gold_fw_version, target, self.lport))
                if not self.utility.update_transceiver_firmware_info_to_state_db():
                    helper_logger.log_error("fw run and commit: Failed to update transceiver firmware info to state db for {}".format(self.lport))
                    return ERROR_EXISTING_FW_RUN_AND_COMMIT_DB_UPDATE
                return 0
            elif inactive_fw_version != self.gold_fw_version:
                helper_logger.log_notice("fw run and commit: Inactive firmware version "
                                         "{} is not gold {} for target {} {}".format(
                                             inactive_fw_version, self.gold_fw_version, target, self.lport))
                return ERROR_INACTIVE_FW_NOT_GOLD_FW

        # 1. Run the firmware and ensure firmware run is successful by checking the running image bank
        for attempt_count in range(MAX_FIRMWARE_RUN_ATTEMPTS):
            ret, stdout = self.utility.firmware_run(target, self.single_bank)
            if not ret:
                if attempt_count == MAX_FIRMWARE_RUN_ATTEMPTS - 1:
                    helper_logger.log_error("fw run and commit: Failed to firmware run for target {} {} "
                                            "with below failure log".format(target, self.lport))
                    dump_command_errors_to_log_file(stdout)
                    return ERROR_FIRMWARE_RUN
                else:
                    helper_logger.log_notice("fw run and commit: Failed to firmware run for target {} {} "
                                             "with below failure log. Retrying firmware run "
                                             "with attempt {}".format(target, self.lport, attempt_count))
                    dump_command_errors_to_log_file(stdout)
                    continue
            else:
                helper_logger.log_notice("fw run and commit: Firmware run successful for "
                                         "target {} {} with attempt {}".format(target, self.lport, attempt_count))
                break

        # 2. Commit the firmware
        for attempt_count in range(MAX_FIRMWARE_COMMIT_ATTEMPTS):
            ret, stdout = self.utility.firmware_commit(target, self.single_bank)
            if not ret:
                if attempt_count == MAX_FIRMWARE_COMMIT_ATTEMPTS - 1:
                    helper_logger.log_error("fw run and commit: Failed to firmware commit for target {} {} "
                                            "with below failure log".format(target, self.lport))
                    dump_command_errors_to_log_file(stdout)
                    return ERROR_FIRMWARE_COMMIT
                else:
                    helper_logger.log_notice("fw run and commit: Failed to firmware commit for target {} {} "
                                             "with below failure log. Retrying firmware "
                                             "commit with attempt {}".format(target, self.lport, attempt_count))
                    dump_command_errors_to_log_file(stdout)
                    continue
            else:
                helper_logger.log_notice("fw run and commit: Firmware commit successful for target {} {} "
                                         "with attempt {}".format(target, self.lport, attempt_count))
                break

        # 3. Verify that active firmware version is gold firmware version
        active_fw_version, inactive_fw_version = self.utility.get_active_inactive_firmware_version_by_target(target=target)
        helper_logger.log_notice("Firmware version after run and commit: active FW {}, inactive FW {} "
                                 "for target {} {}".format(active_fw_version, inactive_fw_version,
                                                           target, self.lport))
        if active_fw_version != self.gold_fw_version:
            helper_logger.log_error("fw run and commit: Failed to verify gold FW version {} after run and commit active FW"
                                    " version {} for target {} port {}".format(
                                    self.gold_fw_version, active_fw_version, target, self.lport))
            return ERROR_FW_ACTIVATE_VERIFICATION

        return 0

    @contextmanager
    def with_set_optoe_write_timeout_if_required(self):
        """
        For certain optics, the default DEFAULT_OPTOE_WRITE_TIMEOUT write_timeout in the
        optoe kernel driver is not sufficient. Hence, set the
        write_timeout to the value based on the Vendor PN.
        Upon detecting exception, reset the write_timeout to DEFAULT_OPTOE_WRITE
        and exit with the corresponding error code
        """
        model_write_timeout = None
        try:
            model = self.utility.get_value_from_db_by_field('STATE_DB', TRANSCEIVER_INFO_TABLE, 'model', self.lport)
            if model is None or model == "":
                helper_logger.log_error("Set optoe write_timeout if required: Failed to get model {} for {}".format(model, self.lport))
                sys.exit(ERROR_SET_OPTOE_WRITE_TIMEOUT)

            for pattern, timeout in VENDOR_PN_TO_OPTOE_WRITE_TIMEOUT_DICT.items():
                if re.match(pattern, model):
                    model_write_timeout = timeout
                    helper_logger.log_notice("Set optoe write_timeout if required: Setting write_timeout {} for model {}"
                                            " for {}".format(model_write_timeout, model, self.lport))
                    break

            if model_write_timeout is not None:
                if not self.utility.set_optoe_write_timeout(model_write_timeout):
                    helper_logger.log_error("Set optoe write_timeout if required: Failed to set write_timeout {} for model {}"
                                            " for {}".format(model_write_timeout, model, self.lport))
                    sys.exit(ERROR_SET_OPTOE_WRITE_TIMEOUT)
            yield
        finally:
            if model_write_timeout is not None:
                if not self.utility.set_optoe_write_timeout(DEFAULT_OPTOE_WRITE_TIMEOUT):
                    helper_logger.log_error("Set optoe write_timeout if required: Failed to set default write_timeout for {}".format(self.lport))
                    sys.exit(ERROR_SET_OPTOE_WRITE_TIMEOUT_DEFAULT)
                else:
                    helper_logger.log_notice("Set optoe write_timeout if required: Reset write_timeout to default for {}".format(self.lport))

    @contextmanager
    def with_port_dom_disabled(self):
        """
        1. Disable DOM for port
        2. Enable DOM
        Upon detecting exception, enable the DOM and exit with the corresponding error code
        """
        try:
            # Disable DOM for port
            port_orig_dom_status = self.utility.get_port_dom_config()
            if port_orig_dom_status is None:
                helper_logger.log_error("Port DOM disabled: Failed to get port DOM status for {}".format(self.lport))
                sys.exit(ERROR_DOM_STATUS_CHECK)
            # If DOM is enabled, port_orig_dom_status can be either "enabled" or ""
            if port_orig_dom_status != "disabled":
                if not self.utility.set_port_dom_config(False):
                    helper_logger.log_error("Port DOM disabled: Failed to disable DOM for {}".format(self.lport))
                    sys.exit(ERROR_DOM_DISABLE)
                helper_logger.log_notice("Port DOM disabled: DOM disabled for {}".format(self.lport))
                time.sleep(DOM_CONFIG_ENABLE_WAIT_TIME)
            else:
                helper_logger.log_notice("Port DOM disabled: DOM is already disabled for {}".format(self.lport))
            yield
        finally:
            # Enable DOM
            if port_orig_dom_status is not None and port_orig_dom_status != "disabled":
                if not self.utility.set_port_dom_config(True):
                    helper_logger.log_error("Port DOM disabled: Failed to enable DOM for {}".format(self.lport))
                    sys.exit(ERROR_DOM_ENABLE)
                helper_logger.log_notice("Port DOM disabled: DOM enabled for {}".format(self.lport))

    @contextmanager
    def with_port_disabled_if_needed(self):
        """
        1. Shutdown interface and verify link down if not already shutdown
        2. Startup the interface if the interface was shutdown in step 1
        Upon detecting exception, startup the interface and exit with the corresponding error code
        """
        try:
            # Shutdown the interface if not already shutdown
            port_orig_admin_status = self.utility.get_interface_admin_status()
            if port_orig_admin_status is None:
                helper_logger.log_error("Port disabled if needed: Failed to get interface admin status for {}".format(self.lport))
                sys.exit(ERROR_ADMIN_STATUS_CHECK)
            if port_orig_admin_status == "up":
                return_value = self.shutdown_interface_and_verify_link_down()
                if return_value != 0:
                    helper_logger.log_error("Port disabled if needed: Failed to shutdown and verify with return "
                                            "value {} for {}".format(return_value, self.lport))
                    sys.exit(return_value)
                helper_logger.log_notice("Port disabled if needed: Interface shutdown successful for {}".format(self.lport))
            else:
                helper_logger.log_notice("Port disabled if needed: Interface is already shutdown for {}".format(self.lport))
            yield
        finally:
            # Startup the interface if the interface was shutdown in step 1
            if port_orig_admin_status == "up":
                if not self.utility.execute_interface_startup():
                    helper_logger.log_error("Port disabled if needed: Failed to startup interface {}".format(self.lport))
                    sys.exit(ERROR_STARTUP_INTERFACE)
                helper_logger.log_notice("Port disabled if needed: Interface startup successful for {}".format(self.lport))

    def execute_firmware_activate_on_local_side(self):
        """
        1. Shutdown the interface if not already shutdown
        2. If active firmware version is not same as gold firmware version, then
            2.1 Run and commit the firmware
            2.2 Reset the transceiver
            2.3 Sleep for I2C_WAIT_TIME_AFTER_RESET seconds after reset to restore I2C communication
            The steps in this section reset the datapath for all sub-ports of a breakout port. Hence, it is important to
            ensure that we execute these steps only for one sub-port of a breakout port.
            For the remaining sub-ports, we can skip the steps in this section and proceed to step 3
            so that the other sub-ports are re-initialized.
        3. Startup the interface if the interface was shutdown in step 1

        Return 0 on success, error code otherwise
        """

        helper_logger.log_notice("FW activate on local side: Firmware version {} activate in progress on for {}".format(self.gold_fw_version, self.lport))
        # Shutdown the interface if not already shutdown
        # Activate firmware on local side if active firmware version is not same as gold firmware version
        # Startup the interface if the interface was shutdown
        with self.with_port_disabled_if_needed():
            active_fw_version, inactive_fw_version = self.utility.get_active_inactive_firmware_version_by_target()
            if active_fw_version == self.gold_fw_version:
                helper_logger.log_notice("FW activate on local side: Gold firmware version {} is "
                                         "already running for {}".format(self.gold_fw_version, self.lport))
                if not self.utility.update_transceiver_firmware_info_to_state_db():
                    helper_logger.log_error("FW activate on local side: Failed to update transceiver "
                                            "firmware info to state db for {}".format(self.lport))
                    return ERROR_EXISTING_FW_ACTIVATE_DB_UPDATE
            elif inactive_fw_version != self.gold_fw_version:
                helper_logger.log_notice("FW activate on local side: Inactive firmware "
                                         "version {} is not gold {} for {}".format(
                                             inactive_fw_version, self.gold_fw_version, self.lport))
                return ERROR_INACTIVE_FW_NOT_GOLD_FW
            else:
                # 2.1 Run and commit the firmware
                return_value = self.execute_firmware_run_and_commit()
                if return_value != 0:
                    helper_logger.log_error("FW activate on local side: Failed to run and firmware commit for {}".format(self.lport))
                    return return_value

                # 2.2 Reset the transceiver
                if not self.utility.execute_sfputil_reset():
                    helper_logger.log_error("FW activate on local side: Failed to reset interface {}".format(self.lport))
                    return ERROR_SFPUTIL_RESET
                helper_logger.log_notice("FW activate on local side: sfputil reset successful for {}".format(self.lport))

                # 2.3 Sleep for I2C_WAIT_TIME_AFTER_RESET seconds after reset to restore I2C communication
                time.sleep(I2C_WAIT_TIME_AFTER_RESET)

        return 0

    async def execute_firmware_activate(self):
        return self.execute_firmware_activate_on_local_side()

    def print_firmware_version_by_type(self, type):
        """
        Print firmware version if available
        Returns a tuple (success, retry_recommended) where:
            - success is True, False otherwise.
            - retry_recommended is True if the operation failed in a way that suggests a retry might succeed, False otherwise.
        """
        fw_version = self.utility.get_value_from_db_by_field('STATE_DB', TRANSCEIVER_FIRMWARE_INFO_TABLE, type, self.lport)
        helper_logger.log_notice("Print FW version: Firmware version is {} for {}".format(fw_version, self.lport))
        if fw_version is None or fw_version == "":
            helper_logger.log_error("Print FW version: Failed to get firmware version for {}".format(self.lport))
            return False, True
        else:
            print("{}".format(fw_version))
            return True, False

class CMISFWUtilMultipleTargets(CMISFWUtilSingleTarget):
    def __init__(self, lport, fw_path, gold_fw_version, utility, remote_fw_upgrade_target_list):
        super().__init__(lport, fw_path, gold_fw_version, utility)
        self.remote_fw_upgrade_target_list = remote_fw_upgrade_target_list

    def execute_firmware_download(self):
        """
        Download firmware to the transceiver for all the targets
        Firmware download is aborted for next targets if download fails for any target
        Returns 0 on success, error code otherwise
        In case of error, ensures that the target always reverts back to LOCAL_SIDE_FW_UPGRADE_TARGET
        """
        # Ensure target always reverts back to LOCAL_SIDE_FW_UPGRADE_TARGET after downloading firmware on remote side
        helper_logger.log_notice("Firmware version {} download in progress on multiple targets for {}".format(self.gold_fw_version, self.lport))
        return_value = 0

        try:
            for target in self.remote_fw_upgrade_target_list:
                helper_logger.log_notice("Firmware version {} download in progress for target {} {}".format(self.gold_fw_version, target, self.lport))
                return_value = super().execute_firmware_download(target=target)
                if return_value != 0:
                    helper_logger.log_error("Fw download: Failed to download firmware for target {} for {}".format(target, self.lport))
                    break
        except Exception as e:
            helper_logger.log_error("Fw download: Failed to download firmware for target {} for {} "
                                    "with exception {}".format(target, self.lport, repr(e)))
            return_value = ERROR_TARGET_FW_DOWNLOAD_EXCEPTION
        finally:
            if not self.utility.set_firmware_target(LOCAL_SIDE_FW_UPGRADE_TARGET):
                helper_logger.log_error("Fw download: Failed to restore target for {}".format(self.lport))
                return_value = ERROR_LOCAL_FW_DOWNLOAD_TARGET_RESTORE

        return return_value

    async def execute_firmware_activate(self):
        """
        Activates firmware for all the targets
        Firmware activation is aborted for next targets if activation fails for any target
        Returns 0 on success, error code otherwise
        In case of error, ensures that the target always reverts back to LOCAL_SIDE_FW_UPGRADE_TARGET
        """
        # Ensure target always reverts back to LOCAL_SIDE_FW_UPGRADE_TARGET after activating firmware on remote side
        helper_logger.log_notice("Firmware version {} activate in progress on multiple targets for {}".format(self.gold_fw_version, self.lport))
        return_value = 0

        try:
            for target in self.remote_fw_upgrade_target_list:
                helper_logger.log_notice("Firmware version {} activate in progress on target {} {}".format(self.gold_fw_version, target, self.lport))
                if target == LOCAL_SIDE_FW_UPGRADE_TARGET:
                    return_value = self.execute_firmware_activate_on_local_side()
                else:
                    return_value = self.execute_firmware_run_and_commit(target=target)

                if return_value != 0:
                    helper_logger.log_error("Fw activate: Failed to activate firmware for "
                                            "target {} {}".format(target, self.lport))
                    break
        except Exception as e:
            helper_logger.log_error("Fw activate: Failed to activate firmware for target {} for {} "
                                    "with exception {}".format(target, self.lport, repr(e)))
            return_value = ERROR_TARGET_FW_ACTIVATE_EXCEPTION
        finally:
            if not self.utility.set_firmware_target(LOCAL_SIDE_FW_UPGRADE_TARGET):
                helper_logger.log_error("Fw activate: Failed to restore target for {}".format(self.lport))
                return_value = ERROR_LOCAL_FW_ACTIVATE_TARGET_RESTORE
            try:
                await asyncio.wait_for(self.utility.is_cmis_sm_in_terminal_state(), timeout=INTERFACE_CMIS_TERMINAL_STATE_WAIT_TIME)
                helper_logger.log_notice("Fw activate: Verified CMIS terminal state for {}".format(self.lport))
            except asyncio.TimeoutError:
                helper_logger.log_error("Fw activate: Failed to verify CMIS terminal state for {}".format(self.lport))
                return_value = ERROR_CMIS_TERMINAL_STATE_VERIFICATION

        return return_value

    def print_firmware_version_by_type(self, type):
        """
        Prints firmware version if all the targets have the same firmware version
        type - active_firmware or inactive_firmware
        Returns a tuple (success, retry_recommended) where:
            - success is True if all targets have the same firmware version, False otherwise.
            - retry_recommended is True if the operation failed in a way that suggests a retry might succeed, False otherwise.
        """
        firmware_versions = set()
        for target in self.remote_fw_upgrade_target_list:
            db_lookup_field = (TARGET_ACTIVE_FIRMWARE_VERSION_STRING_DICT if type == "active_firmware" 
                            else TARGET_INACTIVE_FIRMWARE_VERSION_STRING_DICT).get(target)
            if db_lookup_field is None:
                helper_logger.log_error("Print FW version: Invalid target {} for {}".format(target, self.lport))
                return False, True
            fw_version = self.utility.get_value_from_db_by_field('STATE_DB', TRANSCEIVER_FIRMWARE_INFO_TABLE,
                                                                 db_lookup_field, self.lport)
            if fw_version is None or fw_version == "":
                helper_logger.log_error("Print FW version: Failed to get firmware "
                                        "version for target {} for {}".format(target, self.lport))
                return False, True
            helper_logger.log_notice("Print FW version: Firmware version is {} "
                                     "for target {} for {}".format(fw_version, target, self.lport))
            firmware_versions.add(fw_version)

        if len(firmware_versions) == 1:
            print("{}".format(firmware_versions.pop()))
            return True, False
        else:
            helper_logger.log_error("Print FW version: Firmware versions {} are not "
                                    "same for all targets for {}".format(firmware_versions, self.lport))
            return False, False

async def main():
    parser = argparse.ArgumentParser(description='Perform CMIS FW upgrade for a transceiver')
    parser.add_argument("-p", "--port", metavar="<port_name>", help="Port name of the module", required=True)
    parser.add_argument("-g", "--gold", metavar="<gold_firmware_version>", help="Version of gold firmware", required= '-a' in sys.argv or '-d' in sys.argv)
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("-d", "--download", metavar="<firmware_binary>", help="Download a new FW")
    group.add_argument("-a", "--activate", help="Activate the inactive FW", action='store_true')
    group.add_argument("-n", "--getactivefwversion", help="Get active FW version", action='store_true')
    group.add_argument("-o", "--getinactivefwversion", help="Get inactive FW version", action='store_true')

    args = parser.parse_args()
    port = args.port
    gold_fw_version = args.gold
    fw_path = args.download
    activate_fw = False if args.activate is None else args.activate
    getactivefwversion = False if args.getactivefwversion is None else args.getactivefwversion
    getinactivefwversion = False if args.getinactivefwversion is None else args.getinactivefwversion

    # gate non sudo user
    if os.geteuid() != 0:
        helper_logger.log_error("Root privileges are required for this operation")
        sys.exit(ERROR_NON_SUDO)

    cmis_fwutil_current_command = CMIS_FWUTIL_INVALID_COMMAND
    if fw_path is not None:
        cmis_fwutil_current_command = CMIS_FWUTIL_DOWNLOAD_COMMAND
    elif activate_fw:
        cmis_fwutil_current_command = CMIS_FWUTIL_ACTIVATE_COMMAND
    elif getactivefwversion:
        cmis_fwutil_current_command = CMIS_FWUTIL_GETACTIVE_FW_VERSION_COMMAND
    elif getinactivefwversion:
        cmis_fwutil_current_command = CMIS_FWUTIL_GETINACTIVE_FW_VERSION_COMMAND
    else:
        helper_logger.log_error("Invalid command")
        sys.exit(ERROR_INVALID_COMMAND)

    try:
        return_value = 0
        cmis_fwutil_factory = CMISFWUtilFactory(port, fw_path, gold_fw_version)
        return_value, cmis_fwutil = cmis_fwutil_factory.verify_prerequisites_and_create_instance()
        if return_value != 0:
            helper_logger.log_error("Failed to create CMISFWUtil instance for {}".format(port))
    except SystemExit as e:
        return_value = e.code
    except Exception as e:
        return_value = ERROR_CMIS_FW_UTIL_INSTANCE_CREATE
        helper_logger.log_error("Failed to create CMISFWUtil instance for {} with exception {}".format(port, repr(e)))
    finally:
        if return_value != 0:
            if cmis_fwutil_current_command in CMIS_FWUTIL_GET_FIRWAMRE_FROM_DB_COMMANDS_SET:
                print("{}".format(INVALID_FW_VERSION))
            sys.exit(return_value)

    if cmis_fwutil_current_command in CMIS_FWUTIL_CDB_ACCESS_COMMANDS_SET:
        with cmis_fwutil.with_port_dom_disabled():
            with cmis_fwutil.with_set_optoe_write_timeout_if_required():
                return_value = cmis_fwutil.verify_cdb_command_access()
                if return_value != 0:
                    helper_logger.log_error("Failed to verify CDB command access for {}".format(port))
                    sys.exit(return_value)

                if cmis_fwutil_current_command == CMIS_FWUTIL_ACTIVATE_COMMAND:
                    return_value = await cmis_fwutil.execute_firmware_activate()
                    if return_value != 0:
                        helper_logger.log_error("Activate FW: Failed to activate firmware for {}".format(port))
                        sys.exit(return_value)
                    helper_logger.log_notice("Activated firmware for {}".format(port))
                else:
                    return_value = cmis_fwutil.execute_firmware_download()
                    if return_value != 0:
                        helper_logger.log_error("Download FW: Failed to download firmware with return value {} for {}".format(
                                                return_value, port))
                        sys.exit(return_value)
                    else:
                        helper_logger.log_notice("Downloaded firmware for {}".format(port))
    elif cmis_fwutil_current_command in CMIS_FWUTIL_GET_FIRWAMRE_FROM_DB_COMMANDS_SET:
        if cmis_fwutil_current_command == CMIS_FWUTIL_GETACTIVE_FW_VERSION_COMMAND:
            firmware_type = "active_firmware"
        else:
            firmware_type = "inactive_firmware"
        for attempt_count in range(MAX_GET_FW_VERSION_ATTEMPTS):
            return_status, retry_recommended = cmis_fwutil.print_firmware_version_by_type(firmware_type)
            if not return_status:
                if attempt_count == MAX_GET_FW_VERSION_ATTEMPTS - 1 or not retry_recommended:
                    helper_logger.log_error("Get FW version: Failed to get {} version for {}".format(firmware_type, port))
                    print("{}".format(INVALID_FW_VERSION))
                    sys.exit(ERROR_GET_FW_VERSION)
                else:
                    helper_logger.log_notice("Get FW version: Failed to get {} version for {} with attempt {}. "
                                            "Retrying get firmware version".format(firmware_type, port, attempt_count))
                    continue
            else:
                break

    return 0

if __name__ == '__main__':
    loop = asyncio.get_event_loop()
    ret = loop.run_until_complete(main())
    loop.close()
    sys.exit(ret)
