#!/usr/bin/python


"""
How to use this tool.

Generate Ferret instance list with region information with following Kusto search:

cluster("Netperf").database("NetPerfKustoDB").Ferret_Log
| project Cluster, Region
| distinct Cluster, Region

Copy & paste the contents into a file and remove the title line and trailing empty line.
e.g. ferret.txt


Generate region list with following Kusto query:

cluster("Azphynet").database("azphynetmds").Devices()
| where CloudType == 'Public'
| where NgsDeviceType in~ ('ToRRouter', 'LeafRouter')
| where Function !contains 'test' and Regions !in~ ('test', 'nonazure')
| project Datacenter, DeviceName, HardwareSku, DeploymentType, OSVersion, NgsDeviceType, Cluster, toint(SysUpTime), Regions, SerialNumber, Function, CloudType
| distinct Regions
| sort by Regions asc


Copy & paste the contents into a file and remvoe the title line. e.g. regions.txt


Run this tool with above 2 files:

parse_ferret.py -f ferret.txt -r regions.txt

"""

import argparse
import socket
import json

def parseFerretList(filename = None):
    ferret = {}

    with open(filename) as fp:
        line = fp.readline()
        while line:
            words   = line.strip().split('\t')

            if len(words) == 2:
                cluster = words[0]
                region  = words[1]

                if region in ferret:
                    info = ferret[region]
                else:
                    info = {}
                    ferret[region] = info

                info[cluster] = { 'url' : 'Ferret.Network-Prod-{0}.{0}.ap.gbl'.format(cluster) }


            line = fp.readline()

    return ferret, json.dumps(ferret, indent = 4)

def loadJsonFerret(filename = None):
    with open(filename) as fp:
        ferret = json.load(fp)

    return ferret, json.dumps(ferret, indent = 4)

def saveJsonFerret(filename = None, ferret = None):
    with open(filename, 'w') as fp:
        json.dump(ferret, fp, indent = 4)

def loadRegionList(filename = None):
    regions = []

    with open(filename) as fp:
        line = fp.readline().strip()
        while line:
            regions.append(line)
            line = fp.readline().strip()

    return regions

def resolveFerretIPs(ferret):
    for key1 in ferret:
        rgn = ferret[key1]
        for key2 in rgn:
            clt = rgn[key2]
            try:
                clt['addr'] = list({addr[-1][0] for addr in socket.getaddrinfo(clt['url'], 0, 0, 0, 0)})
            except:
                clt['addr'] = []

def getCommonPrefixLen(str1, str2):
    len1 = len(str1)
    len2 = len(str2)
    if len2 < len1:
        len1 = len2

    for i in range(0, len1):
        if str1[i] != str2[i]:
            return i

    return len1

def buildRegionCandidate(ferret, region):
    keys = []
    cand = {}

    if region in ferret:
        keys.append(region)

    for key in ferret:
        if key != region:
            cl = getCommonPrefixLen(key, region)
            if cl >= 2:
                if cl in cand:
                    list = cand[cl]
                else:
                    list = []
                list.append(key)
                cand[cl] = list

    for l in sorted(cand, reverse = True):
        keys.extend(cand[l])

    return keys

def getAddrList(ferret, region):
    addrs = []
    rgns  = buildRegionCandidate(ferret, region)
    for rgn in rgns:
        fr = ferret[rgn]
        for key in fr:
            addrs.extend(fr[key]['addr'])
        if len(addrs) >= 3:
            return addrs

    return addrs

def buildRegionFerretList(regions, ferret):
    cpa = {}
    for rgn in regions:
        addrs = getAddrList(ferret, rgn)
        cpa[rgn] = addrs

    return cpa

def parseArgs():
    parser = argparse.ArgumentParser()

    parser.add_argument('-f', '--ferret', help = 'Ferret list', default='', required=False)
    parser.add_argument('-j', '--jsonfr', help = 'Ferret list in JSON format', default='', required=False)
    parser.add_argument('-w', '--jsonwt', help = 'JSON output for ferret list', default='', required=False)
    parser.add_argument('-r', '--region', help = 'Region list', default='', required=False)

    return parser.parse_args()

def main():
    args = parseArgs()

    ferret  = None
    jsonfr  = None
    regions = None

    if args.jsonfr:
        ferret, jsonfr = loadJsonFerret(args.jsonfr)
    elif args.ferret:
        ferret, jsonfr = parseFerretList(args.ferret)
        resolveFerretIPs(ferret)

    if args.jsonwt:
        saveJsonFerret(args.jsonwt, ferret)

    if args.region:
        regions = loadRegionList(args.region)

    if ferret and regions:
        cpa = buildRegionFerretList(regions, ferret)
        if cpa:
            for key in cpa:
                lst = cpa[key]
                if len(lst) > 0:
                    data = '<CpaProfile Name="{}.cpa" CpaAddresses="{}" />'.format(key, ';'.join(x for x in lst))
                    print(data)


if __name__ == "__main__":
    main()
