#!/bin/bash

##################################################################
# v1.0: Guohan Lu <gulv@microsoft.com>
# v1.1: Add lockfile to avoid running two instances at the same time
##################################################################

# this script clean up orphaned l3 egress object when the total number exceed high watermark.
# it reduces the number of l3 egress object to low watermark
# it also configs the crm interval to 86400 

# Check is Lock File exists, if not create it and set trap on exit
if { set -C; 2>/dev/null >/tmp/egress_cleanup.lock; }; then
    trap "rm -f /tmp/egress_cleanup.lock" EXIT 
    set +C
else
    logger -t egrcleanup "/tmp/egress_cleanup.lock exists. Exiting..."
    exit 0
fi

highwm=30000
lowwm=25000
polling_interval=86400

if [[ $# > 1 ]]; then
    highwm=$1
    lowwm=$2
fi

# this is used to make sure we are not touch last 100 orphaned objects as there could be race condition
# that an egress object being just created but not referenced
saferegion=100

total=$(bcmcmd "l3 egress show" | wc -l)


if [ $total -gt $highwm ]; then

    tmpdir=$(mktemp -d)

    mkdir -p $tmpdir

    surplus=$((total-lowwm))

    logger -t egrcleanup "l3 egress object $total exceed high watermark $highwm, $surplus l3 egress objects to clean up to reach $lowwm"

    # vlan != 1 && vlan < 4000
    # ToCpu = no
    # Drop = no
    # Reference count = 0
    # L3MC = no

    bcmcmd "l3 egress show" | sed -e "s/\r//g" | awk '{if ($3 != 1 && $3 <= 4000 && $8 == "no" && $9 == "no" && $10==0 && $11 == "no") {print $0}}' | tail -n $((surplus+saferegion)) | head -n $surplus > $tmpdir/l3egress-delete.txt
    awk '{print $1}' $tmpdir/l3egress-delete.txt | xargs -i{} bcmcmd "l3 egress delete {}" | tee $tmpdir/l3egress-deleted.txt

    deleted_objects=$(cat $tmpdir/l3egress-delete.txt | wc -l)

    tar czf ${tmpdir}-egrcleanup.tgz $tmpdir

    logger -t egrcleanup "cleanup $deleted_objects l3 egress objects, logfile ${tmpdir}-egrcleanup.tgz"

    if [ $deleted_objects -ne $surplus ]; then
        logger -p warning -t egrcleanup "unable to find enough $((surplus-deleted_objects)) leaked egress objects to cleanup"
    fi

    echo "cleanup $deleted_objects egress objects"

    rm -rf $tmpdir

else

    logger -t egrcleanup "found $total l3 egress object not exceed high watermark, skip clean up"

fi

crm_polling_interval=$(redis-cli -n 4 HGET 'CRM|Config' polling_interval) 

if [ $crm_polling_interval != $polling_interval ]; then
    crm config polling interval $polling_interval
fi
