#!/bin/bash
#
# usage:
# link_prober_interval_update:
# Update the link_prober interval value in CONFIG_DB. 
# For OAI clusters only.

# Overload `logger` command to include link_prober_interval_update tag
logger () {
    command logger -i "$$" -t "link_prober_interval_update" "$@"
}

# Retrieve the cluster name of the device
DEVICE_CLUSTER_NAME=$(sonic-db-cli CONFIG_DB hget 'DEVICE_METADATA|localhost' 'cluster')
DEVICE_CLUSTER_NAME=$(echo "$DEVICE_CLUSTER_NAME" | tr '[:upper:]' '[:lower:]')

# List of OAI clusters
OAI_CLUSTERS=("phx11prdgpc01" "phx11prdgpc02" "phx11prdgpc06" "phx11prdgpc07" "phx27prdgpc01" "phx27prdgpc02" "phx27prdgpc03" "phx27prdgpc04" "phx61prdgpc01" "phx61prdgpc02")

# logger "device cluster name: '${DEVICE_CLUSTER_NAME}'"
# logger "OAI clusters: '${OAI_CLUSTERS[@]}'"

# Check if the retrieved value is in the list of OAI clusters
if [[ " ${OAI_CLUSTERS[@]} " =~ " ${DEVICE_CLUSTER_NAME} " ]]; then
    logger "device is in one of the OAI cluster: '${DEVICE_CLUSTER_NAME}', reset link_prober interval to 3000ms."
    sonic-db-cli CONFIG_DB hset "MUX_LINKMGR|LINK_PROBER" "interval_v4" "3000"
    sudo config save -y &>/dev/null
fi