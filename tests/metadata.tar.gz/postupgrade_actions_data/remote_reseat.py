from contextlib import contextmanager
import os


try:
    import argparse
    import subprocess
    import asyncio
    import sys
    import time
    import traceback
    from sonic_py_common import device_info, logger, multi_asic
    from utilities_common import cli
except ImportError as e:
    sys.exit(1)

SYSLOG_IDENTIFIER = "remote_reseat"

ERROR_IMPORT_MODULES = 1
ERROR_NON_SUDO = 2
ERROR_PRE_REQ_OS_CHECK = 3
ERROR_PRE_REQ_INTERFACE_CHECK = 4
ERROR_PRE_REQ_ADMIN_STATUS_CHECK = 5
ERROR_PRE_REQ_PRESENCE_CHECK = 6
ERROR_PRE_REQ_RRESEAT_SUPPORT = 7
ERROR_PREREQUISITE_VERIFICATION = 8
ERROR_SHUTDOWN_INTERFACE = 9
ERROR_SHUTDOWN_INTERFACE_VERIFICATION = 10
ERROR_SFPUTIL_RESET = 11
ERROR_LPMODE_TOGGLE_REQUIRED = 12
ERROR_SFPUTIL_LPMODE = 13
ERROR_SFPUTIL_LPMODE_VERIFICATION = 14
ERROR_STARTUP_INTERFACE = 15
ERROR_INTERFACE_OPER_STATUS_UP = 16
ERROR_EXECUTE_REMOTE_RESEAT_EXCEPTION = 17
ERROR_PRE_REQ_NAMESPACE_CHECK = 18
ERROR_PRE_REQ_INTERFACE_CHECK_FOR_CHASSIS = 19
PRE_REQ_UNSUPPORTED_TRANSCEIVER = 20

I2C_WAIT_TIME_AFTER_RESET = 5
LPMODE_SET_WAIT_TIME = 3
INTERFACE_LINK_DOWN_TIMEOUT = 5
INTERFACE_LINK_UP_TIMEOUT = 150
INTERFACE_LINK_POLL_INTERVAL = 1
MAX_REMOTE_RESEAT_RETRIES = 1

DEFAULT_NAMESPACE = ''

helper_logger = logger.Logger(SYSLOG_IDENTIFIER)

class SonicUtility(object):
    """
    A utility class that provides helper functions for executing and parsing various SONiC commands.
    """

    def run_command(self, command):
        """
        Runs the given command on SONiC device.
        @param command: The command to be run on the SONiC device.
        @return: A tuple of return code, stdout and stderr.
        """
        try:
            process = subprocess.Popen(command, stdout=subprocess.PIPE, stdin=subprocess.PIPE, shell=True)
            stdout, stderr = process.communicate()
        except Exception as e:
            helper_logger.log_error("run command: Found {} exception while executing".format(repr(e)))
            return [None, None, None]
        else:
            return process.returncode, stdout, stderr

    def get_os_version(self):
        """
        Gets the SONiC OS version running on the device.
        @return: String representing OS version. In case of error, None is returned.
        """
        ret_code, stdout, _ = self.run_command("sonic-cfggen -y /etc/sonic/sonic_version.yml -v build_version")
        if ret_code is None:
            helper_logger.log_error("get os version: Failed to get OS version")
            return None
        if ret_code != 0:
            helper_logger.log_error("get os version: Non-zero ({}) ret code received".format(ret_code))
            return None
        else:
           return stdout.decode('utf-8').split('.')[0].strip()

    def get_namespace(self, interface_name):
        """
        Gets the namespace of the given interface.
        @return: String representing the namespace. In case of error, None is returned.
        """
        try:
            return multi_asic.get_namespace_for_port(interface_name)
        except:
            return None

    def is_interface_valid(self, interface_name):
        """
        Checks if the given interface is valid.
        @return True if interface exists, False otherwise.
        """
        ret_code, stdout, _ = self.run_command("show interfaces status {}".format(interface_name))
        if ret_code is None:
            helper_logger.log_error("is interface valid: Failed to get interface status for {}".format(interface_name))
            return False
        if ret_code != 0:
            helper_logger.log_error("is interface valid: Non-zero ({}) ret code received for {}".format(ret_code, interface_name))
            return False
        else:
            return len(stdout.decode('utf-8').splitlines()) == 3

    def wait_until(self, timeout, interval, delay, condition, *args, **kwargs):
        """
        @summary: Wait until the specified condition is True or timeout.
        @param timeout: Maximum time to wait
        @param interval: Poll interval
        @param delay: Delay time
        @param condition: A function that returns False or True
        @param *args: Extra args required by the 'condition' function.
        @param **kwargs: Extra args required by the 'condition' function.
        @return: If the condition function returns True before timeout, return True. If the condition function raises an
            exception, log the error and keep waiting and polling.
        """
        helper_logger.log_debug("Wait until %s is True, timeout is %s seconds, checking interval is %s, delay is %s seconds" %
                 (condition.__name__, timeout, interval, delay))

        if delay > 0:
            helper_logger.log_debug("Delay for %s seconds first" % delay)
            time.sleep(delay)

        start_time = time.time()
        elapsed_time = 0
        while elapsed_time < timeout:
            helper_logger.log_debug("Time elapsed: %f seconds" % elapsed_time)

            try:
                check_result = condition(*args, **kwargs)
            except Exception as e:
                exc_info = sys.exc_info()
                details = traceback.format_exception(*exc_info)
                helper_logger.log_error(
                    "Exception caught while checking {}:{}, error:{}".format(
                        condition.__name__, "".join(details), e
                    )
                )
                check_result = False

            if check_result:
                helper_logger.log_debug("%s is True, exit early with True" % condition.__name__)
                return True
            else:
                helper_logger.log_debug("%s is False, wait %d seconds and check again" % (condition.__name__, interval))
                time.sleep(interval)
                elapsed_time = time.time() - start_time

        if elapsed_time >= timeout:
            helper_logger.log_error("%s is still False after %d seconds, exit with False" % (condition.__name__, timeout))
            return False

    def get_interface_oper_status(self, interface_name):
        """
        Returns interface oper status as string and returns None in case of error.
        """
        ret_code, stdout, _ = self.run_command("show interfaces status {}".format(interface_name))
        if ret_code is None:
            helper_logger.log_error("get interface oper status: Failed to get interface oper status for {}".format(interface_name))
            return None

        if ret_code != 0:
            helper_logger.log_error("get interface oper status: Non-zero ({}) ret code received for {}".format(ret_code, interface_name))
            return None
        else:
            return stdout.decode('utf-8').splitlines()[2].split()[7]

    def get_interface_admin_status(self, interface_name):
        """
        Returns interface admin status as string and returns None in case of error.
        """
        ret_code, stdout, _ = self.run_command("show interfaces status {}".format(interface_name))
        if ret_code is None:
            helper_logger.log_error("get interface admin status: Failed to get interface admin status for {}".format(interface_name))
            return None

        if ret_code != 0:
            helper_logger.log_error("get interface admin status: Non-zero ({}) ret code received for {}".format(ret_code, interface_name))
            return None
        else:
            return stdout.decode('utf-8').splitlines()[2].split()[8]

    def is_admin_status_down(self, interface_name):
        """
        Returns True if admin status is down, False otherwise.
        """
        admin_status = self.get_interface_admin_status(interface_name)
        if admin_status is None:
            helper_logger.log_error("is link status down: Failed to get interface admin_status for {}".format(interface_name))
            return False

        return admin_status == "down"

    def is_link_status_down(self, interface_name):
        """
        Returns True if link status is down, False otherwise.
        """
        oper_status = self.get_interface_oper_status(interface_name)
        if oper_status is None:
            helper_logger.log_error("is link status down: Failed to get interface oper status for {}".format(interface_name))
            return False

        return oper_status == "down"

    async def is_link_status_up(self, interface_name):
        """
        Returns True if link status is up, False otherwise.
        """
        while True:
            oper_status = self.get_interface_oper_status(interface_name)
            if oper_status is None:
                helper_logger.log_error("is link status up: Failed to get interface oper status for {}".format(interface_name))
                return False
            if oper_status == "up":
                return True
            await asyncio.sleep(INTERFACE_LINK_POLL_INTERVAL)

    def execute_interface_shutdown(self, interface_name, namespace):
        """
        Executes interface shutdown
        Returns True on success, False otherwise.
        """
        namespace_string = "-n {}".format(namespace) if namespace else ""
        ret_code, _, _ = self.run_command("config interface {} shutdown {}".format(namespace_string, interface_name))
        if ret_code is None:
            helper_logger.log_error("execute interface shutdown: Failed to shutdown interface {}".format(interface_name))
            return False
        if ret_code != 0:
            helper_logger.log_error("execute interface shutdown: Non-zero ({}) ret code for interface {}".format(ret_code, interface_name))
            return False

        return True

    def execute_interface_startup(self, interface_name, namespace):
        """
        Executes interface startup
        Returns True on success, False otherwise.
        """
        namespace_string = "-n {}".format(namespace) if namespace else ""
        ret_code, _, _ = self.run_command("config interface {} startup {}".format(namespace_string, interface_name))
        if ret_code is None:
            helper_logger.log_error("execute interface startup: Failed to startup interface {}".format(interface_name))
            return False
        if ret_code != 0:
            helper_logger.log_error("execute interface startup: Non-zero ({}) ret code for interface {}".format(ret_code, interface_name))
            return False

        return True

    def execute_sfputil_reset(self, interface_name):
        """
        Executes sfputil reset
        Returns True on success, False otherwise.
        """
        ret_code, stdout, _ = self.run_command("sfputil reset {}".format(interface_name))
        if ret_code is None:
            helper_logger.log_error("execute sfputil reset: Failed to reset interface {}".format(interface_name))
            return False
        if ret_code != 0:
            helper_logger.log_error("execute sfputil reset: Non-zero ({}) ret code for interface {}".format(ret_code, interface_name))
            return False

        return "OK" in stdout.decode('utf-8')

    def is_transceiver_present(self, interface_name):
        """
        Checks if the transceiver is present
        Returns
            True if transceiver is present
            False if transceiver is not present
            None otherwise.
        """
        ret_code, stdout, _ = self.run_command("sfputil show presence -p {} ".format(interface_name))
        if ret_code is None:
            helper_logger.log_error("is transceiver present: Failed to execute CLI for {}".format(interface_name))
            return None

        if ret_code != 0:
            helper_logger.log_error("is transceiver present: Non-zero ({}) ret code for interface {}".format(ret_code, interface_name))
            return None
        elif len(stdout.decode('utf-8').splitlines()) != 3:
            helper_logger.log_error("is transceiver present: Invalid output {} for {}".format(
                                        stdout.decode('utf-8').splitlines(), interface_name))
            return None
        else:
            return stdout.decode('utf-8').splitlines()[2].split()[1] == "Present"

    def get_transceiver_remote_reseat_support(self, interface_name):
        """
        Checks if the transceiver is of SFP type
        Returns
            True if transceiver is of SFP type
            None if error is encountered while getting transceiver EEPROM
            False otherwise.
        """
        ret_code, stdout, _ = self.run_command("sfputil show eeprom -p {}".format(interface_name))
        if ret_code is None:
            helper_logger.log_error("Transceiver remote reseat support: Failed to get transceiver eeprom for {}".format(interface_name))
            return None

        if ret_code != 0:
            helper_logger.log_error("Transceiver remote reseat support: Non-zero ({}) ret code for interface {}".format(ret_code, interface_name))
            return None

        eeprom_data = stdout.decode('utf-8').splitlines()
        if len(eeprom_data) < 2:
            helper_logger.log_error("lpmode toggle required: Invalid transceiver eeprom data {} for {}".format(
                                                                                eeprom_data, interface_name))
            return None

        for line in eeprom_data:
            if "SFP/SFP+/SFP28" in line:
                helper_logger.log_error("Transceiver remote reseat support: Transceiver is SFP/SFP+/SFP28 for {}".format(interface_name))
                return False

        return True

    def is_lpmode_toggle_required(self, interface_name):
        """
        Checks if lpmode toggle required for a transceiver
        Returns
                None if error is encountered while getting transceiver EEPROM
                False if
                    if transceiver is CMIS compliant or
                    error is encountered
                True otherwise.
        """
        ret_code, stdout, _ = self.run_command("sfputil show eeprom -p {}".format(interface_name))
        if ret_code is None:
            helper_logger.log_error("lpmode toggle required: Failed to get transceiver eeprom for {}".format(interface_name))
            return None

        if ret_code != 0:
            helper_logger.log_error("lpmode toggle required: Non-zero ({}) ret code for interface {}".format(ret_code, interface_name))
            return None

        eeprom_data = stdout.decode('utf-8').splitlines()
        if len(eeprom_data) < 2:
            helper_logger.log_error("lpmode toggle required: Invalid transceiver eeprom data {} for {}".format(
                                                                                eeprom_data, interface_name))
            return None

        for line in eeprom_data:
            if "CMIS" in line:
                return False
            if "Power Class 1 Module" in line:
                return False

        return True

    def execute_sfputil_lpmode(self, interface_name, enable):
        """
        Puts transceiver in low/high power mode
        @interface_name: Interface name
        @param enable: True to enable low power mode, False to disable low power mode (enable high power mode)
        @return True on success, False otherwise.
        """
        if enable:
            enable_str = "on"
        else:
            enable_str = "off"

        ret_code, stdout, _ = self.run_command("sfputil lpmode {} {}".format(enable_str, interface_name))
        if ret_code is None:
            helper_logger.log_error("execute sfputil lpmode: ret_code is none with enable {} for {}".format(enable_str, interface_name))
            return False
        if ret_code != 0:
            helper_logger.log_error("execute sfputil lpmode: Non-zero ({}) ret code for interface {}".format(ret_code, interface_name))
            return False
        if "OK" in stdout.decode('utf-8'):
            return True
        else:
            helper_logger.log_error("execute sfputil lpmode: Failed to change power mode with enable {} stdout {} for {}".format(
                                                                            enable_str, stdout.decode('utf-8'), interface_name))
            return False

    def get_transceiver_lpmode_status(self, interface_name):
        """
        Gets transceiver low power mode status
        Returns "on" if low power mode is enabled, "off" if low power mode is disabled, None in case of error.
        """
        ret_code, stdout, _ = self.run_command("sfputil show lpmode -p {}".format(interface_name))
        if ret_code is None:
            helper_logger.log_error("get transceiver lpmode status: ret_code is none for {}".format(interface_name))
            return None
        if ret_code != 0:
            helper_logger.log_error("get transceiver lpmode status: Non-zero ({}) ret code for interface {}".format(ret_code, interface_name))
            return None
        return stdout.decode('utf-8').splitlines()[2].split()[1]

class RemoteReseat(object):
    def __init__(self, port, link_up_verification_disabled):
        self.os_version = None
        self.port = port
        self.namespace = DEFAULT_NAMESPACE
        self.utility = SonicUtility()
        self.link_up_verification_disabled = link_up_verification_disabled
        try:
            self.verify_prerequisites_result = self.verify_prerequisites()
        except Exception as e:
            helper_logger.log_error("Failed to verify prerequisites with exception {}".format(repr(e)))
            self.verify_prerequisites_result = ERROR_PREREQUISITE_VERIFICATION

    def verify_prerequisites(self):
        """
        1. Ensure OS version supports remote reseat
        2. Ensure that the port is valid
        3. Ensure port is not shutdown ('admin' status is not down)
        4. Ensure transceiver is present
        5. Ensure transceiver supports remote reseat
        Returns 0 on success, error code otherwise.
        """
        
        # 1. Ensure OS version supports remote reseat
        self.os_version = self.utility.get_os_version()
        if self.os_version is None:
            helper_logger.log_error("verify prerequisites: Failed to get OS version, port {}".format(self.port))
            return ERROR_PRE_REQ_OS_CHECK
        if self.os_version < "202012":
            helper_logger.log_error("verify prerequisites: Remote reseat is not supported "
                                    "on {} OS version, port {}".format(self.os_version, self.port))
            return ERROR_PRE_REQ_OS_CHECK

        # 2. Verify if the port is valid
        if not self.utility.is_interface_valid(self.port):
            helper_logger.log_error("verify prerequisites: Port {} is not valid on"
                                    " OS Version {}".format(self.port, self.os_version))
            if device_info.is_chassis():
                return ERROR_PRE_REQ_INTERFACE_CHECK_FOR_CHASSIS
            else:
                return ERROR_PRE_REQ_INTERFACE_CHECK

        # 3. Get the namespace of the port
        self.namespace = self.utility.get_namespace(self.port)
        if self.namespace is None:
            helper_logger.log_error("verify prerequisites: Failed to get namespace for {}".format(self.port))
            return ERROR_PRE_REQ_NAMESPACE_CHECK
        helper_logger.log_notice("Namespace for port {} is \'{}\'".format(self.port, self.namespace))

        # 4. Ensure port is not shutdown ('admin' status is not down)
        is_port_admin_status_down = self.utility.is_admin_status_down(self.port)
        if is_port_admin_status_down is None:
            helper_logger.log_error("verify prerequisites:is_port_admin_status_down is None for {}".format(self.port))
            return ERROR_PRE_REQ_ADMIN_STATUS_CHECK
        elif is_port_admin_status_down:
            helper_logger.log_error("verify prerequisites: Interface {} is shutdown already!".format(self.port))
            return ERROR_PRE_REQ_ADMIN_STATUS_CHECK

        # 5. Ensure transceiver is present
        is_transceiver_present = self.utility.is_transceiver_present(self.port)
        if is_transceiver_present is None:
            helper_logger.log_error("verify prerequisites: Failed to get transceiver presence for {}".format(self.port))
            return ERROR_PRE_REQ_PRESENCE_CHECK
        if not is_transceiver_present:
            helper_logger.log_error("verify prerequisites: Transceiver is not present for port {}".format(self.port))
            return ERROR_PRE_REQ_PRESENCE_CHECK

        # 6. Ensure transceiver supports remote reseat
        transceiver_remote_reseat_supported = self.utility.get_transceiver_remote_reseat_support(self.port)
        if transceiver_remote_reseat_supported is None:
            helper_logger.log_error("verify prerequisites: Failed to get transceiver eeprom for {}".format(self.port))
            return ERROR_PRE_REQ_RRESEAT_SUPPORT
        if not transceiver_remote_reseat_supported:
            helper_logger.log_notice("verify prerequisites: Transceiver is of SFP type for port {}".format(self.port))
            return PRE_REQ_UNSUPPORTED_TRANSCEIVER
        helper_logger.log_notice("Verified prerequisites on OS version {} for port {}".format(self.os_version, self.port))

        return 0

    def shutdown_interface_and_verify_link_down(self):
        """
        1. Shutdown interface
        2. Verify interface oper status down
        Upon failure, exit with error code
        """
        if not self.utility.execute_interface_shutdown(self.port, self.namespace):
            helper_logger.log_error("shutdown and verify: Failed to shutdown interface {}".format(self.port))
            sys.exit(ERROR_SHUTDOWN_INTERFACE)
        helper_logger.log_notice("Interface shutdown successful for port {}".format(self.port))

        if not self.utility.wait_until(INTERFACE_LINK_DOWN_TIMEOUT, INTERFACE_LINK_POLL_INTERVAL, 0, self.utility.is_link_status_down, self.port):
            helper_logger.log_error("shutdown and verify: Failed to verify interface oper status down for {}".format(self.port))
            sys.exit(ERROR_SHUTDOWN_INTERFACE)
        helper_logger.log_notice("Interface oper status down verified for port {}".format(self.port))

    def set_and_verify_lpmode(self, enable):
        """
        1. Set transceiver to low/high power mode
        2. sleep for LPMODE_SET_WAIT_TIME
        3. Verify transceiver is in low/high power mode
        @params enable - True to enable low power mode, False to disable low power mode (enable high power mode)
        Upon failure, exit with error code
        """
        if not self.utility.execute_sfputil_lpmode(self.port, enable):
            helper_logger.log_error("set and verify lpmode: Failed to change transceiver low power "
                                    "mode with enable {} for {}".format(enable, self.port))
            sys.exit(ERROR_SFPUTIL_LPMODE)
        time.sleep(LPMODE_SET_WAIT_TIME)

        lpmode_status = self.utility.get_transceiver_lpmode_status(self.port)
        if lpmode_status is None:
            helper_logger.log_error("set and verify lpmode: Failed to get low power mode status "
                                    "after setting with enable {} for {}".format(enable, self.port))
            sys.exit(ERROR_SFPUTIL_LPMODE_VERIFICATION)

        if enable and lpmode_status != "On":
            helper_logger.log_error("set and verify lpmode: Transceiver is not in low power mode for {}".format(self.port))
            sys.exit(ERROR_SFPUTIL_LPMODE_VERIFICATION)
        elif not enable and lpmode_status != "Off":
            helper_logger.log_error("set and verify lpmode: Transceiver is not in high power mode for {}".format(self.port))
            sys.exit(ERROR_SFPUTIL_LPMODE_VERIFICATION)

        helper_logger.log_notice("Transceiver is in {} power mode now for port {}".format("low" if enable else "high", self.port))

    @contextmanager
    def with_transceiver_in_low_power_mode(self):
        """
        1. Put the transceiver in low power mode
        2. Restore the transceiver to high power mode
        Upon detecting exception, restore the transceiver to high power mode and exit with the corresponding error code
        """
        try:
            # Put transceiver in low power mode
            self.set_and_verify_lpmode(True)
            yield
        finally:
            # Restore transceiver to high power mode
            self.set_and_verify_lpmode(False)

    @contextmanager
    def with_port_disabled(self):
        """
        1. Shutdown interface and verify link down
        2. Startup the interface
        Upon detecting exception, startup the interface and exit with the corresponding error code
        """
        try:
            self.shutdown_interface_and_verify_link_down()
            yield
        finally:
            # Startup the interface
            if not self.utility.execute_interface_startup(self.port, self.namespace):
                helper_logger.log_error("execute remote reseat: Failed to startup interface {}".format(self.port))
                sys.exit(ERROR_STARTUP_INTERFACE)
            else:
                helper_logger.log_notice("Interface startup successful for port {}".format(self.port))

    async def execute_remote_reseat_procedure(self):
        """
        1. Shutdown interface and verify link down
        2. Reset the transceiver
        2.5 Sleep for I2C_WAIT_TIME_AFTER_RESET seconds after reset to restore I2C communication
        3. If lpmode toggle is required, force transceiver to low power mode and ensure it is in low power mode
        4. If lpmode toggle is required, force transceiver to high power mode and ensure it is in high power mode
        5. Startup interface
        6. Verify if the link is up within 60 seconds
        """

        with self.with_port_disabled():
            if not self.utility.execute_sfputil_reset(self.port):
                helper_logger.log_error("execute remote reseat: Failed to reset interface {}".format(self.port))
                sys.exit(ERROR_SFPUTIL_RESET)
            helper_logger.log_notice("sfputil reset successful for port {}".format(self.port))

            # 2.5 Sleep for I2C_WAIT_TIME_AFTER_RESET seconds after reset to restore I2C communication
            await asyncio.sleep(I2C_WAIT_TIME_AFTER_RESET)

            # If lpmode toggle is required, force transceiver to low power mode followed by forcing it to high power mode
            is_lpmode_toggle_required = self.utility.is_lpmode_toggle_required(self.port)
            helper_logger.log_notice("is_lpmode_toggle_required: {} for port {}".format(is_lpmode_toggle_required, self.port))
            if is_lpmode_toggle_required is None:
                helper_logger.log_error("execute remote reseat: Failed to get lpmode toggle requirement for {}".format(self.port))
                sys.exit(ERROR_LPMODE_TOGGLE_REQUIRED)

            if is_lpmode_toggle_required:
                # 3. If lpmode toggle is required, force transceiver to low power mode and ensure it is in low power mode
                # 4. If lpmode toggle is required, force transceiver to high power mode and ensure it is in high power mode
                with self.with_transceiver_in_low_power_mode():
                    pass

        # 6. Verify if the link is up if link_up_verification_disabled is False
        if not self.link_up_verification_disabled:
            try:
                await asyncio.wait_for(self.utility.is_link_status_up(self.port), timeout=INTERFACE_LINK_UP_TIMEOUT)
                helper_logger.log_notice("Interface oper status up verified for port {}".format(self.port))
            except asyncio.TimeoutError:
                    helper_logger.log_error("execute remote reseat: Failed to verify interface oper status up after "
                                            "timeout {}s for {}".format(INTERFACE_LINK_UP_TIMEOUT, self.port))
                    sys.exit(ERROR_INTERFACE_OPER_STATUS_UP)
        else:
            helper_logger.log_notice("Link up verification is disabled for port {}".format(self.port))

        return 0

    async def execute_remote_reseat_procedure_with_retry(self, max_retry_count):
        for retry_count in range(max_retry_count):
            helper_logger.log_notice("Attempting {}/{} to remote reseat for port {}".format(
                retry_count + 1, max_retry_count, self.port))
            try:
                result = await self.execute_remote_reseat_procedure()
            except SystemExit as e:
                result = e.code
            except Exception as e:
                helper_logger.log_error("Failed to execute remote reseat with exception {}".format(repr(e)))
                result = ERROR_EXECUTE_REMOTE_RESEAT_EXCEPTION

            if result == 0:
                helper_logger.log_notice("Attempt {}/{} remote reseat successful for port {}".format(
                    retry_count + 1, max_retry_count, self.port))
                return 0
            helper_logger.log_error("Attempt {}/{} remote reseat failed with error code {} for port {}".format(
                retry_count + 1, max_retry_count, result, self.port))

        helper_logger.log_error("Failed to execute remote reseat after all {} retries "
                                "exhausted for port {}".format(max_retry_count, self.port))
        return result

async def main():
    parser = argparse.ArgumentParser(description='Perform remote reseat of a transceiver')
    parser.add_argument("-p", "--ports", nargs='+', required=True, help="Port list of the modules")
    parser.add_argument("-d", "--disable", help="Disable port link up verification after reseat", action="store_true", default=False)
    parser.add_argument("-r", "--retry", type=int, default=MAX_REMOTE_RESEAT_RETRIES,
                        help="Number of retries for remote reseat")

    args = parser.parse_args()
    ports = args.ports
    max_retry_count = args.retry
    link_up_verification_disabled = args.disable

    # gate non sudo user
    if os.geteuid() != 0:
        helper_logger.log_error("Root privileges are required for this operation")
        sys.exit(ERROR_NON_SUDO)

    # Convert to SONiC Name if alias is present. Remove dependency on Hw-proxy to do this conversion
    # if sonic name or alais_name  is passed for which mapping  does not exit it return same and interface check will fail.
    iface_alias_converter = cli.InterfaceAliasConverter()
    port_list = []

    for port in ports:
        sonic_port = iface_alias_converter.alias_to_name(port)
        #To Handle special case where for device where alias is Ethernet1/1 in NGS
        # Netassist still call with ethernet1/1. This is to temp fix until Netassist fix 
        # properly.
        if sonic_port == port and port.startswith("ethernet"):
            sonic_port = iface_alias_converter.alias_to_name(port[0].upper() + port[1:])
        port_list.append(sonic_port)

    remote_reseats = [RemoteReseat(port, link_up_verification_disabled) for port in port_list]

    port_result_dict = {}
    port_remote_reseat_task_dict = {}
    for remote_reseat in remote_reseats:
        if remote_reseat.verify_prerequisites_result == 0:
            port_remote_reseat_task_dict[remote_reseat.port] = asyncio.create_task(
                remote_reseat.execute_remote_reseat_procedure_with_retry(max_retry_count))
        elif remote_reseat.verify_prerequisites_result == PRE_REQ_UNSUPPORTED_TRANSCEIVER:
                port_result_dict[remote_reseat.port] = 0
        else:
            port_result_dict[remote_reseat.port] = remote_reseat.verify_prerequisites_result

    remote_reseat_results = await asyncio.gather(*port_remote_reseat_task_dict.values(), return_exceptions=True)
    for port, result in zip(port_remote_reseat_task_dict.keys(), remote_reseat_results):
        port_result_dict[port] = result

    helper_logger.log_notice("Remote reseat: final result is {}".format(port_result_dict))

    return next((result for result in port_result_dict.values() if result != 0), 0)

if __name__ == '__main__':
    loop = asyncio.get_event_loop()
    result = loop.run_until_complete(main())
    loop.close()
    sys.exit(result)
