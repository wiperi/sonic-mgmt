import sdk

def get_device():
        la_dev = None
        for i in range(256):
                la_dev = sdk.la_get_device(i)
                if la_dev:
                        return la_dev

def apply():
      # 1.50.0.4
      la_dev = get_device()
      if not la_dev:
            print("ERROR: la_dev not found")
            return
      read_values = []
      ll_dev = la_dev.get_ll_device()
      tree = ll_dev.get_gibraltar_tree()
      for i in range(6):
            ll_dev.write_register(tree.slice[i].npu.rxpp_fwd.top.res_lb_header_type_mapping_reg[20], 65)
            ll_dev.write_register(tree.slice[i].npu.rxpp_fwd.top.res_lb_header_type_mapping_reg[22], 130)

def read_and_check():
      # 1.50.0.4
      la_dev = get_device()
      if not la_dev:
            print("ERROR: la_dev not found")
            return
      # Read the modified register values and check
      expected_values = [65, 130, 65, 130, 65, 130, 65, 130, 65, 130, 65, 130]
      values = []
      ll_dev = la_dev.get_ll_device()
      tree = ll_dev.get_gibraltar_tree()
      for i in range(6):
            values.append(ll_dev.read_register(tree.slice[i].npu.rxpp_fwd.top.res_lb_header_type_mapping_reg[20]))
            values.append(ll_dev.read_register(tree.slice[i].npu.rxpp_fwd.top.res_lb_header_type_mapping_reg[22]))
      return values == expected_values

# Apply the patch if the current register value is not expected
if not read_and_check():
    apply()
    if not read_and_check():
        print("Failed to apply patch. Register read back check failure.")
        exit(0)

print("Out-of-order fix applied.")

