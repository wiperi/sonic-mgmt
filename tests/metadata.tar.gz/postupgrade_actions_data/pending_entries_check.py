#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
    This scripts's job is to verify that there are no pending entries over a
    period of time in APP_DB that are yet to be consumed by orchagent.

    The script does does the following:

    * Read APP_DB tables once for pending entries.
    * Wait 30 seconds.
    * Read APP_DB tables again for pending entries
    * If there are overlapping entries between both reads,
        * Add that table to the list of tables to be synced
    * Go through all the tables that need to be synced
    * Publish the pending entries for that table

    This is to be run periodically on a SONiC device using a monit
    configuration file.
"""


import argparse
import os
import sys
import pdb
import time
import subprocess
import syslog
import shlex

from swsscommon import swsscommon

APPL_DB_NAME = 'APPL_DB'

os.environ['PYTHONUNBUFFERED'] = 'True'


def write_syslog(message, *args):
    """
    Write a message to syslog.

    :param message: Message string to be logged
    :param args: Optional args
    :return: None
    """

    if args:
        message %= args
    syslog.syslog(syslog.LOG_NOTICE, message)


def run_command(cmd):
    """
    Runs a command and returns its output.

    :param cmd: Command string to be run
    :return: Command output string
    """

    write_syslog("Running command: %s", cmd)
    try:
        p = subprocess.Popen(shlex.split(cmd),
                             stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        (output, _) = p.communicate()
    except Exception as details:
        raise RuntimeError("Failed to run command: %s", details)
    if p.returncode != 0:
        raise RuntimeError("Command failed with return code %s: %s"
                           % (p.returncode, output))
    write_syslog("Command completed successfully")
    return output.decode()


def sonic_db_cli(cmd):
    """
    Call a sonic-db-cli command with return error check.

    :param cmd: Command string to be passed to sonc-db-cli
    :return: Command output string
    """

    run_cmd = "sudo sonic-db-cli %s" % cmd
    result = run_command(run_cmd).strip()
    if "error" in result or "ERR" in result:
        raise RuntimeError("Command '%s' failed: %s" % (cmd, result))
    return result


def get_pending_tables():
    """
    The heart of the script that checks for pending APP_DB table entries

    :param: None
    :return ret: Boolean based on whether there are pending entries or not
    :return tables_to_be_synced: A list of APP_DB tables to be synced
    """

    ret = False
    tables_to_be_synced = []
    db = swsscommon.DBConnector(APPL_DB_NAME, 0)

    lag_member_tbl = swsscommon.Table(db, '_LAG_MEMBER_TABLE')
    lag_member_table_keys = lag_member_tbl.getKeys()
    lag_tbl = swsscommon.Table(db, '_LAG_TABLE')
    lag_table_keys = lag_tbl.getKeys()
    mux_tbl = swsscommon.Table(db, '_MUX_CABLE_TABLE')
    mux_table_keys = mux_tbl.getKeys()
    nbr_tbl = swsscommon.Table(db, '_NEIGH_TABLE')
    nbr_table_keys = nbr_tbl.getKeys()
    route_tbl = swsscommon.Table(db, '_ROUTE_TABLE')
    route_table_keys = route_tbl.getKeys()
    intf_tbl = swsscommon.Table(db, '_INTF_TABLE')
    intf_table_keys = intf_tbl.getKeys()

    time.sleep(30)

    lag_member_table_keys2 = lag_member_tbl.getKeys()
    lag_table_keys2 = lag_tbl.getKeys()
    mux_table_keys2 = mux_tbl.getKeys()
    nbr_table_keys2 = nbr_tbl.getKeys()
    route_table_keys2 = route_tbl.getKeys()
    intf_table_keys2 = intf_tbl.getKeys()

    if len(lag_member_table_keys2) != 0:
        for k in lag_member_table_keys2:
            if k in lag_member_table_keys:
                tables_to_be_synced.append("LAG_MEMBER_TABLE")
                ret = True
                break

    if len(lag_table_keys2) != 0:
        for k in lag_table_keys2:
            if k in lag_table_keys:
                tables_to_be_synced.append("LAG_TABLE")
                ret = True
                break

    if len(mux_table_keys2) != 0:
        for k in mux_table_keys2:
            if (k in mux_table_keys):
                tables_to_be_synced.append("MUX_CABLE_TABLE")
                ret = True
                break

    if len(nbr_table_keys2) != 0:
        for k in nbr_table_keys2:
            if k in nbr_table_keys:
                tables_to_be_synced.append("NEIGH_TABLE")
                ret = True
                break

    if len(route_table_keys2) != 0:
        for k in route_table_keys2:
            if k in route_table_keys:
                tables_to_be_synced.append("ROUTE_TABLE")
                ret = True
                break

    if len(intf_table_keys2) != 0:
        for k in intf_table_keys2:
            if k in intf_table_keys:
                tables_to_be_synced.append("INTF_TABLE")
                ret = True
                break

    return ret, tables_to_be_synced


def check_pending_entries():
    """
    The function that checks for pending APP_DB table entries
    and mitgates them by doing a publish using sonic-db-cli

    :param: None
    :return: True if there are pending entries, False otherwise
    """

    res, tables_to_sync = get_pending_tables()
    if not res:
        return True

    for t in tables_to_sync:
        write_syslog("Found pending entries for %s. \
                Mitigating by doing a publish", t)
        chan = t + "_CHANNEL"
        command = 'APPL_DB publish {} ""'.format(chan)
        result = sonic_db_cli(command)

    return False


if __name__ == "__main__":
    res = check_pending_entries()
    sys.exit(0 if res else 1)
