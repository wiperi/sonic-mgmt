#!/bin/bash


for kvh in {0..1}; do
    for pipe in {0..7}; do
        # control 2
        mcra /dev/mst/mt52100_pciconf0 $((0x1c2010 + (0x4000 * $kvh) + (0x400 * $pipe))).0:32 0xcc001022
        mcra /dev/mst/mt52100_pciconf0 $((0x1c2014 + (0x4000 * $kvh) + (0x400 * $pipe))).0:32 0x00040000
        # control 3 
        mcra /dev/mst/mt52100_pciconf0 $((0x1c2018 + (0x4000 * $kvh) + (0x400 * $pipe))).0:32 0xcc001022
        mcra /dev/mst/mt52100_pciconf0 $((0x1c201c + (0x4000 * $kvh) + (0x400 * $pipe))).0:32 0x00842200
        # control 4
        mcra /dev/mst/mt52100_pciconf0 $((0x1c2020 + (0x4000 * $kvh) + (0x400 * $pipe))).0:32 0xcc001025
        mcra /dev/mst/mt52100_pciconf0 $((0x1c2024 + (0x4000 * $kvh) + (0x400 * $pipe))).0:32 0x08040000
        # control 5
        mcra /dev/mst/mt52100_pciconf0 $((0x1c2028 + (0x4000 * $kvh) + (0x400 * $pipe))).0:32 0xc8001025
        mcra /dev/mst/mt52100_pciconf0 $((0x1c202c + (0x4000 * $kvh) + (0x400 * $pipe))).0:32 0x00040000
        # control 6
        mcra /dev/mst/mt52100_pciconf0 $((0x1c2030 + (0x4000 * $kvh) + (0x400 * $pipe))).0:32 0xcc271022
        mcra /dev/mst/mt52100_pciconf0 $((0x1c2034 + (0x4000 * $kvh) + (0x400 * $pipe))).0:32 0x00042600
        # control 7
        mcra /dev/mst/mt52100_pciconf0 $((0x1c2038 + (0x4000 * $kvh) + (0x400 * $pipe))).0:32 0xcc001022
        mcra /dev/mst/mt52100_pciconf0 $((0x1c203c + (0x4000 * $kvh) + (0x400 * $pipe))).0:32 0x00842600
    done
done
