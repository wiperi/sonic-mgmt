#!/bin/bash

IsArista1GSFP() {
    BUS=$1
    EEPROM_PATH="/sys/devices/pci0000:00/0000:00:02.2/0000:02:00.0/i2c-${BUS}/${BUS}-0050/eeprom"

    if [ `grep -s -c -ai "Arista" $EEPROM_PATH` -eq 1 ]; then
        if [ `grep -c -ai "SFP-1G" $EEPROM_PATH` -eq 1 ]; then
            #echo "Arista 1G-SFP detected"
            return 1
        fi
    fi
    return 0
}

GetConfiguredSpeed() {
    echo $(redis-cli --raw -n 4 hget "PORT|$1" speed)
}

# Initialize Marvell PHY 88E1111
InitPhy() {
    VALUE="0x16 0x00 0x16 0x01 0x0 0x01 0x0 0x40 0x16 0x00 0x16 0x00 0x1b 0x90 0x1b 0x80 0x0 0x91 0x0 0x40"

    BUS=$1
    ADDR=0x56

    set $VALUE

    while [ $# -gt 0 ]; do
        #echo i2cset -y $BUS $ADDR $1 $2
        i2cset -y $BUS $ADDR $1 $2
        shift
        shift
    done

    sleep 1

    VALUE="0x09 0x0c 0x09 0x00 0x04 0x0d 0x04 0x01 0x18 0x41 0x18 0x08 0x0 0x91 0x0 0x40"

    set $VALUE

    while [ $# -gt 0 ]; do
        #echo i2cset -y $BUS $ADDR $1 $2
        i2cset -y $BUS $ADDR $1 $2
        shift
        shift
    done

    sleep 1
}

source /host/machine.conf
if [ x"${aboot_platform}" != x"x86_64-arista_7050_qx32s" ]; then
    logger -p local0.notice "Skipping phyinit ..."
    exit 0
fi

# Handle SFP ports 1, 2, 3, 4
for bus in `seq 42 45`; do
    let port=$bus-41
    TX_DISABLE="/sys/devices/pci0000:00/0000:00:02.2/0000:02:00.0/sfp${port}_txdisable"
    PRESENCE_PIN="/sys/devices/pci0000:00/0000:00:02.2/0000:02:00.0/sfp${port}_present"
    RX_LOS="/sys/devices/pci0000:00/0000:00:02.2/0000:02:00.0/sfp${port}_rxlos"

    # Skip if SFP not present
    if [ `cat $PRESENCE_PIN` -eq 0 ]; then
        continue
    fi

    let sonicPort=${port}-1
    IFNAME="Ethernet${sonicPort}"
    sonicSpeed=$(GetConfiguredSpeed "${IFNAME}")
    if [ $sonicSpeed -ge 1000 ]; then
        logger -p local0.notice "skip phyinit on Port${port} @speed $sonicSpeed"
        continue
    fi

    retry=5
    IsArista1GSFP $bus
    if [ $? -eq 1 ]; then
        logger -p local0.notice "Arista 1G-SFP detected on Port${port}"

        config interface shutdown ${IFNAME}

        while [ $retry -gt 0 ]; do
            #echo $TX_DISABLE
            echo "1" >  $TX_DISABLE
            sleep 1
            echo "0" >  $TX_DISABLE
            sleep 1
            logger -p local0.notice "Initializing Marvell PHY-88E1111 on Port${port}"
            InitPhy $bus
            sleep 2

            if [ `cat $RX_LOS` -eq 0 ]; then
                break
            fi

            # Detect LOS
            if [ $retry -le 0 ]; then
                if [ `cat $RX_LOS` -eq 1 ]; then
                    logger -p local0.warning "RX LOS detected on PORT${port}"
                fi
            fi
            let retry=$retry-1
        done

        config interface startup ${IFNAME}
    fi
done

# Handle QSFP ports 6, 7, 8
for bus in `seq 11 13`; do
    let port=$bus-5
    RESET="/sys/devices/pci0000:00/0000:00:02.2/0000:02:00.0/qsfp${port}_reset"
    PRESENCE_PIN="/sys/devices/pci0000:00/0000:00:02.2/0000:02:00.0/qsfp${port}_present"
    RX_LOS="/sys/devices/pci0000:00/0000:00:02.2/0000:02:00.0/qsfp${port}_interrupt"

    # Skip if SFP not present
    if [ `cat $PRESENCE_PIN` -eq 0 ]; then
        continue
    fi

    let sonicPort=(${port}-5)*4
    IFNAME="Ethernet${sonicPort}"
    sonicSpeed=$(GetConfiguredSpeed "${IFNAME}")
    if [ $sonicSpeed -ge 1000 ]; then
        logger -p local0.notice "skip phyinit on Port${port} @speed $sonicSpeed"
        continue
    fi

    retry=5
    IsArista1GSFP $bus
    if [ $? -eq 1 ]; then
        logger -p local0.notice "Arista 1G-SFP detected on Port$port"

        config interface shutdown ${IFNAME}

        while [ $retry -gt 0 ]; do
            #echo $RESET
            echo "1" > $RESET
            sleep 1
            echo "0" > $RESET
            sleep 1
            logger -p local0.notice "Initializing Marvell PHY-88E1111 on Port$port"
            InitPhy $bus
            sleep 2

            if [ `cat $RX_LOS` -eq 0 ]; then
                break
            fi

            # Detect LOS
            if [ $retry -le 0 ]; then
                if [ `cat $RX_LOS` -eq 1 ]; then
                    logger -p local0.warning "RX LOS detected on PORT$port"
                fi
            fi
            let retry=$retry-1
        done

        config interface startup ${IFNAME}
    fi
done
