#!/usr/bin/python
# Version 1.0

from contextlib import contextmanager
import argparse
import re
import subprocess
import sys
import tempfile
import logging

try:
    from swsscommon.swsscommon import SonicV2Connector
except ImportError:
    from swsssdk import SonicV2Connector
import sonic_platform
import sonic_platform_base.sonic_sfp.sfputilhelper
from sonic_py_common import device_info, logger

sonic_logger = logger.Logger("bcm_40g_phy_reinit_cint_script")


T0_40G_PORTS = ['Ethernet0', 'Ethernet4', 'Ethernet8', 'Ethernet12', 'Ethernet16', 'Ethernet20', 'Ethernet40', 'Ethernet44', 'Ethernet48', 'Ethernet52', 'Ethernet56', 'Ethernet60', 'Ethernet64', 'Ethernet68', 'Ethernet72', 'Ethernet76', 'Ethernet80', 'Ethernet84', 'Ethernet104', 'Ethernet108', 'Ethernet112', 'Ethernet116']

def exec_cmd(cmd, verbose=True):
    p = subprocess.Popen(cmd, shell=True, executable='/bin/bash', stdout=subprocess.PIPE)
    outs, errs = p.communicate()
    msg = outs.decode('utf8')
    if outs and verbose: print('exec_cmd stdout = '+msg)
    if errs: print('exec_cmd stderr = '+errs)

    return (p.returncode, msg)


class CintTool():
    def runBcmCmd(self, cmd, output=False, **kwargs):
        cmd = ['bcmcmd'] + cmd
        try:
            if output:
                return subprocess.check_output(cmd, **kwargs).decode('utf-8').rstrip()
            else:
                return subprocess.check_call(cmd, **kwargs)
        except subprocess.CalledProcessError as e:
            sonic_logger.log_error('Error in runing bcmcmd {}: {}'.format(cmd, e))
            raise e


    def execCint(self, fileContent):
        with tempfile.NamedTemporaryFile(mode='w+', prefix='th_cint', dir='/etc/sonic') as tmp:
            tmp.write(fileContent)
            tmp.flush()
            output = self.runBcmCmd(['cint %s' % tmp.name], output=True)

            lines = output.splitlines()
            for line in lines:
                sonic_logger.log_debug('cint stdout: {}'.format(line))

            if 'execCintError' in output:
                sonic_logger.log_error('Error found in runing {}: {}'.format(fileContent, output))
                return None

            return lines


    def isPortEnabled(self, portInfo):
        content = '''
void update40GPortConfig() {
    int enabled = 0;
    int p = %s;
    int ret = 0;
    ret = bcm_port_enable_get(0, p, &enabled);
    if (ret) {
        printf("execCintError: bcm_port_enable_get\\n");
    }
    printf("Port enabled status: %%d\\n", enabled);
}

update40GPortConfig();

''' % portInfo.port
        output = self.execCint(content) or []
        for line in output:
            matcher = re.match(r'^Port enabled status: (\d+)$', line)
            if matcher:
                status = matcher.group(1)
                sonic_logger.log_info('  - {}: Initial bcm port enable status is {}'.format(portInfo, status))
                return int(status)
        sonic_logger.log_error('Failed to read enabled status for port {}'.format(portInfo.port))
        return 0

    def portEnableSet(self, portInfo, enable):
        content = '''
void update40GPortConfig() {
    int p = %s;
    int enable = %s;
    int ret = 0;
    ret = bcm_port_enable_set(0, p, enable);
    if (ret) {
        printf("execCintError: bcm_port_enable_set\\n");
    }
    sal_sleep(1);
}

update40GPortConfig();

''' % (portInfo.port, enable)
        sonic_logger.log_info('  - {}: Setting bcm port enable to {}'.format(portInfo, enable))
        self.execCint(content)


    @contextmanager
    def withDisablePort(self, portInfo):
        isEnabled = self.isPortEnabled(portInfo)
        if isEnabled:
            try:
                self.portEnableSet(portInfo, 0)
                yield
            finally:
                self.portEnableSet(portInfo, 1)
        else:
            sonic_logger.log_info('  - {}: Skipping bcm port disable'.format(portInfo))
            yield


    def setSr4AndUnreliableLOS(self, portInfo):
        content = '''
void update40GPortConfig() {
    int p = %s;
    int speed = 40000;
    int ret;

    // Set BCM_PORT_IF_SR4
    ret = bcm_port_interface_set(0, p, BCM_PORT_IF_SR4);
    if (ret) {
        printf("execCintError: bcm_port_interface_set\\n");
    }
    sal_sleep(1);
    ret = bcm_port_speed_get(0, p, &speed);
    if (ret) {
        printf("execCintError: bcm_port_speed_get\\n");
    } else {
        ret = bcm_port_speed_set(0, p, speed);
        if (ret) {
            printf("execCintError: bcm_port_speed_set\\n");
        }
        sal_sleep(1);
    }

    // Set BCM_PORT_PHY_CONTROL_UNRELIABLE_LOS
    ret = bcm_port_phy_control_set(0, p, BCM_PORT_PHY_CONTROL_UNRELIABLE_LOS, 1);
    if (ret) {
        printf("execCintError: bcm_port_phy_control_set\\n");
    }
    sal_sleep(1);
}
update40GPortConfig();
''' % portInfo.port
        sonic_logger.log_info('  - {}: Setting BCM_PORT_IF_SR4/BCM_PORT_PHY_CONTROL_UNRELIABLE_LOS'.format(portInfo))
        self.execCint(content)


    def getSr4AndUnreliableLOS(self, portInfo):
        content = '''
void update40GPortConfig() {
    int p = %s;
    int speed = 40000;
    int ret;
    uint32_t status;

    // Set BCM_PORT_IF_SR4
    ret = bcm_port_interface_set(0, p, BCM_PORT_IF_SR4);
    if (ret) {
        printf("execCintError: bcm_port_interface_set\\n");
    }
    sal_sleep(1);
    ret = bcm_port_speed_get(0, p, &speed);
    if (ret) {
        printf("execCintError: bcm_port_speed_get\\n");
    } else {
        ret = bcm_port_speed_set(0, p, speed);
        if (ret) {
            printf("execCintError: bcm_port_speed_set\\n");
        }
        sal_sleep(1);
    }

    // Get BCM_PORT_PHY_CONTROL_UNRELIABLE_LOS
    ret = bcm_port_phy_control_get(0, p, BCM_PORT_PHY_CONTROL_UNRELIABLE_LOS, &status);
    if (ret) {
        printf("execCintError: bcm_port_phy_control_get\\n");
    }
    printf("Port phy control enabled status: %%d\\n", status);
    sal_sleep(1);
}
update40GPortConfig();
''' % portInfo.port
        sonic_logger.log_info('  - {}: Getting BCM_PORT_IF_SR4/BCM_PORT_PHY_CONTROL_UNRELIABLE_LOS'.format(portInfo))
        
        output = self.execCint(content) or []
        for line in output:
            matcher = re.match(r'^Port phy control enabled status: (\d+)$', line)
            if matcher:
                status = matcher.group(1)
                sonic_logger.log_info('  - {}: Initial bcm port enable status is {}'.format(portInfo, status))
                return int(status)
        sonic_logger.log_error('Failed to get phy control enabled status for port {}'.format(portInfo.port))


    def obtainPortList(self):
        ret = []
        content = '''
void update40GPortConfig() {
    bcm_info_t info;
    int dev;
    int isTh;
    int isTh2;
    bcm_port_config_t config;
    bcm_pbmp_t pbmp_xe;
    int p;
    int speed;
    int ret;

    ret = bcm_info_get(0, &info);
    if (ret) {
        printf("execCintError: bcm_info_get\\n");
        return;
    }
    dev = info.device;
    isTh2 = (dev == 0xb970) || (dev == 0xb971) || (dev == 0xb972);
    isTh = (dev == 0xb960) || (dev == 0xb963);
    if (!(isTh || isTh2)) {
        printf("execCintError: no th or th2 chip found, device type = %d\\n", dev);
        return;
    }

    ret = bcm_port_config_get(0, &config);
    if (ret) {
        printf("execCintError: bcm_port_config_get\\n");
        return;
    }
    BCM_PBMP_ASSIGN(pbmp_xe, config.xe);
    BCM_PBMP_ITER(pbmp_xe, p) {
        ret = bcm_port_speed_get(0, p, &speed);
        if (ret) {
            printf("execCintError: bcm_port_speed_get\\n");
            continue;
        }
        if (speed != 40000) {
            continue;
        }
        printf("Found 40G XE port %d\\n", p);
    }
}
update40GPortConfig();
'''
        output = self.execCint(content)
        for line in output or []:
            matcher = re.match(r'^Found 40G XE port (\d+)$', line)
            if matcher:
                ret.append(int(matcher.group(1)))
        return ret


class XcvrTool():
    def __init__(self):
        self.intfToSfp = {}


    def initSfps(self, intfs):
        platform_chassis = sonic_platform.platform.Platform().get_chassis()
        platform_sfputil = sonic_platform_base.sonic_sfp.sfputilhelper.SfpUtilHelper()
        port_config_file_path = device_info.get_path_to_port_config_file()
        platform_sfputil.read_porttab_mappings(port_config_file_path, 0)
        for intf in intfs:
            try:
                physical_port = platform_sfputil.get_logical_to_physical(intf)
                sfp_port = platform_chassis.get_sfp(physical_port[0])
                self.intfToSfp[intf] = sfp_port
            except:
                sonic_logger.log_error('Failed to find sfp for intf {}'.format(intf))
                return False
        return True


    def txDisable(self, portInfo, disable):
        try:
            xcvr_api = self.intfToSfp[portInfo.intf].get_xcvr_api()
            supported = xcvr_api and xcvr_api.get_tx_disable_support()
            if not supported:
                sonic_logger.log_info('  - {}: Skip setting xcvr tx_diable to {}'.format(portInfo, disable))
                return
            sonic_logger.log_info('  - {}: Setting xcvr tx_diable to {}'.format(portInfo, disable))
            ret = self.intfToSfp[portInfo.intf].tx_disable(disable)
            if ret != True:
                sonic_logger.log_warning('Failed to set tx_disable for intf {}: {}'.format(portInfo, ret))
        except Exception as e:
            sonic_logger.log_warning('Exception to set tx_disable for intf {}: {}'.format(portInfo, e))


    @contextmanager
    def withTxDisable(self, portInfo):
        try:
            self.txDisable(portInfo, 1)
            yield
        finally:
            self.txDisable(portInfo, 0)


class PortInfo():
    def __init__(self, port, intf):
        self.port = port
        self.intf = intf


    def __str__(self):
        return '%s (%s)' % (self.intf, self.port)


    def __lt__(self, other):
        v1 = int(''.join(a for a in self.intf if a.isdigit()))
        v2 = int(''.join(a for a in other.intf if a.isdigit()))
        return v1 < v2


class Th40GFiberConfigurator():
    def __init__(self):
        self.portInfos = []


    def initPortMapping(self, logicalPorts, portmap):
        # Read mapping from lane to intf name
        laneToIntfName = {}
        db = SonicV2Connector(host="127.0.0.1")
        db.connect(db.APPL_DB)
        for key in db.keys(db.APPL_DB, 'PORT_TABLE:Ethernet*') or []:
            lanes = db.get(db.APPL_DB, key, 'lanes')
            intfName = key[len('PORT_TABLE:'):]
            matcher = re.match(r'^(\d+).*', lanes)
            if not matcher:
                continue
            laneToIntfName[int(matcher.group(1))] = intfName

        # Read mapping from logial port to lane
        logicalPortToLane = {}
        for line in portmap.splitlines():
            matcher=re.search(r'portmap_(\d+).*=(\d+).*', line)
            if not matcher:
                continue
            logicalPortToLane[int(matcher.group(1))] = int(matcher.group(2))

        # Iterate logicalPorts
        for port in logicalPorts:
            if port not in logicalPortToLane:
                sonic_logger.log_error('Failed to find lane for port {}'.format(port))
                return False
            lane = logicalPortToLane[port]
            if lane not in laneToIntfName:
                sonic_logger.log_error('Failed to find intf for lane {}'.format(lane))
                return False
            self.portInfos.append(PortInfo(port, laneToIntfName[lane]))
        self.portInfos.sort()
        return True


    def exec(self, all40GPorts=False):
        t0_ports_40G_list = []
        if not all40GPorts:
           rc, ports_stdout = exec_cmd("redis-cli -n 4 KEYS 'PORT|*'", verbose=False)
           all_ports = ports_stdout.split()
           for port in all_ports:
               actual_port = port.split('|')[1]
               rc, hget_speed = exec_cmd("redis-cli -n 4 HGET '{}' speed".format(port), verbose=False)
               speed = hget_speed.strip()
               # only if the speed connected is 40000 and the neighbor is a T0 append the port to the list
               if speed == "40000" and actual_port in T0_40G_PORTS:
                   t0_ports_40G_list.append(actual_port)

        # if no port available for bcm script, just return
        if len(t0_ports_40G_list) == 0:
            return 0

        cintTool = CintTool()
        xcvrTool = XcvrTool()
        logicalPorts = cintTool.obtainPortList()
        portmap = cintTool.runBcmCmd(['config'], output=True)
        if not portmap:
            sonic_logger.log_error('Failed to obtain portmap from bcm config')
            sys.exit(1)
        if not self.initPortMapping(logicalPorts, portmap):
            sonic_logger.log_error('Failed to read port mapping')
            sys.exit(1)
        if not xcvrTool.initSfps([portInfo.intf for portInfo in self.portInfos]):
            sonic_logger.log_error('Failed to prepare sfps')
            sys.exit(1)

        for portInfo in self.portInfos:
            if all40GPorts or portInfo.intf in t0_ports_40G_list:
                # Apply the settings once a relevant port is found
                sonic_logger.log_info('Updating port {}'.format(portInfo.intf))
                with xcvrTool.withTxDisable(portInfo):
                    with cintTool.withDisablePort(portInfo):
                        cintTool.setSr4AndUnreliableLOS(portInfo)
                
                #Disable the get SR4 check for now
                #cint_rc = cintTool.getSr4AndUnreliableLOS(portInfo)
                rc, rval = exec_cmd("redis-cli -n 6 HSET 'PORT_TABLE|{}' phy_ctrl_unreliable_los true".format(portInfo.intf), verbose=False)
                sonic_logger.log_notice('bcm port {} reinitalized using cint script'.format(portInfo))

        sonic_logger.log_info('All finished for bcm phy re init for 40G ports!')


def parseArgs():
    parser = argparse.ArgumentParser(description='Tool to configure SR4 and UnreliableLOS for 40G ports on TH/TH2')
    parser.add_argument('-v', '--verbose', action='store_true', help="verbose log")
    parser.add_argument('-a', '--all40GPorts', action='store_true', help="configure all 40G ports in bcmcmd ps")
    return parser.parse_args()


if __name__ == "__main__":
    args = parseArgs()
    if args.verbose:
        sonic_logger.set_min_log_priority(logger.Logger.LOG_PRIORITY_DEBUG)
    else:
        sonic_logger.set_min_log_priority(logger.Logger.LOG_PRIORITY_INFO)

    Th40GFiberConfigurator().exec(args.all40GPorts)
