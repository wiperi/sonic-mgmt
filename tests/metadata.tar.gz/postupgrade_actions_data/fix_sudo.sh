#!/bin/bash
SUDOER_TMP=$(mktemp)
cat /etc/sudoers | sed "${1}" > $SUDOER_TMP
tmp_file_size=$(du -b $SUDOER_TMP | awk '{ print $1 }')
# sed command may generate a empty file
if [[ "${tmp_file_size}" != "0" ]]; then
    # check tmp sudoers file format before write to sudoers.
    /usr/sbin/visudo -c -f $SUDOER_TMP && cat $SUDOER_TMP > /etc/sudoers
fi
rm $SUDOER_TMP

