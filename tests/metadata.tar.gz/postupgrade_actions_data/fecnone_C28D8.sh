#!/bin/bash

cat << END | xargs -I{} sudo bash -c "portconfig -f none -p {}; portconfig -l -p {}; config interface shutdown {}; config interface startup {}"
Ethernet0
Ethernet4
Ethernet8
Ethernet12
Ethernet16
Ethernet20
Ethernet40
Ethernet44
Ethernet48
Ethernet52
Ethernet56
Ethernet60
Ethernet64
Ethernet68
Ethernet72
Ethernet76
Ethernet80
Ethernet84
Ethernet104
Ethernet108
END
