import cr_access as cr

def read_adaptive_headroom_cfg_shared_spectrum_1(device_ptr, adb_ptr):
    res = {}
    res['shp_size_cell'] = cr.rw_register_by_name(device_ptr, adb_ptr, "glc.glc_sbanks.sbanks_ctrl.rq_quota_global_hr_threshold")
    res['ah_usage'] = cr.rw_register_by_name(device_ptr, adb_ptr, "glc.glc_sbanks.sbanks_rq_buf.sbanks_rq_quota_global_hr.data")
    return res

def read_port_pg(device_ptr, adb_ptr, local_port_index, pg_index):
    num_ports_in_4x = 2
    num_4x_in_cluster = 2
    num_ports_in_cluster = num_ports_in_4x * num_4x_in_cluster
    logic_port_index = local_port_index - 1
    cluster_index = logic_port_index // num_ports_in_cluster
    cluster_4x_index = (logic_port_index % num_ports_in_cluster) // num_4x_in_cluster
    cluster_4x_split_index = logic_port_index % num_ports_in_4x

    split_port_addr = "ports.cluster[" + str(cluster_index) + "].link.llu_rx.llu_rx_port[" + str(cluster_4x_index) + "].llu_rx_split[" + str(cluster_4x_split_index) + "]."
    flowctrl_buffers_addr = split_port_addr + "flowctrl.buffers."
    flowctrl_mac_timers_addr = split_port_addr + "flowctrl.mac_timers."

    flowctrl_buffers_registers = ["max_stat_cred" + str(pg_index),
                                  "used_stat_cred" + str(pg_index),
                                  # "max_sxoff",
                                  # "used_sxoff",
                                  "adaptive_hr_enable",
                                  "max_adaptive_hr_addition",
                                  "headroom_watermark" + str(pg_index),
                                  "used_adaptive_headroom"]
    mac_timers_registers = ["stat" + str(pg_index) + "_xoff_threshold",
                            "stat" + str(pg_index) + "_xon_threshold"]

    read_res = {}
    for reg in flowctrl_buffers_registers:
        read_res[reg] = cr.rw_register_by_name(device_ptr, adb_ptr, flowctrl_buffers_addr + reg)
    for reg in mac_timers_registers:
        read_res[reg] = cr.rw_register_by_name(device_ptr, adb_ptr, flowctrl_mac_timers_addr  + reg)
    return read_res

def adaptive_headroom_cfg_shared_spectrum_1(device_ptr, adb_ptr, shp_size_cells):
    print("adaptive_headroom_cfg_shared_spectrum_1(...) start");
    # config the size of shp
    cr.rw_register_by_name(device_ptr, adb_ptr, "glc.glc_sbanks.sbanks_ctrl.rq_quota_global_hr_threshold", shp_size_cells)
    print("adaptive_headroom_cfg_shared_spectrum_1(...) end\n\n\n");

def adaptive_headroom_cfg_port_pg_spectrum_1(device_ptr, adb_ptr, local_port_index, pg_index, hr_size, xoff_th, xon_th, adaptive_headroom_en, mtu_in_cells):
    print("- adaptive_headroom_cfg_port_pg_spectrum_1(...) start")
    num_ports_in_4x = 2
    num_4x_in_cluster = 2
    num_ports_in_cluster = num_ports_in_4x * num_4x_in_cluster
    logic_port_index = local_port_index - 1
    cluster_index = logic_port_index // num_ports_in_cluster
    cluster_4x_index = (logic_port_index % num_ports_in_cluster) // num_4x_in_cluster
    cluster_4x_split_index = logic_port_index % num_ports_in_4x

    split_port_addr = "ports.cluster[" + str(cluster_index) + "].link.llu_rx.llu_rx_port[" + str(cluster_4x_index) + "].llu_rx_split[" + str(cluster_4x_split_index) + "]."
    flowctrl_buffers_addr = split_port_addr + "flowctrl.buffers."
    flowctrl_mac_timers_addr = split_port_addr + "flowctrl.mac_timers."

    if adaptive_headroom_en is True:
        # (1) enable shared headroom for this PG
        # (1.1) enable pg to access shared xoff
        current_addr = flowctrl_buffers_addr + "shared_xoff_pg_enable"
        shared_xoff_pg_enable = cr.rw_register_by_name(device_ptr, adb_ptr, current_addr)
        print(shared_xoff_pg_enable);
        shared_xoff_pg_enable = shared_xoff_pg_enable  | (1<<pg_index)
        cr.rw_register_by_name(device_ptr, adb_ptr, current_addr, shared_xoff_pg_enable)

        # # (1.2) disable drop over static pg buff
        # stat_drop_threshold_addr = flowctrl_buffers_addr + "stat_drop_threshold_en"
        # stat_drop_threshold_en = cr.rw_register_by_name(device_ptr, adb_ptr, stat_drop_threshold_addr)
        # stat_drop_threshold_en = stat_drop_threshold_en & ~(1<<pg_index)
        # cr.rw_register_by_name(device_ptr, adb_ptr, stat_drop_threshold_addr, stat_drop_threshold_en)

        # (2) config the new pg size/xon/xoff
        current_addr = flowctrl_buffers_addr + "max_stat_cred" + str(pg_index)
        cr.rw_register_by_name(device_ptr, adb_ptr, current_addr, hr_size)
        current_addr = flowctrl_mac_timers_addr + "stat" + str(pg_index) + "_xoff_threshold"
        cr.rw_register_by_name(device_ptr, adb_ptr, current_addr, xoff_th)
        current_addr = flowctrl_mac_timers_addr + "stat" + str(pg_index) + "_xon_threshold"
        cr.rw_register_by_name(device_ptr, adb_ptr, current_addr, xon_th)

        # (3) enable adaptive headroom in GLC per PG
        glc_sbanks_rq_buf_gw_ctrl_addr = "glc.glc_sbanks.sbanks_rq_buf_gw_ctrl."
        glc_sbanks_buffer_gw = cr.GWDriver(device_ptr, cr.get_reg_from_path(glc_sbanks_rq_buf_gw_ctrl_addr + "lock")["addr"])

        glc_sbanks_buffer_gw.acquire_lock()
        cr.rw_register_by_name(device_ptr, adb_ptr, glc_sbanks_rq_buf_gw_ctrl_addr + "entry.q_p_qouta_addr", 9 * logic_port_index + pg_index)
        cr.rw_register_by_name(device_ptr, adb_ptr, glc_sbanks_rq_buf_gw_ctrl_addr + "entry.rq_pg_addr", 9 * logic_port_index + pg_index)
        cr.rw_register_by_name(device_ptr, adb_ptr, glc_sbanks_rq_buf_gw_ctrl_addr + "entry.q_p_quota_use_adaptive_hr", 1)
        cr.rw_register_by_name(device_ptr, adb_ptr, glc_sbanks_rq_buf_gw_ctrl_addr + "entry_bm.q_p_quota_use_adaptive_hr", 1)
        cr.rw_register_by_name(device_ptr, adb_ptr, glc_sbanks_rq_buf_gw_ctrl_addr + "entry.q_p_quota_private_hr_size_th", hr_size)
        cr.rw_register_by_name(device_ptr, adb_ptr, glc_sbanks_rq_buf_gw_ctrl_addr + "entry_bm.q_p_quota_private_hr_size_th", 0x7ffff)
        glc_sbanks_buffer_gw.gw_run(ctrl_offset=25, ctrl_value=5)
        glc_sbanks_buffer_gw.release_gw()

    print("- adaptive_headroom_cfg_port_pg_spectrum_1(...) end")

def adaptive_headroom_cfg_port_spectrum_1(device_ptr, adb_ptr, local_port_index, s_pg_size, s_xoff_th, s_xon_th, ah_en, ah_max_loan_th, ah_start_loan_th, mtu_in_cells):
    print("- adaptive_headroom_cfg_port_spectrum_1(...) start")


    if s_pg_size <= mtu_in_cells:
        mtu_in_cells = s_pg_size - 1

    num_ports_in_4x = 2
    num_4x_in_cluster = 2
    num_ports_in_cluster = num_ports_in_4x * num_4x_in_cluster
    logic_port_index = local_port_index - 1
    cluster_index = logic_port_index // num_ports_in_cluster
    cluster_4x_index = (logic_port_index % num_ports_in_cluster) // num_4x_in_cluster
    cluster_4x_split_index = logic_port_index % num_ports_in_4x

    split_port_addr = "ports.cluster[" + str(cluster_index) + "].link.llu_rx.llu_rx_port[" + str(cluster_4x_index) + "].llu_rx_split[" + str(cluster_4x_split_index) + "]."
    flowctrl_buffers_addr = split_port_addr + "flowctrl.buffers."
    flowctrl_mac_timers_addr = split_port_addr + "flowctrl.mac_timers."

    if ah_en is True:
        # sanity not to occupy adaptive headroom if local PTB is nearing full
        # this can be reduced by try and error
        cr.rw_register_by_name(device_ptr, adb_ptr, flowctrl_buffers_addr + "grade_disable_adaptive_th", 214)

        # enable adaptive headroom
        cr.rw_register_by_name(device_ptr, adb_ptr, flowctrl_buffers_addr + "adaptive_hr_enable", 1)

        # (1) config the shared pg size/xoff/xon/maxloan/startloan
        cr.rw_register_by_name(device_ptr, adb_ptr, flowctrl_buffers_addr + "max_sxoff", s_pg_size)
        cr.rw_register_by_name(device_ptr, adb_ptr, flowctrl_buffers_addr + "shared_drop_threshold", s_pg_size)
        cr.rw_register_by_name(device_ptr, adb_ptr, flowctrl_mac_timers_addr + "shared_xoff_threshold", s_xoff_th)
        cr.rw_register_by_name(device_ptr, adb_ptr, flowctrl_mac_timers_addr + "shared_xon_threshold", s_xon_th)
        cr.rw_register_by_name(device_ptr, adb_ptr, flowctrl_buffers_addr + "max_adaptive_hr_addition", ah_max_loan_th)
        cr.rw_register_by_name(device_ptr, adb_ptr, flowctrl_buffers_addr + "adaptive_hr_threshold", ah_start_loan_th)

        # Configure GLC with port
        glc_sbanks_rq_buf_gw_ctrl_addr = "glc.glc_sbanks.sbanks_rq_buf_gw_ctrl."
        glc_sbanks_buffer_gw = cr.GWDriver(device_ptr, cr.get_reg_from_path(glc_sbanks_rq_buf_gw_ctrl_addr + "lock")["addr"])

        glc_sbanks_buffer_gw.acquire_lock()
        cr.rw_register_by_name(device_ptr, adb_ptr, glc_sbanks_rq_buf_gw_ctrl_addr + "entry.q_only_addr", logic_port_index)
        cr.rw_register_by_name(device_ptr, adb_ptr, glc_sbanks_rq_buf_gw_ctrl_addr + "entry.rq_addr", logic_port_index)
        cr.rw_register_by_name(device_ptr, adb_ptr, glc_sbanks_rq_buf_gw_ctrl_addr + "entry.q_hr_quota_shared_occupancy_th", s_pg_size)
        cr.rw_register_by_name(device_ptr, adb_ptr, glc_sbanks_rq_buf_gw_ctrl_addr + "entry_bm.q_hr_quota_shared_occupancy_th", 0x7ffff)
        glc_sbanks_buffer_gw.gw_run(ctrl_offset=25, ctrl_value=8)
        glc_sbanks_buffer_gw.release_gw()

    print("- adaptive_headroom_cfg_port_spectrum_1(...) end\n\n\n")
