#!/usr/bin/env python3
'''
This script will determine the correct dSMS region to configure ACMS and update the config file
It will also update the ACMS config file with the bootstrap cert path
'''
import os, re, sys, ipaddress
from sonic_py_common import logger
from swsscommon import swsscommon

# ACMS config file
acms_conf = "/var/opt/msft/client/acms_secrets.ini"

# Redis DB information
REDIS_TIMEOUT_MS = 0

sonic_logger = logger.Logger()
sonic_logger.set_min_log_priority_info()

def get_device_cloudtype():
    try:
        config_db = swsscommon.DBConnector("CONFIG_DB", REDIS_TIMEOUT_MS, True)
        device_metadata = swsscommon.Table(config_db, swsscommon.CFG_DEVICE_METADATA_TABLE_NAME)
    except RuntimeError as e:
        # TODO: Use specific exception swsscommon.RedisError
        sonic_logger.log_error("dSMS_config_modifier: Unable to get cloudtype " + str(e))
        return ""
    (status, tuples) = device_metadata.get("localhost")
    localhost = dict(tuples)
    return localhost.get('cloudtype', '')

def get_mgmt_addr_list():
    result = []
    try:
        config_db = swsscommon.DBConnector("CONFIG_DB", REDIS_TIMEOUT_MS, True)
        mgmt_interface = swsscommon.Table(config_db, swsscommon.CFG_MGMT_INTERFACE_TABLE_NAME)
    except RuntimeError as e:
        # TODO: Use specific exception swsscommon.RedisError
        sonic_logger.log_error("dSMS_config_modifier: Unable to get mgmt interface " + str(e))
        return result
    keys = mgmt_interface.getKeys()
    separator = mgmt_interface.getTableNameSeparator()
    for key in keys:
        # key format: "MGMT_INTERFACE|addr/mask_length"
        start_index = key.find(separator)
        if start_index == -1:
            continue
        end_index = key.find('/', start_index + 1)
        if end_index == -1:
            continue
        result.append(key[start_index + 1:end_index])
    return result

def get_device_region_from_bootstrap_cert(path_to_bootstrap_cert):
    # /etc/sonic/credentials/sonic_acms_bootstrap-uswestcentral.pfx
    cert = os.path.basename(path_to_bootstrap_cert)
    region = cert.split('-')[1].split('.')[0]
    return region

def update_dsms_url(conf_file, new_url):
    '''
    Update the dSMS URL in the given config file by looking for line starting with FullHttpsDsmsUrl pattern
    '''
    with open(conf_file, "r+") as conf_file_t:
        contents = conf_file_t.read()
        if new_url not in contents:
            new_contents = re.sub("FullHttpsDsmsUrl=.*", "FullHttpsDsmsUrl="+new_url, contents)
            conf_file_t.seek(0)
            conf_file_t.write(new_contents)

def update_acms_dns(ip):
    '''
    Update the ACMS DNS in /etc/resolv.conf
    '''
    with open('/etc/resolv.conf', "w") as dns_file:
        new_contents = "nameserver " + ip + "\n"
        dns_file.write(new_contents)
    return

ipv4_dns_dic = {
    "public": "10.64.5.5",
    "fairfax": "10.111.39.6",
    "mooncake": "10.41.21.20",
    "usnat": "10.1.12.0",
    "ussec": "10.1.48.0"
}

ipv6_dns_dic = {
    "public": "nameserver 2603:10e1:100:c0::5",
    "fairfax": "nameserver 2001:489a:e01::5",
    "mooncake": "nameserver 2406:e500:8204::5"
}

def fix_dns_for_cloud(cloud):
    '''
    Identify the correct DNS IP address for dSMS endpoints in national clouds
    '''
    ipv4_dns = ipv4_dns_dic.get(cloud.lower(), "")
    if ipv4_dns:
        update_acms_dns(ipv4_dns)
        sonic_logger.log_info("dSMS_config_modifier: fix_dns_for_cloud: DNS for "+cloud+" is "+ipv4_dns)
    # Check addresses in the mgmt interface
    addr_list = get_mgmt_addr_list()
    if len(addr_list) == 0:
        return
    has_ipv6 = False
    has_ipv4 = False
    for addr in addr_list:
        try:
            ipaddress.IPv4Address(addr)
        except Exception as e:
            sonic_logger.log_info("dSMS_config_modifier: fix_dns_for_cloud: "+str(e))
        else:
            sonic_logger.log_info("dSMS_config_modifier: fix_dns_for_cloud: "+addr+" is ipv4")
            has_ipv4 = True
        try:
            ipaddress.IPv6Address(addr)
        except Exception as e:
            sonic_logger.log_info("dSMS_config_modifier: fix_dns_for_cloud: "+str(e))
        else:
            sonic_logger.log_info("dSMS_config_modifier: fix_dns_for_cloud: "+addr+" is ipv6")
            has_ipv6 = True
    # If the mgmt interface has only IPv6 address, use the IPv6 DNS
    if has_ipv6 and not(has_ipv4):
        ipv6_dns = ipv6_dns_dic.get(cloud.lower(), "")
        if ipv6_dns:
            update_acms_dns(ipv6_dns)
            sonic_logger.log_info("dSMS_config_modifier: fix_dns_for_cloud: DNS for "+cloud+" is "+ipv6_dns)
    return

def fix_endpoint_for_cloud(cloud):
    '''
    Identify the correct URL pattern for dSMS endpoints in national clouds 
    '''
    # Convert cloudtype to lowercase for case-insensitive string comparison
    if cloud.lower() == "FairFax".lower():
        url_pattern = "https://region-dsms.dsms.core.usgovcloudapi.net"
    elif cloud.lower() == "BlackForest".lower():
        url_pattern = "https://region-dsms.dsms.core.cloudapi.de"
    elif cloud.lower() == "Mooncake".lower():
        url_pattern = "https://region-dsms.dsms.core.chinacloudapi.cn"
    elif cloud.lower() == "USnat".lower():
        url_pattern = "https://region-dsms.dsms.core.eaglex.ic.gov"
    elif cloud.lower() == "USSec".lower():
        url_pattern = "https://region-dsms.dsms.core.microsoft.scloud"
    else:
        sonic_logger.log_error("CloudType "+cloud+" not listed!")
        return False
    sonic_logger.log_info("dSMS_config_modifier: fix_endpoint_for_cloud: dSMS endpoint for "+cloud+" is "+url_pattern)
    # Change URL pattern in the ACMS config file
    update_dsms_url(acms_conf, url_pattern)
    return True

def update_config(path_to_bootstrap_cert):
    '''
    Determine the correct dSMS endpoint and update the ACMS config file
    '''
    region = get_device_region_from_bootstrap_cert(path_to_bootstrap_cert)
    with open(acms_conf, "r+") as acms_conf_file:
        contents = acms_conf_file.read()
        new_contents = re.sub("region", region, contents)
        new_contents = re.sub("BootstrapCert=.*\n*", "BootstrapCert="+path_to_bootstrap_cert+"\n", new_contents)
        sonic_logger.log_info("dSMS_config_modifier: update_config: Updated config: "+new_contents)
        acms_conf_file.seek(0)
        acms_conf_file.write(new_contents)
        sonic_logger.log_debug("dSMS_config_modifier: update_config: dSMS endpoint set to "+region)
