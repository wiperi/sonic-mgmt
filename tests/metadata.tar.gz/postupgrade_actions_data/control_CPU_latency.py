#!/usr/bin/python

import time
from struct import *

with open("/dev/cpu_dma_latency", "w") as file_t:
    value = pack('=i', 0)
    file_t.write(value)
    file_t.flush()
    while True: 
        time.sleep(60)
