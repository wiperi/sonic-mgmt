#!/bin/bash


for kvh in {0..1}; do
    for pipe in {0..7}; do
        # control 2
        if [[ x"$(mcra /dev/mst/mt52100_pciconf0 $((0x1c2010 + (0x4000 * $kvh) + (0x400 * $pipe))).0:32)" != x"0xcc001022" ]]; then exit 1; fi
        if [[ x"$(mcra /dev/mst/mt52100_pciconf0 $((0x1c2014 + (0x4000 * $kvh) + (0x400 * $pipe))).0:32)" != x"0x00040000" ]]; then exit 1; fi 
        # control 3 
        if [[ x"$(mcra /dev/mst/mt52100_pciconf0 $((0x1c2018 + (0x4000 * $kvh) + (0x400 * $pipe))).0:32)" != x"0xcc001022" ]]; then exit 1; fi
        if [[ x"$(mcra /dev/mst/mt52100_pciconf0 $((0x1c201c + (0x4000 * $kvh) + (0x400 * $pipe))).0:32)" != x"0x00842200" ]]; then exit 1; fi
        # control 4
        if [[ x"$(mcra /dev/mst/mt52100_pciconf0 $((0x1c2020 + (0x4000 * $kvh) + (0x400 * $pipe))).0:32)" != x"0xcc001025" ]]; then exit 1; fi
        if [[ x"$(mcra /dev/mst/mt52100_pciconf0 $((0x1c2024 + (0x4000 * $kvh) + (0x400 * $pipe))).0:32)" != x"0x08040000" ]]; then exit 1; fi
        # control 5
        if [[ x"$(mcra /dev/mst/mt52100_pciconf0 $((0x1c2028 + (0x4000 * $kvh) + (0x400 * $pipe))).0:32)" != x"0xc8001025" ]]; then exit 1; fi
        if [[ x"$(mcra /dev/mst/mt52100_pciconf0 $((0x1c202c + (0x4000 * $kvh) + (0x400 * $pipe))).0:32)" != x"0x00040000" ]]; then exit 1; fi
        # control 6
        if [[ x"$(mcra /dev/mst/mt52100_pciconf0 $((0x1c2030 + (0x4000 * $kvh) + (0x400 * $pipe))).0:32)" != x"0xcc271022" ]]; then exit 1; fi
        if [[ x"$(mcra /dev/mst/mt52100_pciconf0 $((0x1c2034 + (0x4000 * $kvh) + (0x400 * $pipe))).0:32)" != x"0x00042600" ]]; then exit 1; fi
        # control 7
        if [[ x"$(mcra /dev/mst/mt52100_pciconf0 $((0x1c2038 + (0x4000 * $kvh) + (0x400 * $pipe))).0:32)" != x"0xcc001022" ]]; then exit 1; fi
        if [[ x"$(mcra /dev/mst/mt52100_pciconf0 $((0x1c203c + (0x4000 * $kvh) + (0x400 * $pipe))).0:32)" != x"0x00842600" ]]; then exit 1; fi
    done
done