#!/usr/bin/env python
import argparse
from interfaces import *
import adaptive_headroom as ah

parser = argparse.ArgumentParser(description='Reads Shared Headroom Configuration from HW')
parser.add_argument('--interfaces', metavar='INTF', type=str, nargs='*',
                    default=[], help='Interfaces to configure (defaults to all)')
parser.add_argument('--pg', metavar='PG', type=int, nargs='*',
                    default=[3, 4], help='Priority Groups to read (defaults to 3, 4)')
args = parser.parse_args()
if len(args.interfaces) == 0:
    args.interfaces = get_all_interfaces()

device_ptr = "/dev/mst/mt52100_pciconf0"
adb_ptr = "/mswg/release/fw/fw-SwitchEN/fw-SwitchEN-rel-13_2000_1470/../etc/condor_def.dump"
read_res = ah.read_adaptive_headroom_cfg_shared_spectrum_1(device_ptr, adb_ptr)
print("Global:\n-----------------")
print("\tShared Pool XOFF: %d\n\tShared Pool Usage: %d" % (cells_to_bytes(read_res['shp_size_cell']), cells_to_bytes(read_res['ah_usage'])))

for if_name in args.interfaces:
    if not(if_name.startswith("Ethernet")):
        continue
    print("\n%s:\n-----------------" % if_name)
    local_port_index = get_local_port_index(if_name)
    for pg in args.pg:
        print("PG %d" % pg)
        read_res = ah.read_port_pg(device_ptr, adb_ptr, local_port_index, pg)
        size = cells_to_bytes(read_res['max_stat_cred%s'%pg])
        print("\tPrivate Headroom Size: %d" % size)
        xon = cells_to_bytes(read_res['stat%s_xon_threshold'%pg])
        xoff = cells_to_bytes(read_res['max_stat_cred%s'%pg] - read_res['stat%s_xoff_threshold'%pg])
        watermark = cells_to_bytes(read_res['headroom_watermark%s'%pg])
        print("\tPrivate Headroom XOFF: %d" % xoff)
        print("\tPrivate Headroom XON:  %d" % xon)
        print("\tUsing Shared Headroom: %s" % ("TRUE" if read_res["adaptive_hr_enable"] else "FALSE"))
        print("\tShared Headroom Maximum Allowed Usage (configuration): %d" % cells_to_bytes(read_res["max_adaptive_hr_addition"]))
        print("\tShared Headroom Maximum Usage (Watermark): %d" % watermark)
