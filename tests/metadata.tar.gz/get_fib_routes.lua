function string.split(str, sep, ...)
    local result = {}
    local startIndex = 1
    local resultIndex =1
    local times = select(1, ...)
    local counts = 1

    if select('#', ...) > 1 then
        return -1
    end
    if str == nil or sep == nil or type(str) ~= "string" or type(sep) ~= "string" then
        return result
    end
    if string.len(sep) == 0 then
        return result
    end
    while (not times or counts <= times) do
        local endIndex = string.find(str, sep, startIndex)
        if not endIndex then
            result[resultIndex] = string.sub(str, startIndex, string.len(str))
            break
        end
        result[resultIndex] = string.sub(str, startIndex, endIndex - 1)
        startIndex = endIndex + string.len(sep)
        resultIndex = resultIndex + 1
        counts = counts + 1
    end
    result[resultIndex] = string.sub(str, startIndex, string.len(str))
    return result
end


local fib_entries = {}
local fib_str = redis.call('keys', KEYS[1])

if #fib_str == 0 then
    return 3
end

local count = 0
local nexthop = ""
local ifname = ""

for i,s in ipairs(fib_str) do
    -- s = "ROUTE_TABLE:20c0:fff8:0:80::/64"
    while true do
        if #s == 0 then
            break
        end

        local ent = redis.call('HGETALL', s)
        if #ent == 0 then
            break
        end

        table.insert(fib_entries, {s.split(s, ":", 1)[2], ent, "*EOL*"})
        count = count + 1
        break
    end
end

return fib_entries
