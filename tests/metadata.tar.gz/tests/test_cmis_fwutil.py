import asyncio
from io import StringIO
import time
import pytest
import os
import sys
import unittest
from unittest.mock import AsyncMock, patch, MagicMock

sys.path.insert( 0, '..' )
sys.modules['sonic_platform'] = MagicMock()
sys.modules['sonic_platform.platform'] = MagicMock()
sys.modules['sonic_py_common'] = MagicMock()
sys.modules['swsscommon'] = MagicMock()
sys.modules['sonic_platform_base'] = MagicMock()
sys.modules['sonic_platform_base.sonic_sfp'] = MagicMock()
sys.modules['sonic_platform_base.sonic_sfp.sfputilhelper'] = MagicMock()

time.sleep = MagicMock()
import cmis_fwutil

SHOW_INTERFACE_STATUS_OUTPUT = """\
  Interface                Lanes    Speed    MTU    FEC    Alias    Vlan    Oper    Admin                                             Type    Asym PFC
-----------  -------------------  -------  -----  -----  -------  ------  ------  -------  -----------------------------------------------  ----------
  Ethernet0  2048,2049,2050,2051     400G   9100    N/A    etp0a  routed      down       up  QSFP-DD Double Density 8X Pluggable Transceiver         off""".encode("utf-8")

SHOW_INTERFACE_STATUS_INVALID_OUTPUT = """\
  Interface                Lanes    Speed    MTU    FEC    Alias    Vlan    Oper    Admin                                             Type    Asym PFC
-----------  -------------------  -------  -----  -----  -------  ------  ------  -------  -----------------------------------------------  ----------
  Ethernet0  2048,2049,2050,2051     400G   9100    N/A    etp0a  routed      down       QSFP-DD Double Density 8X Pluggable Transceiver         off""".encode("utf-8")

FIRMWARE_DOWNLOAD_SUCCESS="""\
CDB: Starting firmware download
Downloading ...  [###################################-]   99%  00:00:00
CDB: firmware download complete
Firmware download complete success
Total download Time: 0:05:06.785182""".encode("utf-8")

FIRMWARE_RUN_SUCCESS="""\
Running firmware: Non-hitless Reset to Inactive Image
Firmware run in mode=0 success""".encode("utf-8")

FIRMWARE_COMMIT_SUCCESS="""\
Firmware commit successful""".encode("utf-8")

FIRMWARE_VERSION_DUMP="""\
Image A Version: 5.2.0
Image B Version: 5.3.0
Factory Image Version: 1.5.2
Running Image: A
Committed Image: A
Active Firmware: 5.2.0
Inactive Firmware: 5.3.0"""

class TestSonicPyAPIXcvrUtility(object):
    # The SonicPyAPIXcvrUtility.__init__ failures are tested through the test cases in CMISFWUtilTest.
    # This has been done since the __init__ method calls sys.exit upon failure and this class is not inherited from unittest.TestCase (helps in handling assertRaises)
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @pytest.mark.parametrize(
            "mock_exception, mock_is_xcvr_api_none, is_single_target, expected_return_value",
            [
                (False, True, False, (None, None)),
                (True, False, False, (None, None)),
                (False, False, False, (True, cmis_fwutil.DEFAULT_TARGET_LIST)),
                (False, False, True, (False, None))
            ])
    def test_get_transceiver_remote_side_fw_upgrade_support(self, mock_exception, mock_is_xcvr_api_none, is_single_target, expected_return_value):
        mock_sonic_utility = cmis_fwutil.SonicPyAPIXcvrUtility("Ethernet0")
        mock_sfp = MagicMock()
        mock_xcvr_api = MagicMock()
        if mock_is_xcvr_api_none:
            mock_sfp.get_xcvr_api = MagicMock(return_value=None)
        elif mock_exception:
            mock_sfp.get_xcvr_api = MagicMock(side_effect=Exception("ValueError"))
        elif is_single_target:
            del mock_xcvr_api.set_firmware_download_target_end
            mock_sfp.get_xcvr_api = MagicMock(return_value=mock_xcvr_api)

        mock_sonic_utility.sfp = mock_sfp
        support_status = mock_sonic_utility.get_transceiver_remote_side_fw_upgrade_support()
        assert support_status == expected_return_value

    @pytest.mark.parametrize(
            "mock_exception, mock_presence_value, expected_return_value",
            [
                (False, False, False),
                (False, True, True),
                (True, None, None)
            ])
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    def test_is_transceiver_present(self, mock_exception, mock_presence_value, expected_return_value):
        mock_sonic_utility = cmis_fwutil.SonicPyAPIXcvrUtility("Ethernet0")
        if mock_exception:
            mock_sonic_utility.sfp.get_presence = MagicMock(side_effect=Exception("ValueError"))
        else:
            mock_sonic_utility.sfp.get_presence = MagicMock(return_value=mock_presence_value)
        presence_status = mock_sonic_utility.is_transceiver_present()
        assert presence_status == expected_return_value

    @pytest.mark.parametrize("expected_result, raises_exception", [
        (True, False),  # Successful timeout setting
        (True, False),  # Another successful case
        (False, True),  # Expected failure due to an exception
    ])
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    def test_set_optoe_write_timeout(self, expected_result, raises_exception):
        mock_sonic_utility = cmis_fwutil.SonicPyAPIXcvrUtility("Ethernet0")
        mock_sonic_utility.sfp = MagicMock()
        if raises_exception:
            mock_sonic_utility.sfp.set_optoe_write_timeout.side_effect = Exception("Mocked exception")

        assert mock_sonic_utility.set_optoe_write_timeout(1) == expected_result

    @pytest.mark.parametrize(
            "mock_exception, mock_transceiver_firmware_info_dict, expected_return_value",
            [
                (False, {"active_firmware" : "1.2.3", "inactive_firmware" : "0.1.0"}, {"active_firmware" : "1.2.3", "inactive_firmware" : "0.1.0"}),
                (False, None, None),
                (True, None, None)
            ])
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_value_from_db_by_field', MagicMock(return_value=True))
    def test_get_firmware_versions_for_all_sides(self, mock_exception, mock_transceiver_firmware_info_dict, expected_return_value):
        mock_sfp = MagicMock()
        if mock_exception:
            mock_sfp.get_transceiver_info_firmware_versions = MagicMock(side_effect=Exception("ValueError"))
        else:
            mock_sfp.get_transceiver_info_firmware_versions = MagicMock(return_value=(mock_transceiver_firmware_info_dict))
        mock_sonic_utility = cmis_fwutil.SonicPyAPIXcvrUtility("Ethernet0")
        mock_sonic_utility.sfp = mock_sfp
        assert mock_sonic_utility.get_firmware_versions_for_all_sides() == expected_return_value

    @pytest.mark.parametrize(
            "mock_exception, mock_transceiver_firmware_info_dict, expected_return_value",
            [
                (False, {"active_firmware" : "1.2.3", "inactive_firmware" : "0.1.0"}, ("1.2.3", "0.1.0")),
                (False, None, (None, None)),
                (True, None, (None, None))
            ])
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_value_from_db_by_field', MagicMock(return_value=True))
    def test_active_inactive_firmware_version_by_target(self, mock_exception, mock_transceiver_firmware_info_dict, expected_return_value):
        mock_sfp = MagicMock()
        if mock_exception:
            mock_sfp.get_transceiver_info_firmware_versions = MagicMock(side_effect=Exception("ValueError"))
        else:
            mock_sfp.get_transceiver_info_firmware_versions = MagicMock(return_value=(mock_transceiver_firmware_info_dict))
        mock_sonic_utility = cmis_fwutil.SonicPyAPIXcvrUtility("Ethernet0")
        mock_sonic_utility.sfp = mock_sfp
        assert mock_sonic_utility.get_active_inactive_firmware_version_by_target() == expected_return_value

    @pytest.mark.parametrize(
            "mock_exception, mock_is_xcvr_api_none, mock_field, mock_info_dict, expected_return_value",
            [
                (False, False, "running", {'info' : FIRMWARE_VERSION_DUMP}, 'A'),
                (False, False, "committed", {'info' : FIRMWARE_VERSION_DUMP}, 'A'),
                (False, False, "", {'info' : FIRMWARE_VERSION_DUMP}, None),
                (False, False, "running", {'info' : 'invalid'}, None),
                (False, False, "running", None, None),
                (True, False, "running", {'info' : FIRMWARE_VERSION_DUMP}, None),
                (False, True, "running", None, None)
            ])
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    def test_get_image_bank_by_field(self, mock_exception, mock_is_xcvr_api_none, mock_field, mock_info_dict, expected_return_value):
        mock_sfp = MagicMock()
        mock_xcvr_api = MagicMock()
        if mock_exception:
            mock_xcvr_api.get_module_fw_info = MagicMock(side_effect=Exception("ValueError"))
        else:
            mock_xcvr_api.get_module_fw_info = MagicMock(return_value=(mock_info_dict))
        if mock_is_xcvr_api_none:
            mock_sfp.get_xcvr_api = MagicMock(return_value=None)
        else:
            mock_sfp.get_xcvr_api = MagicMock(return_value=mock_xcvr_api)
        mock_sonic_utility = cmis_fwutil.SonicPyAPIXcvrUtility("Ethernet0")
        mock_sonic_utility.sfp = mock_sfp
        assert mock_sonic_utility.get_image_bank_by_field(mock_field) == expected_return_value

class TestSonicPyAPIAndCommandsUtility(object):
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @patch('subprocess.Popen')
    def test_run_command_success(self, mock_popen):
        sonic_utility = cmis_fwutil.SonicPyAPIAndCommandsUtility("Ethernet0")
        mock_popen.return_value.communicate.return_value = (b'test_output', b'')
        mock_popen.return_value.returncode = 0
        return_code, result, _ = sonic_utility.run_command("test_command")
        assert return_code == 0
        assert result == b'test_output'

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @patch('subprocess.Popen', MagicMock(side_effect=Exception("ValueError")))
    def test_run_command_exception(self):
        sonic_utility = cmis_fwutil.SonicPyAPIAndCommandsUtility("Ethernet0")
        return_code, result, _ = sonic_utility.run_command("test_command")
        assert return_code == None
        assert result == None

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @pytest.mark.parametrize(
            "run_command_return_value, expected_return_value",
            [
                ((None, '', ''), None),
                ((2, '', ''), None),
                ((0, "202305".encode("utf-8"), ''), "202305")
            ])
    def test_get_os_version(self, run_command_return_value, expected_return_value):
        mock_sonic_utility = cmis_fwutil.SonicPyAPIAndCommandsUtility("Ethernet0")
        mock_sonic_utility.run_command = MagicMock(return_value=run_command_return_value)
        output = mock_sonic_utility.get_os_version()
        assert output == expected_return_value

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @pytest.mark.parametrize(
            "run_command_return_value, expected_return_value",
            [
                ((None, '', ''), None),
                ((2, '', ''), None),
                ((0, SHOW_INTERFACE_STATUS_OUTPUT, ''), "down")
            ])
    def test_get_interface_oper_status(self, run_command_return_value, expected_return_value):
        mock_sonic_utility = cmis_fwutil.SonicPyAPIAndCommandsUtility("Ethernet0")
        mock_sonic_utility.run_command = MagicMock(return_value=run_command_return_value)
        output = mock_sonic_utility.get_interface_oper_status()
        assert output == expected_return_value

    @pytest.mark.parametrize(
            "mock_db, mock_key, mock_field, mock_run_command_return_value, expected_return_value",
            [
                ('CONFIG_DB', 'key1', 'field1', (0, "value1".encode("utf-8"), ''), "value1"),
                ('STATE_DB', 'key2', 'field2', (0, "value2".encode("utf-8"), ''), "value2"),
                ('CONFIG_DB', 'key4', 'field4', (None, None, ''), None), # Invalid key
                ('STATE_DB', 'key5', 'field5', (2, '', ''), None), # Invalid return code
                ('APP_DB', 'key6', 'field6', (0, '', ''), None) # Invalid value
            ])
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    def test_get_value_from_db_by_field(self, mock_db, mock_key, mock_field, mock_run_command_return_value, expected_return_value):
        lport="Ethernet0"
        mock_sonic_utility = cmis_fwutil.SonicPyAPIAndCommandsUtility(lport)
        mock_sonic_utility.run_command = MagicMock(return_value=mock_run_command_return_value)
        return_value = mock_sonic_utility.get_value_from_db_by_field(mock_db, mock_key, mock_field, lport)
        assert return_value == expected_return_value
        if mock_db in cmis_fwutil.SUPPORTED_DB_LIST:
            assert mock_sonic_utility.run_command.call_count == 1
            assert mock_sonic_utility.run_command.call_args[0][0] == "sonic-db-cli -n '{}' {} HGET \"{}|{}\" {}".\
                    format(mock_sonic_utility.namespace, mock_db, mock_key, mock_sonic_utility.lport, mock_field)

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @pytest.mark.parametrize(
            "mock_dict, mock_run_command_return_value, expected_result",
            [
                (None, [(None, '', '')], False),
                (None, [(2, '', '')], False),
                ({"active_firmware" : "0.2.5", "inactive_firmware" : "1.2.1"}, ([0, '', ''], [0, '', '']), True),
                ({"active_firmware" : "0.2.5", "inactive_firmware" : "1.2.1"}, ([2, '', ''], [0, '', '']), False),
                (None, ([0, '', ''], [2, '', '']), False) # Invalid return value while updating inactive firmware version
            ])
    def test_update_transceiver_firmware_info_to_state_db(self, mock_dict, mock_run_command_return_value, expected_result):
        mock_sonic_utility = cmis_fwutil.SonicPyAPIAndCommandsUtility("Ethernet0")
        mock_sonic_utility.run_command = MagicMock(side_effect=mock_run_command_return_value)
        mock_sonic_utility.get_firmware_versions_for_all_sides = MagicMock(return_value=mock_dict)
        return_value = mock_sonic_utility.update_transceiver_firmware_info_to_state_db()
        assert return_value == expected_result

    @pytest.mark.parametrize(
            "mock_cmis_state, expected_return_value",
            [
                ('READY', True),  # Terminal state
                (None, False)  # CMIS state retrieval fails
            ])
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    def test_is_cmis_sm_in_terminal_state(self, mock_cmis_state, expected_return_value):
        mock_sonic_utility = cmis_fwutil.SonicPyAPIAndCommandsUtility("Ethernet0")
        mock_sonic_utility.get_value_from_db_by_field = MagicMock(return_value=mock_cmis_state)
        output = asyncio.run(mock_sonic_utility.is_cmis_sm_in_terminal_state())
        assert output == expected_return_value

    @pytest.mark.parametrize(
            "mock_cmis_suport, expected_return_value",
            [
                ("1.2", True),
                ("", False),
                (None, False)
            ])
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    def test_is_transceiver_cmis_compliant(self, mock_cmis_suport, expected_return_value):
        mock_sonic_utility = cmis_fwutil.SonicPyAPIAndCommandsUtility("Ethernet0")
        mock_sonic_utility.get_value_from_db_by_field = MagicMock(return_value=mock_cmis_suport)
        assert mock_sonic_utility.is_transceiver_cmis_compliant() == expected_return_value

    @pytest.mark.parametrize(
            "model, expected_result",
            [
                ("DEF8504-2C12-MB3", True),
                ("DEF8504-2CXX-MB3", False),
                ("DEF8504-2C1B-MB3", False),
                ("", None),  # Model is empty string
                (None, None)  # Model is None
            ])
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    def test_is_transceiver_with_single_bank(self, model, expected_result):
        mock_sonic_utility = cmis_fwutil.SonicPyAPIAndCommandsUtility("Ethernet0")
        mock_sonic_utility.get_value_from_db_by_field = MagicMock(return_value=model)
        assert mock_sonic_utility.is_transceiver_with_single_bank() == expected_result

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @pytest.mark.parametrize(
            "dom_enable, run_command_return_value, expected_result",
            [
                (False, (None, '', ''), False),
                (False, (2, '', ''), False),
                (False, (0, '', ''), True),
                (True, (0, '', ''), True)
            ])
    def test_set_port_dom_config(self, dom_enable, run_command_return_value, expected_result):
        mock_sonic_utility = cmis_fwutil.SonicPyAPIAndCommandsUtility("Ethernet0")
        mock_sonic_utility.run_command = MagicMock(return_value=run_command_return_value)
        assert mock_sonic_utility.set_port_dom_config(dom_enable) == expected_result

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @pytest.mark.parametrize(
            "dom_config",
            [
                (None),
                ('enabled'),
                ('disabled'),
                ('')
            ])
    def test_set_get_port_dom_config(self, dom_config):
        mock_sonic_utility = cmis_fwutil.SonicPyAPIAndCommandsUtility("Ethernet0")
        mock_sonic_utility.get_value_from_db_by_field = MagicMock(return_value=dom_config)
        assert mock_sonic_utility.get_port_dom_config() == dom_config

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @pytest.mark.parametrize(
            "run_command_return_value, expected_return_value",
            [
                ((None, '', ''), False),
                ((2, '', ''), False),
                ((0, SHOW_INTERFACE_STATUS_OUTPUT, ''), True)
            ])
    def test_is_link_status_down(self, run_command_return_value, expected_return_value):
        mock_sonic_utility = cmis_fwutil.SonicPyAPIAndCommandsUtility("Ethernet0")
        mock_sonic_utility.run_command = MagicMock(return_value=run_command_return_value)
        output = mock_sonic_utility.is_link_status_down()
        assert output == expected_return_value

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @pytest.mark.parametrize(
            "run_command_return_value, expected_return_value",
            [
                ((None, '', ''), None),
                ((2, '', ''), None),
                ((0, SHOW_INTERFACE_STATUS_INVALID_OUTPUT, ''), None),
                ((0, SHOW_INTERFACE_STATUS_OUTPUT, ''), "up")
            ])
    def test_get_interface_admin_status(self, run_command_return_value, expected_return_value):
        mock_sonic_utility = cmis_fwutil.SonicPyAPIAndCommandsUtility("Ethernet0")
        mock_sonic_utility.run_command = MagicMock(return_value=run_command_return_value)
        output = mock_sonic_utility.get_interface_admin_status()
        assert output == expected_return_value

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @pytest.mark.parametrize(
            "run_command_return_value, expected_return_value",
            [
                ((None, '', ''), False),
                ((2, '', ''), False),
                ((0, '', ''), True)
            ])
    def test_execute_interface_shutdown(self, run_command_return_value, expected_return_value):
        mock_sonic_utility = cmis_fwutil.SonicPyAPIAndCommandsUtility("Ethernet0")
        mock_sonic_utility.run_command = MagicMock(return_value=run_command_return_value)
        output = mock_sonic_utility.execute_interface_shutdown()
        assert output == expected_return_value

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @pytest.mark.parametrize(
            "run_command_return_value, expected_return_value",
            [
                ((None, '', ''), False),
                ((2, '', ''), False),
                ((0, '', ''), True)
            ])
    def test_execute_interface_startup(self, run_command_return_value, expected_return_value):
        mock_sonic_utility = cmis_fwutil.SonicPyAPIAndCommandsUtility("Ethernet0")
        mock_sonic_utility.run_command = MagicMock(return_value=run_command_return_value)
        output = mock_sonic_utility.execute_interface_startup()
        assert output == expected_return_value

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @pytest.mark.parametrize(
            "run_command_return_value, expected_return_value",
            [
                ((None, '', ''), False),
                ((2, '', ''), False),
                ((0, 'OK'.encode("utf-8"), ''), True)
            ])
    def test_execute_sfputil_reset(self, run_command_return_value, expected_return_value):
        mock_sonic_utility = cmis_fwutil.SonicPyAPIAndCommandsUtility("Ethernet0")
        mock_sonic_utility.run_command = MagicMock(return_value=run_command_return_value)
        output = mock_sonic_utility.execute_sfputil_reset()
        assert output == expected_return_value

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @pytest.mark.parametrize(
            "mock_target, run_command_return_value, expected_return_status",
            [
                (cmis_fwutil.LOCAL_SIDE_FW_UPGRADE_TARGET, (0, "Target Mode set to 0".encode("utf-8"), ''), True),
                (cmis_fwutil.LOCAL_SIDE_FW_UPGRADE_TARGET, (0, "Target Mode set to".encode("utf-8"), ''), False),
                (cmis_fwutil.LOCAL_SIDE_FW_UPGRADE_TARGET, (1, '', ''), False)
            ])
    def test_set_firmware_target(self, mock_target, run_command_return_value, expected_return_status):
        mock_sonic_utility = cmis_fwutil.SonicPyAPIAndCommandsUtility("Ethernet0")
        mock_sonic_utility.run_command = MagicMock(return_value=run_command_return_value)
        return_status = mock_sonic_utility.set_firmware_target(mock_target)
        assert return_status == expected_return_status

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @pytest.mark.parametrize(
            "mock_target, run_command_return_value, original_inactive_fw_version, new_inactive_fw_version, expected_return_value, expected_return_output",
            [
                (cmis_fwutil.LOCAL_SIDE_FW_UPGRADE_TARGET, (None, '', ''), None, None, False, None),
                (cmis_fwutil.LOCAL_SIDE_FW_UPGRADE_TARGET, (None, '', ''), '1.2.0', '2.1.0', False, None),
                (cmis_fwutil.LOCAL_SIDE_FW_UPGRADE_TARGET, (2, ''.encode("utf-8"), ''), '1.2.0', '2.1.0', False, ''),
                (cmis_fwutil.LOCAL_SIDE_FW_UPGRADE_TARGET, (0, "Failed".encode("utf-8"), ''), '1.2.0', None, False, "Failed"),
                (cmis_fwutil.LOCAL_SIDE_FW_UPGRADE_TARGET, (0, "Failed".encode("utf-8"), ''), '1.2.0', '1.2.0', False, "Failed"),
                (cmis_fwutil.LOCAL_SIDE_FW_UPGRADE_TARGET, (0, FIRMWARE_DOWNLOAD_SUCCESS, ''), '1.2.0', '2.1.0', True, FIRMWARE_DOWNLOAD_SUCCESS.decode("utf-8")),
                (1, None, '1.2.0', None, False, None)
            ])
    def test_firmware_download(self, mock_target, run_command_return_value, original_inactive_fw_version, new_inactive_fw_version, expected_return_value, expected_return_output):
        mock_sonic_utility = cmis_fwutil.SonicPyAPIAndCommandsUtility("Ethernet0")
        mock_sonic_utility.run_command = MagicMock(return_value=run_command_return_value)
        mock_sonic_utility.set_firmware_target = MagicMock(return_value=False)
        mock_sonic_utility.get_active_inactive_firmware_version_by_target = MagicMock(side_effect=[(None, original_inactive_fw_version), (None, new_inactive_fw_version)])
        ret_code, output = mock_sonic_utility.firmware_download("path", mock_target)
        assert ret_code == expected_return_value
        assert output == expected_return_output
        if mock_target == cmis_fwutil.LOCAL_SIDE_FW_UPGRADE_TARGET:
            assert mock_sonic_utility.set_firmware_target.call_count == 0
        else:
            assert mock_sonic_utility.set_firmware_target.call_count == 1

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @pytest.mark.parametrize(
            "mock_target, mock_set_target_call_count, mock_set_target_side_effect, run_command_return_value, original_running_image_bank, new_running_image_bank, expected_return_value, expected_return_output",
            [
                (cmis_fwutil.LOCAL_SIDE_FW_UPGRADE_TARGET, 0, None, (None, '', ''), 'A', 'A', False, None),
                (cmis_fwutil.LOCAL_SIDE_FW_UPGRADE_TARGET, 0, None, (None, '', ''), None, None, False, None),
                (cmis_fwutil.LOCAL_SIDE_FW_UPGRADE_TARGET, 0, None, (2, ''.encode("utf-8"), ''), 'A', None, False, ""),
                (cmis_fwutil.LOCAL_SIDE_FW_UPGRADE_TARGET, 0, None, (0, "Failed".encode("utf-8"), ''), 'A', None, False, "Failed"),
                (cmis_fwutil.LOCAL_SIDE_FW_UPGRADE_TARGET, 0, None, (0, "Failed".encode("utf-8"), ''), 'A', 'A', False, "Failed"),
                (cmis_fwutil.LOCAL_SIDE_FW_UPGRADE_TARGET, 0, None, (0, FIRMWARE_RUN_SUCCESS, ''), 'A', 'B', True, FIRMWARE_RUN_SUCCESS.decode("utf-8")),
                (1, 1, [False], None, None, None, False, None),
                (1, 2, [True, False], (0, "Failed".encode("utf-8"), ''), 'A', 'A', False, None),
                (2, 3, [True, True, False], (0, FIRMWARE_RUN_SUCCESS, ''), 'A', 'B', False, None),
            ])
    def test_firmware_run(self, mock_target, mock_set_target_call_count, mock_set_target_side_effect, run_command_return_value, expected_return_value, original_running_image_bank, new_running_image_bank, expected_return_output):
        mock_sonic_utility = cmis_fwutil.SonicPyAPIAndCommandsUtility("Ethernet0")
        mock_sonic_utility.run_command = MagicMock(return_value=run_command_return_value)
        mock_sonic_utility.get_image_bank_by_field = MagicMock(side_effect=[original_running_image_bank, new_running_image_bank])
        mock_sonic_utility.set_firmware_target = MagicMock(side_effect=mock_set_target_side_effect)
        ret_code, output = mock_sonic_utility.firmware_run(mock_target, False)
        assert ret_code == expected_return_value
        assert output == expected_return_output
        assert mock_sonic_utility.set_firmware_target.call_count == mock_set_target_call_count

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @pytest.mark.parametrize(
            "mock_target, mock_set_target_call_count, mock_set_target_side_effect, run_command_return_value, original_committed_image_bank, new_committed_image_bank, expected_return_value, expected_return_output",
            [
                (cmis_fwutil.LOCAL_SIDE_FW_UPGRADE_TARGET, 0, None, (None, '', ''), 'A', 'A', False, None),
                (cmis_fwutil.LOCAL_SIDE_FW_UPGRADE_TARGET, 0, None, (None, '', ''), None, None, False, None),
                (cmis_fwutil.LOCAL_SIDE_FW_UPGRADE_TARGET, 0, None, (2, ''.encode("utf-8"), ''), 'A', None, False, ""),
                (cmis_fwutil.LOCAL_SIDE_FW_UPGRADE_TARGET, 0, None, (0, "Failed".encode("utf-8"), ''), 'A', None, False, "Failed"),
                (cmis_fwutil.LOCAL_SIDE_FW_UPGRADE_TARGET, 0, None, (0, "Failed".encode("utf-8"), ''), 'A', 'A', False, "Failed"),
                (cmis_fwutil.LOCAL_SIDE_FW_UPGRADE_TARGET, 0, None, (0, FIRMWARE_COMMIT_SUCCESS, ''), 'A', 'B', True, FIRMWARE_COMMIT_SUCCESS.decode("utf-8")),
                (cmis_fwutil.LOCAL_SIDE_FW_UPGRADE_TARGET, 0, None, (None, '', ''), 'A', 'A', False, None),
                (1, 1, [False], None, None, None, False, None),
                (1, 2, [True, False], (0, "Failed".encode("utf-8"), ''), 'A', 'A', False, None),
                (2, 3, [True, True, False], (0, FIRMWARE_COMMIT_SUCCESS, ''), 'A', 'B', False, None)
            ])
    def test_firmware_commit(self, mock_target, mock_set_target_call_count, mock_set_target_side_effect, run_command_return_value, original_committed_image_bank, new_committed_image_bank, expected_return_value, expected_return_output):
        mock_sonic_utility = cmis_fwutil.SonicPyAPIAndCommandsUtility("Ethernet0")
        mock_sonic_utility.run_command = MagicMock(return_value=run_command_return_value)
        mock_sonic_utility.get_image_bank_by_field = MagicMock(side_effect=[original_committed_image_bank, new_committed_image_bank])
        mock_sonic_utility.set_firmware_target = MagicMock(side_effect=mock_set_target_side_effect)
        ret_code, output = mock_sonic_utility.firmware_commit(mock_target, False)
        assert ret_code == expected_return_value
        assert output == expected_return_output
        assert mock_sonic_utility.set_firmware_target.call_count == mock_set_target_call_count

class TestBase(unittest.TestCase):
    def checkCmd(self, success, testargs, sysExit=True, uid=0):
        with patch('sys.stdout', new=StringIO()) as stdOutput:
            testargs = ['./cmis_fwutil.py'] + testargs
            with patch.object(sys, 'argv', testargs):
                with patch.object(os, 'geteuid', return_value=uid):
                    if sysExit:
                        with self.assertRaises(SystemExit) as cm:
                            loop = asyncio.new_event_loop()
                            asyncio.set_event_loop(loop)
                            try:
                                return_val = loop.run_until_complete(cmis_fwutil.main())
                            finally:
                                loop.close()
                        if success:
                            self.assertTrue(cm.exception.code == 0)
                        else:
                            self.assertTrue(cm.exception.code != 0)
                            return cm.exception.code, stdOutput.getvalue().strip()
                    else:
                        loop = asyncio.new_event_loop()
                        asyncio.set_event_loop(loop)
                        try:
                            return_val = loop.run_until_complete(cmis_fwutil.main())
                        finally:
                            loop.close()


            return return_val, stdOutput.getvalue().strip()

    def checkPassAndGetOutput(self, testargs):
        cmd_return_value, output = self.checkCmd(True, testargs, sysExit=False)
        return cmd_return_value, output

    def checkPass(self, testargs):
        cmd_return_value, _ = self.checkPassAndGetOutput(testargs)
        return cmd_return_value

    def checkFailAndGetOutput(self, testargs, userId=0):
        cmd_return_value, output = self.checkCmd(False, testargs, sysExit=True, uid=userId)
        return cmd_return_value, output

    def checkFail(self, testargs, userId=0):
        cmd_return_value, _ = self.checkFailAndGetOutput(testargs, userId=userId)
        return cmd_return_value

def get_value_from_db_by_field_callback(*args, **kwargs):
    if args[2] == "model":
        return "ABC"
    return ""

class CMISFWUtilTest(TestBase):
    def test_non_sudo_caller(self):
        self.assertEqual(self.checkFail(['-p', 'Ethernet0', '-a', '-g', '2.3.0'], userId=1000), cmis_fwutil.ERROR_NON_SUDO)

    @patch('sonic_platform_base.sonic_sfp.sfputilhelper.SfpUtilHelper', MagicMock(return_value=False))
    def test_load_sfputilhelper_failure(self):
        self.assertEqual(self.checkFail(['-p', 'Ethernet0', '-a', '-g', '2.3.0']), cmis_fwutil.ERROR_LOAD_PLATFORM_SFPUTIL)

    @patch('sonic_py_common.multi_asic.is_multi_asic', MagicMock(return_value=False))
    @patch('sonic_py_common.device_info.get_paths_to_platform_and_hwsku_dirs', MagicMock(return_value=(None, "test")))
    @patch('sonic_platform_base.sonic_sfp.sfputilhelper.SfpUtilHelper', MagicMock(return_value=True))
    @patch('sonic_platform_base.sonic_sfp.sfputilhelper.SfpUtilHelper.read_porttab_mappings', MagicMock(side_effect=AttributeError))
    def test_load_port_config_failure_single_asic(self):
        self.assertEqual(self.checkFail(['-p', 'Ethernet0', '-a', '-g', '2.3.0']), cmis_fwutil.ERROR_LOAD_PORT_CONFIG)

    @patch('sonic_py_common.multi_asic.is_multi_asic', MagicMock(return_value=True))
    @patch('sonic_py_common.device_info.get_paths_to_platform_and_hwsku_dirs', MagicMock(return_value=(None, "test")))
    @patch('sonic_platform_base.sonic_sfp.sfputilhelper.SfpUtilHelper', MagicMock(return_value=True))
    @patch('sonic_platform_base.sonic_sfp.sfputilhelper.SfpUtilHelper.read_all_porttab_mappings', MagicMock(side_effect=AttributeError))
    def test_load_port_config_failure_ns(self):
        self.assertEqual(self.checkFail(['-p', 'Ethernet0', '-a', '-g', '2.3.0']), cmis_fwutil.ERROR_LOAD_PORT_CONFIG)

    @patch('sonic_py_common.multi_asic.is_multi_asic', MagicMock(return_value=True))
    @patch('sonic_py_common.device_info.get_paths_to_platform_and_hwsku_dirs', MagicMock(return_value=(None, "test")))
    @patch('sonic_platform_base.sonic_sfp.sfputilhelper.SfpUtilHelper')
    def test_invalid_logical_port(self, mock_sfputilhelper):
        mock_platform_sfputil = MagicMock()
        mock_platform_sfputil.read_all_porttab_mappings = MagicMock()
        mock_platform_sfputil.is_logical_port = MagicMock(return_value=False)
        mock_sfputilhelper.return_value = mock_platform_sfputil
        self.assertEqual(self.checkFail(['-p', 'Ethernet0', '-a', '-g', '2.3.0']), cmis_fwutil.ERROR_INVALID_LPORT)

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('sonic_platform_base.sonic_sfp.sfputilhelper.SfpUtilHelper')
    def test_get_pport_failure(self, mock_sfputilhelper):
        mock_platform_sfputil = MagicMock()
        mock_platform_sfputil.is_logical_port = MagicMock(return_value=True)
        mock_platform_sfputil.get_logical_to_physical = MagicMock(return_value=None)
        mock_sfputilhelper.return_value = mock_platform_sfputil
        self.assertEqual(self.checkFail(['-p', 'Ethernet0', '-a', '-g', '2.3.0']), cmis_fwutil.ERROR_INVALID_PPORT)

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('sonic_platform_base.sonic_sfp.sfputilhelper.SfpUtilHelper')
    def test_get_first_lport_of_pport_failure(self, mock_sfputilhelper):
        mock_platform_sfputil = MagicMock()
        mock_platform_sfputil.is_logical_port = MagicMock(return_value=True)
        mock_platform_sfputil.get_physical_to_logical = MagicMock(return_value=None)
        mock_sfputilhelper.return_value = mock_platform_sfputil
        self.assertEqual(self.checkFail(['-p', 'Ethernet0', '-a', '-g', '2.3.0']), cmis_fwutil.ERROR_INVALID_FIRST_LPORT_OF_PPORT)

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('sonic_platform_base.sonic_sfp.sfputilhelper.SfpUtilHelper')
    @patch('sonic_platform.platform.Platform')
    def test_get_sfp_exception_failure(self, mock_platform, mock_sfputilhelper):
        mock_platform_sfputil = MagicMock()
        mock_platform_sfputil.is_logical_port = MagicMock(return_value=True)
        mock_platform_sfputil.get_physical_to_logical = MagicMock(return_value=["Ethernet0"])
        mock_sfputilhelper.return_value = mock_platform_sfputil
        mock_chassis = MagicMock()
        mock_chassis.return_value.get_sfp = MagicMock(side_effect=AttributeError)
        mock_platform.return_value.get_chassis = mock_chassis
        self.assertEqual(self.checkFail(['-p', 'Ethernet0', '-a', '-g', '2.3.0']), cmis_fwutil.ERROR_GET_SFP_INIT)

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @patch('sonic_platform.platform.Platform')
    def test_get_sfp_None_failure(self, mock_platform):
        mock_chassis = MagicMock()
        mock_chassis.return_value.get_sfp = MagicMock(return_value=None)
        mock_platform.return_value.get_chassis = mock_chassis
        self.assertEqual(self.checkFail(['-p', 'Ethernet0', '-a', '-g', '2.3.0']), cmis_fwutil.ERROR_GET_SFP_INIT)

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_os_version', MagicMock(return_value=None))
    def test_prerequisite_os_version_None_failure(self):
        self.assertEqual(self.checkFail(['-p', 'Ethernet0', '-a', '-g', '2.3.0']), cmis_fwutil.ERROR_PRE_REQ_OS_CHECK)

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_os_version', MagicMock(return_value="201911"))
    def test_prerequisite_os_version_unsupported_failure(self):
        self.assertEqual(self.checkFail(['-p', 'Ethernet0', '-a', '-g', '2.3.0']), cmis_fwutil.ERROR_PRE_REQ_OS_CHECK)

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_os_version', MagicMock(return_value="202305"))
    @patch('os.path.isfile', MagicMock(return_value=False))
    def test_invalid_fw_path(self):
        self.assertEqual(self.checkFail(['-p Ethernet0', '-d', 'invalid_path', '-g', '2.3.0']), cmis_fwutil.ERROR_PRE_REQ_FW_PATH_CHECK)

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_os_version', MagicMock(return_value="202305"))
    @patch('os.path.isfile', MagicMock(return_value=False))
    def test_invalid_gold_firmware_version(self):
        self.assertEqual(self.checkFail(['-p Ethernet0', '-a', '-g', '3.0']), cmis_fwutil.ERROR_PRE_REQ_GOLD_FIRMWARE_VERSION_CHECK)
        self.assertEqual(self.checkFail(['-p Ethernet0', '-a', '-g', '1..0']), cmis_fwutil.ERROR_PRE_REQ_GOLD_FIRMWARE_VERSION_CHECK)
        self.assertEqual(self.checkFail(['-p Ethernet0', '-a', '-g', 'A.B.C']), cmis_fwutil.ERROR_PRE_REQ_GOLD_FIRMWARE_VERSION_CHECK)

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_os_version', MagicMock(return_value="202305"))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.is_transceiver_present', MagicMock(return_value=None))
    def test_prerequisite_transceiver_present_None_failure(self):
        self.assertEqual(self.checkFail(['-p', 'Ethernet0', '-a', '-g', '2.3.0']), cmis_fwutil.ERROR_PRE_REQ_PRESENCE_CHECK)

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_non_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.is_transceiver_present', MagicMock(return_value=False))
    def test_prerequisite_transceiver_present_failure(self):
        self.assertEqual(self.checkFail(['-p', 'Ethernet0', '-a', '-g', '2.3.0']), cmis_fwutil.ERROR_PRE_REQ_PRESENCE_CHECK)

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_non_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.is_transceiver_present', MagicMock(return_value=True))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.is_transceiver_cmis_compliant', MagicMock(return_value=False))
    def test_prerequisite_is_transceiver_non_cmis(self):
        self.assertEqual(self.checkFail(['-p', 'Ethernet0', '-a', '-g', '2.3.0']), cmis_fwutil.ERROR_PRE_REQ_FWUPGRADE_SUPPORT)

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @patch('cmis_fwutil.CMISFWUtilFactory.verify_prerequisites_and_create_instance', MagicMock(side_effect=Exception("ValueError")))
    def test_cmis_fwutil_instance_create_exception(self):
        self.assertEqual(self.checkFail(['-p', 'Ethernet0', '-a', '-g', '2.3.0']), cmis_fwutil.ERROR_CMIS_FW_UTIL_INSTANCE_CREATE)

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_non_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_transceiver_remote_side_fw_upgrade_support', MagicMock(return_value=(None, None)))
    def test_remote_side_firmware_upgrade_check_error(self):
        self.assertEqual(self.checkFail(['-p', 'Ethernet0', '-a', '-g', '2.3.0']), cmis_fwutil.ERROR_REMOTE_SIDE_FW_UPGRADE_SUPPORT_CHECK)

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_non_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_transceiver_remote_side_fw_upgrade_support', MagicMock(return_value=(False, None)))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.is_transceiver_with_single_bank', MagicMock(return_value=None))
    def test_single_bank_None_failure(self):
        self.assertEqual(self.checkFail(['-p', 'Ethernet0', '-a', '-g', '2.3.0']), cmis_fwutil.ERROR_SINGLE_BANK_CHECK)

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_transceiver_remote_side_fw_upgrade_support', MagicMock(return_value=(False, None)))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.is_transceiver_with_single_bank', MagicMock(return_value=False))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.set_port_dom_config', MagicMock(return_value=True))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_non_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_value_from_db_by_field', MagicMock(return_value=''))
    def test_set_optoe_write_timeout_failure_during_firmware_activate(self):
        self.assertEqual(self.checkFail(['-p', 'Ethernet0', '-a', '-g', '2.3.0']), cmis_fwutil.ERROR_SET_OPTOE_WRITE_TIMEOUT)
        assert cmis_fwutil.SonicPyAPIAndCommandsUtility.set_port_dom_config.call_count == 2

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_non_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_transceiver_remote_side_fw_upgrade_support', MagicMock(return_value=(False, None)))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.set_optoe_write_timeout', MagicMock(side_effect=[False, True]))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.is_transceiver_with_single_bank', MagicMock(return_value=False))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_value_from_db_by_field', MagicMock(side_effect=["", "DEF8504-2C12-MB3"]))
    @patch('cmis_fwutil.CMISFWUtilSingleTarget.shutdown_interface_and_verify_link_down', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.set_port_dom_config', MagicMock(return_value=True))
    def test_cmis_fwutil_activate_with_optoe_write_timeout_if_required_failure(self):
        self.assertEqual(self.checkFail(['-p', 'Ethernet0', '-a', '-g', '2.3.0']), cmis_fwutil.ERROR_SET_OPTOE_WRITE_TIMEOUT)
        assert cmis_fwutil.SonicPyAPIAndCommandsUtility.set_port_dom_config.call_count == 2

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_non_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_transceiver_remote_side_fw_upgrade_support', MagicMock(return_value=(False, None)))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.set_optoe_write_timeout', MagicMock(side_effect=[True, False]))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.is_transceiver_with_single_bank', MagicMock(return_value=False))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_value_from_db_by_field', MagicMock(side_effect=["", "DEF8504-2C12-MB3"]))
    @patch('cmis_fwutil.CMISFWUtilSingleTarget.shutdown_interface_and_verify_link_down', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.set_port_dom_config', MagicMock(return_value=True))
    def test_cmis_fwutil_activate_with_optoe_write_timeout_restore_failure(self):
        self.assertEqual(self.checkFail(['-p', 'Ethernet0', '-a', '-g', '2.3.0']), cmis_fwutil.ERROR_SET_OPTOE_WRITE_TIMEOUT_DEFAULT)
        assert cmis_fwutil.SonicPyAPIAndCommandsUtility.set_port_dom_config.call_count == 2

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_transceiver_remote_side_fw_upgrade_support', MagicMock(return_value=(False, None)))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.is_transceiver_with_single_bank', MagicMock(return_value=False))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.set_port_dom_config', MagicMock(return_value=True))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_non_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_active_inactive_firmware_version_by_target', MagicMock(return_value=(("None", None))))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_value_from_db_by_field', MagicMock(side_effect=get_value_from_db_by_field_callback))
    def test_verify_cdb_command_access(self):
        self.assertEqual(self.checkFail(['-p', 'Ethernet0', '-a', '-g', '2.3.0']), cmis_fwutil.ERROR_CDB_COMMAND_ACCESS_CHECK)
        assert cmis_fwutil.SonicPyAPIAndCommandsUtility.set_port_dom_config.call_count == 2

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_transceiver_remote_side_fw_upgrade_support', MagicMock(return_value=(False, None)))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.is_transceiver_with_single_bank', MagicMock(return_value=False))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_non_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_value_from_db_by_field', MagicMock(return_value=None))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.set_port_dom_config', MagicMock(return_value=True))
    def test_port_get_dom_failure(self):
        self.assertEqual(self.checkFail(['-p', 'Ethernet0', '-a', '-g', '2.3.0']), cmis_fwutil.ERROR_DOM_STATUS_CHECK)
        assert cmis_fwutil.SonicPyAPIAndCommandsUtility.set_port_dom_config.call_count == 0

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_transceiver_remote_side_fw_upgrade_support', MagicMock(return_value=(False, None)))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_non_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.is_transceiver_with_single_bank', MagicMock(return_value=False))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_value_from_db_by_field', MagicMock(return_value=''))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.set_port_dom_config', MagicMock(side_effect=(False, True)))
    def test_port_dom_disable_failure(self):
        self.assertEqual(self.checkFail(['-p', 'Ethernet0', '-a', '-g', '2.3.0']), cmis_fwutil.ERROR_DOM_DISABLE)
        assert cmis_fwutil.SonicPyAPIAndCommandsUtility.set_port_dom_config.call_count == 2

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_transceiver_remote_side_fw_upgrade_support', MagicMock(return_value=(False, None)))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_non_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.is_transceiver_with_single_bank', MagicMock(return_value=False))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_value_from_db_by_field', MagicMock(return_value=''))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.set_port_dom_config', MagicMock(side_effect=(True, False)))
    def test_port_dom_restore_failure(self):
        self.assertEqual(self.checkFail(['-p', 'Ethernet0', '-a', '-g', '2.3.0']), cmis_fwutil.ERROR_DOM_ENABLE)
        assert cmis_fwutil.SonicPyAPIAndCommandsUtility.set_port_dom_config.call_count == 2

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_non_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.is_transceiver_present', MagicMock(return_value=True))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.is_transceiver_cmis_compliant', MagicMock(return_value=True))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_transceiver_remote_side_fw_upgrade_support', MagicMock(return_value=(False, None)))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.is_transceiver_with_single_bank', MagicMock(return_value=False))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_value_from_db_by_field', MagicMock(side_effect=get_value_from_db_by_field_callback))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.set_port_dom_config', MagicMock(return_value=True))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_active_inactive_firmware_version_by_target', MagicMock(return_value=(("0.2.5", "1.2.1"))))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.firmware_download', MagicMock(return_value=(False, None)))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.update_transceiver_firmware_info_to_state_db', MagicMock(return_value=True))
    def test_firmware_download_with_existing_gold_firmware_success(self):
        self.assertEqual(self.checkPass(['-p', 'Ethernet0', '-d', 'path', '-g', '1.2.1']), 0)
        assert cmis_fwutil.SonicPyAPIAndCommandsUtility.firmware_download.call_count == 0
        assert cmis_fwutil.SonicPyAPIAndCommandsUtility.set_port_dom_config.call_count == 2
        assert cmis_fwutil.SonicPyAPIAndCommandsUtility.update_transceiver_firmware_info_to_state_db.call_count == 1

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_non_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_transceiver_remote_side_fw_upgrade_support', MagicMock(return_value=(False, None)))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.is_transceiver_with_single_bank', MagicMock(return_value=False))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_value_from_db_by_field', MagicMock(side_effect=get_value_from_db_by_field_callback))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.set_port_dom_config', MagicMock(return_value=True))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_active_inactive_firmware_version_by_target', MagicMock(return_value=(("0.2.5", "1.2.1"))))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.firmware_download', MagicMock(return_value=(True, 'Success')))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.update_transceiver_firmware_info_to_state_db', MagicMock(return_value=False))
    def test_firmware_download_with_existing_gold_firmware_failure(self):
        self.assertEqual(self.checkFail(['-p', 'Ethernet0', '-d', 'path', '-g', '1.2.1']), cmis_fwutil.ERROR_EXISTING_FW_DOWNLOAD_DB_UPDATE)
        assert cmis_fwutil.SonicPyAPIAndCommandsUtility.firmware_download.call_count == 0
        assert cmis_fwutil.SonicPyAPIAndCommandsUtility.set_port_dom_config.call_count == 2

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_non_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_transceiver_remote_side_fw_upgrade_support', MagicMock(return_value=(False, None)))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.is_transceiver_with_single_bank', MagicMock(return_value=False))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_value_from_db_by_field', MagicMock(side_effect=get_value_from_db_by_field_callback))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.set_port_dom_config', MagicMock(return_value=True))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_active_inactive_firmware_version_by_target', MagicMock(return_value=(("0.2.5", "1.2.1"))))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.firmware_download', MagicMock(return_value=(False, 'Test')))
    def test_execute_firmware_download_failure_after_max_attempts(self):
        self.assertEqual(self.checkFail(['-p', 'Ethernet0', '-d', 'path', '-g', '2.3.0']), cmis_fwutil.ERROR_FW_DOWNLOAD)
        assert cmis_fwutil.SonicPyAPIAndCommandsUtility.firmware_download.call_count == 3

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_non_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.is_transceiver_with_single_bank', MagicMock(return_value=False))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_transceiver_remote_side_fw_upgrade_support', MagicMock(return_value=(False, None)))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_value_from_db_by_field', MagicMock(side_effect=get_value_from_db_by_field_callback))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.set_port_dom_config', MagicMock(return_value=True))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_active_inactive_firmware_version_by_target', MagicMock(side_effect=(("0.2.5", "1.2.1"), ("0.2.5", "1.2.1"), ("1.2.1", "0.2.5"))))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.firmware_download', MagicMock(return_value=(True, 'Success')))
    def test_cmis_fwutil_download_gold_firmware_verification_failure(self):
        self.assertEqual(self.checkFail(['-p', 'Ethernet0', '-d', 'path', '-g', '2.2.1']), cmis_fwutil.ERROR_FW_DOWNLOAD_VERIFICATION)

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_non_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_transceiver_remote_side_fw_upgrade_support', MagicMock(return_value=(False, None)))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.is_transceiver_with_single_bank', MagicMock(return_value=False))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_value_from_db_by_field', MagicMock(side_effect=get_value_from_db_by_field_callback))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.set_port_dom_config', MagicMock(return_value=True))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_active_inactive_firmware_version_by_target', MagicMock(side_effect=(("0.2.5", "1.2.1"), ("0.2.5", "1.2.1"), ("1.2.1", "2.2.1"))))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.firmware_download', MagicMock(return_value=(True, 'Success')))
    def test_cmis_fwutil_download_success(self):
        self.assertEqual(self.checkPass(['-p', 'Ethernet0', '-d', 'path', '-g', '2.2.1']), 0)
        assert cmis_fwutil.SonicPyAPIAndCommandsUtility.firmware_download.call_count == 1

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_non_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_transceiver_remote_side_fw_upgrade_support', MagicMock(return_value=(False, None)))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.is_transceiver_with_single_bank', MagicMock(return_value=False))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_value_from_db_by_field', MagicMock(side_effect=get_value_from_db_by_field_callback))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.set_port_dom_config', MagicMock(return_value=True))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_active_inactive_firmware_version_by_target', MagicMock(return_value=(("1.2.1", "0.2.5"))))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.update_transceiver_firmware_info_to_state_db', MagicMock(return_value=True))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_interface_admin_status', MagicMock(return_value="down"))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.execute_interface_startup', MagicMock(return_value=True))
    @patch('cmis_fwutil.CMISFWUtilSingleTarget.shutdown_interface_and_verify_link_down', MagicMock(return_value=0))
    def test_cmis_fwutil_activate_with_existing_gold_firmware_and_port_originally_admin_down(self):
        self.assertEqual(self.checkPass(['-p', 'Ethernet0', '-a', '-g', '1.2.1']), 0)
        assert cmis_fwutil.CMISFWUtilSingleTarget.shutdown_interface_and_verify_link_down.call_count == 0
        assert cmis_fwutil.SonicPyAPIAndCommandsUtility.execute_interface_startup.call_count == 0

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_non_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_transceiver_remote_side_fw_upgrade_support', MagicMock(return_value=(False, None)))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.is_transceiver_with_single_bank', MagicMock(return_value=False))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_value_from_db_by_field', MagicMock(return_value='disabled'))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.set_port_dom_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.update_transceiver_firmware_info_to_state_db', MagicMock(return_value=True))
    @patch('cmis_fwutil.CMISFWUtilSingleTarget.execute_firmware_run_and_commit', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_active_inactive_firmware_version_by_target', MagicMock(return_value=(("1.2.1", "0.2.5"))))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_interface_admin_status', MagicMock(return_value="up"))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.execute_interface_startup', MagicMock(return_value=True))
    @patch('cmis_fwutil.CMISFWUtilSingleTarget.shutdown_interface_and_verify_link_down', MagicMock(return_value=0))
    def test_cmis_fwutil_activate_with_existing_gold_firmware_success_port_originally_dom_disable(self):
        self.assertEqual(self.checkPass(['-p', 'Ethernet0', '-a', '-g', '1.2.1']), 0)
        assert cmis_fwutil.CMISFWUtilSingleTarget.execute_firmware_run_and_commit.call_count == 0
        assert cmis_fwutil.CMISFWUtilSingleTarget.shutdown_interface_and_verify_link_down.call_count == 1
        assert cmis_fwutil.SonicPyAPIAndCommandsUtility.execute_interface_startup.call_count == 1
        assert cmis_fwutil.SonicPyAPIAndCommandsUtility.set_port_dom_config.call_count == 0

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_non_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_transceiver_remote_side_fw_upgrade_support', MagicMock(return_value=(False, None)))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.is_transceiver_with_single_bank', MagicMock(return_value=False))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_value_from_db_by_field', MagicMock(return_value='enabled'))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.set_port_dom_config', MagicMock(return_value=True))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.update_transceiver_firmware_info_to_state_db', MagicMock(return_value=False))
    @patch('cmis_fwutil.CMISFWUtilSingleTarget.execute_firmware_run_and_commit', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_active_inactive_firmware_version_by_target', MagicMock(return_value=(("1.2.1", "0.2.5"))))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_interface_admin_status', MagicMock(return_value="up"))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.execute_interface_startup', MagicMock(return_value=True))
    @patch('cmis_fwutil.CMISFWUtilSingleTarget.shutdown_interface_and_verify_link_down', MagicMock(return_value=0))
    def test_cmis_fwutil_activate_with_existing_gold_firmware_failure(self):
        self.assertEqual(self.checkFail(['-p', 'Ethernet0', '-a', '-g', '1.2.1']), cmis_fwutil.ERROR_EXISTING_FW_ACTIVATE_DB_UPDATE)
        assert cmis_fwutil.CMISFWUtilSingleTarget.execute_firmware_run_and_commit.call_count == 0
        assert cmis_fwutil.CMISFWUtilSingleTarget.shutdown_interface_and_verify_link_down.call_count == 1
        assert cmis_fwutil.SonicPyAPIAndCommandsUtility.execute_interface_startup.call_count == 1

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_non_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_transceiver_remote_side_fw_upgrade_support', MagicMock(return_value=(False, None)))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.is_transceiver_with_single_bank', MagicMock(return_value=False))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_value_from_db_by_field', MagicMock(side_effect=get_value_from_db_by_field_callback))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.set_port_dom_config', MagicMock(return_value=True))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_active_inactive_firmware_version_by_target', MagicMock(return_value=(("1.2.1", "0.2.5"))))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_interface_admin_status', MagicMock(return_value=None))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.execute_interface_startup', MagicMock(return_value=True))
    def test_cmis_fwutil_port_orig_admin_status_down_None(self):
        self.assertEqual(self.checkFail(['-p', 'Ethernet0', '-a', '-g', '2.3.0']), cmis_fwutil.ERROR_ADMIN_STATUS_CHECK)
        assert cmis_fwutil.SonicPyAPIAndCommandsUtility.execute_interface_startup.call_count == 0

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_non_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_transceiver_remote_side_fw_upgrade_support', MagicMock(return_value=(False, None)))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.is_transceiver_with_single_bank', MagicMock(return_value=False))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_value_from_db_by_field', MagicMock(side_effect=get_value_from_db_by_field_callback))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.set_port_dom_config', MagicMock(return_value=True))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_active_inactive_firmware_version_by_target', MagicMock(return_value=(("1.2.1", "0.2.5"))))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_interface_admin_status', MagicMock(return_value="up"))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.execute_interface_shutdown', MagicMock(return_value=False))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.execute_interface_startup', MagicMock(return_value=True))
    def test_cmis_fwutil_shutdown_interface_and_verify_link_down_False_error(self):
        self.assertEqual(self.checkFail(['-p', 'Ethernet0', '-a', '-g', '2.3.0']), cmis_fwutil.ERROR_SHUTDOWN_INTERFACE)
        assert cmis_fwutil.SonicPyAPIAndCommandsUtility.execute_interface_startup.call_count == 1

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_non_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_transceiver_remote_side_fw_upgrade_support', MagicMock(return_value=(False, None)))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.is_transceiver_with_single_bank', MagicMock(return_value=False))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_value_from_db_by_field', MagicMock(side_effect=get_value_from_db_by_field_callback))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.set_port_dom_config', MagicMock(return_value=True))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_active_inactive_firmware_version_by_target', MagicMock(return_value=(("1.2.1", "0.2.5"))))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_interface_admin_status', MagicMock(return_value="up"))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.execute_interface_shutdown', MagicMock(return_value=True))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.wait_until', MagicMock(return_value=False))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.execute_interface_startup', MagicMock(return_value=True))
    def test_cmis_fwutil_shutdown_interface_and_verify_link_down_failure(self):
        self.assertEqual(self.checkFail(['-p', 'Ethernet0', '-a', '-g', '2.3.0']), cmis_fwutil.ERROR_SHUTDOWN_INTERFACE_VERIFICATION)
        assert cmis_fwutil.SonicPyAPIAndCommandsUtility.execute_interface_startup.call_count == 1

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_non_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_transceiver_remote_side_fw_upgrade_support', MagicMock(return_value=(False, None)))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.is_transceiver_with_single_bank', MagicMock(return_value=False))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_value_from_db_by_field', MagicMock(side_effect=get_value_from_db_by_field_callback))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.set_port_dom_config', MagicMock(return_value=True))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_active_inactive_firmware_version_by_target', MagicMock(return_value=(("1.2.1", "0.2.5"))))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_interface_admin_status', MagicMock(return_value="up"))
    @patch('cmis_fwutil.CMISFWUtilSingleTarget.shutdown_interface_and_verify_link_down', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.firmware_run', MagicMock(return_value=(True, None)))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.execute_interface_startup', MagicMock(return_value=True))
    def test_cmis_fwutil_inactive_firmware_not_gold_firmware(self):
        self.assertEqual(self.checkFail(['-p', 'Ethernet0', '-a', '-g', '2.3.0']), cmis_fwutil.ERROR_INACTIVE_FW_NOT_GOLD_FW)
        assert cmis_fwutil.CMISFWUtilSingleTarget.shutdown_interface_and_verify_link_down.call_count == 1
        assert cmis_fwutil.SonicPyAPIAndCommandsUtility.execute_interface_startup.call_count == 1

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_non_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_transceiver_remote_side_fw_upgrade_support', MagicMock(return_value=(False, None)))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.is_transceiver_with_single_bank', MagicMock(return_value=False))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_value_from_db_by_field', MagicMock(side_effect=get_value_from_db_by_field_callback))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.set_port_dom_config', MagicMock(return_value=True))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_active_inactive_firmware_version_by_target', MagicMock(return_value=(("1.2.1", "0.2.5"))))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_interface_admin_status', MagicMock(return_value="down"))
    @patch('cmis_fwutil.CMISFWUtilSingleTarget.shutdown_interface_and_verify_link_down', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.firmware_run', MagicMock(return_value=(False, 'Failed')))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.execute_interface_startup', MagicMock(return_value=True))
    def test_cmis_fwutil_run_failure(self):
        self.assertEqual(self.checkFail(['-p', 'Ethernet0', '-a', '-g', '0.2.5']), cmis_fwutil.ERROR_FIRMWARE_RUN)
        assert cmis_fwutil.SonicPyAPIAndCommandsUtility.execute_interface_startup.call_count == 0


    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_non_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_transceiver_remote_side_fw_upgrade_support', MagicMock(return_value=(False, None)))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.is_transceiver_with_single_bank', MagicMock(return_value=False))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_value_from_db_by_field', MagicMock(side_effect=get_value_from_db_by_field_callback))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.set_port_dom_config', MagicMock(return_value=True))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_active_inactive_firmware_version_by_target', MagicMock(return_value=(("1.2.1", "0.2.5"))))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_interface_admin_status', MagicMock(return_value="up"))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.execute_interface_startup', MagicMock(return_value=False))
    @patch('cmis_fwutil.CMISFWUtilSingleTarget.shutdown_interface_and_verify_link_down', MagicMock(return_value=0))
    def test_cmis_fwutil_run_startup_failure(self):
        self.assertEqual(self.checkFail(['-p', 'Ethernet0', '-a', '-g', '2.3.0']), cmis_fwutil.ERROR_STARTUP_INTERFACE)
        assert cmis_fwutil.SonicPyAPIAndCommandsUtility.execute_interface_startup.call_count == 1

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_non_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_transceiver_remote_side_fw_upgrade_support', MagicMock(return_value=(False, None)))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.is_transceiver_with_single_bank', MagicMock(return_value=False))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_value_from_db_by_field', MagicMock(side_effect=get_value_from_db_by_field_callback))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.set_port_dom_config', MagicMock(return_value=True))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_active_inactive_firmware_version_by_target', MagicMock(return_value=(("1.2.1", "0.2.5"))))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_interface_admin_status', MagicMock(return_value="down"))
    @patch('cmis_fwutil.CMISFWUtilSingleTarget.shutdown_interface_and_verify_link_down', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.firmware_run', MagicMock(side_effect=[(False, 'Failed'), (False, 'Failed'), (True, "Success")]))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.firmware_commit', MagicMock(return_value=(False, 'Failed')))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.execute_interface_startup', MagicMock(return_value=False))
    def test_cmis_fwutil_commit_failure(self):
        self.assertEqual(self.checkFail(['-p', 'Ethernet0', '-a', '-g', '0.2.5']), cmis_fwutil.ERROR_FIRMWARE_COMMIT)
        assert cmis_fwutil.SonicPyAPIAndCommandsUtility.firmware_run.call_count == cmis_fwutil.MAX_FIRMWARE_RUN_ATTEMPTS
        assert cmis_fwutil.SonicPyAPIAndCommandsUtility.execute_interface_startup.call_count == 0

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_non_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_value_from_db_by_field', MagicMock(side_effect=get_value_from_db_by_field_callback))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.set_port_dom_config', MagicMock(return_value=True))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_transceiver_remote_side_fw_upgrade_support', MagicMock(return_value=(False, None)))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.is_transceiver_with_single_bank', MagicMock(return_value=False))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_interface_admin_status', MagicMock(return_value="up"))
    @patch('cmis_fwutil.CMISFWUtilSingleTarget.shutdown_interface_and_verify_link_down', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_active_inactive_firmware_version_by_target', MagicMock(side_effect=(("0.2.5", "1.2.1"), ("0.2.5", "1.2.1"), ("0.2.5", "1.2.1"))))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.firmware_run', MagicMock(return_value=(True, "Success")))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.firmware_commit', MagicMock(return_value=(True, "Success")))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.execute_interface_startup', MagicMock(return_value=True))
    def test_cmis_fwutil_gold_firmware_verification_failure(self):
        self.assertEqual(self.checkFail(['-p', 'Ethernet0', '-a', '-g', '1.2.1']), cmis_fwutil.ERROR_FW_ACTIVATE_VERIFICATION)
        assert cmis_fwutil.SonicPyAPIAndCommandsUtility.firmware_run.call_count == 1
        assert cmis_fwutil.SonicPyAPIAndCommandsUtility.firmware_commit.call_count == 1
        assert cmis_fwutil.SonicPyAPIAndCommandsUtility.execute_interface_startup.call_count == 1

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_non_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_transceiver_remote_side_fw_upgrade_support', MagicMock(return_value=(False, None)))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.is_transceiver_with_single_bank', MagicMock(return_value=False))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_value_from_db_by_field', MagicMock(side_effect=get_value_from_db_by_field_callback))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.set_port_dom_config', MagicMock(return_value=True))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_interface_admin_status', MagicMock(return_value="up"))
    @patch('cmis_fwutil.CMISFWUtilSingleTarget.shutdown_interface_and_verify_link_down', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.firmware_run', MagicMock(return_value=(True, "Success")))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.firmware_commit', MagicMock(side_effect=[(False, 'Failed'), (False, 'Failed'), (True, "Success")]))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_active_inactive_firmware_version_by_target', MagicMock(side_effect=(("0.2.5", "2.3.0"), ("0.2.5", "2.3.0"), ("2.3.0", "0.2.5"))))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.execute_sfputil_reset', MagicMock(return_value=(False)))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.execute_interface_startup', MagicMock(return_value=True))
    def test_cmis_fwutil_reset_failure(self):
        self.assertEqual(self.checkFail(['-p', 'Ethernet0', '-a', '-g', '2.3.0']), cmis_fwutil.ERROR_SFPUTIL_RESET)
        assert cmis_fwutil.SonicPyAPIAndCommandsUtility.firmware_run.call_count == 1
        assert cmis_fwutil.SonicPyAPIAndCommandsUtility.firmware_commit.call_count == cmis_fwutil.MAX_FIRMWARE_COMMIT_ATTEMPTS
        assert cmis_fwutil.SonicPyAPIAndCommandsUtility.execute_interface_startup.call_count == 1

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_non_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_transceiver_remote_side_fw_upgrade_support', MagicMock(return_value=(False, None)))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.is_transceiver_with_single_bank', MagicMock(return_value=False))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.is_transceiver_with_single_bank', MagicMock(return_value=False))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_value_from_db_by_field', MagicMock(side_effect=get_value_from_db_by_field_callback))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.set_port_dom_config', MagicMock(return_value=True))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_interface_admin_status', MagicMock(return_value="up"))
    @patch('cmis_fwutil.CMISFWUtilSingleTarget.shutdown_interface_and_verify_link_down', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.firmware_run', MagicMock(return_value=(True, "Success")))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.firmware_commit', MagicMock(return_value=(True, "Success")))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_active_inactive_firmware_version_by_target', MagicMock(side_effect=(("0.2.5", "2.3.0"), ("0.2.5", "2.3.0"), ("2.3.0", "0.2.5"))))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.execute_sfputil_reset', MagicMock(return_value=True))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.execute_interface_startup', MagicMock(return_value=False))
    def test_cmis_fwutil_startup_failure(self):
        self.assertEqual(self.checkFail(['-p', 'Ethernet0', '-a', '-g', '2.3.0']), cmis_fwutil.ERROR_STARTUP_INTERFACE)

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_non_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_transceiver_remote_side_fw_upgrade_support', MagicMock(return_value=(False, None)))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.is_transceiver_with_single_bank', MagicMock(return_value=False))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_value_from_db_by_field', MagicMock(side_effect=get_value_from_db_by_field_callback))
    @patch('cmis_fwutil.CMISFWUtilSingleTarget.shutdown_interface_and_verify_link_down', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.set_port_dom_config', MagicMock(return_value=True))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_interface_admin_status', MagicMock(return_value="up"))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.firmware_run', MagicMock(return_value=(True, "Success")))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.firmware_commit', MagicMock(return_value=(True, "Success")))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_active_inactive_firmware_version_by_target', MagicMock(side_effect=(("0.2.5", "2.3.0"), ("0.2.5", "2.3.0"), ("2.3.0", "0.2.5"))))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.execute_sfputil_reset', MagicMock(return_value=True))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.execute_interface_startup', MagicMock(return_value=True))
    def test_cmis_fwutil_activate_success(self):
        self.assertEqual(self.checkPass(['-p', 'Ethernet0', '-a', '-g', '2.3.0']), 0)

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_non_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_transceiver_remote_side_fw_upgrade_support', MagicMock(return_value=(False, None)))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.is_transceiver_with_single_bank', MagicMock(return_value=True))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_value_from_db_by_field', MagicMock(side_effect=get_value_from_db_by_field_callback))
    @patch('cmis_fwutil.CMISFWUtilSingleTarget.shutdown_interface_and_verify_link_down', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.set_port_dom_config', MagicMock(return_value=True))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_interface_admin_status', MagicMock(return_value="up"))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.run_command', MagicMock(side_effect=((0, "Firmware run in mode=0 success".encode("utf-8"), ""), (0, "Firmware commit successful".encode("utf-8"), ""))))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_image_bank_by_field', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_active_inactive_firmware_version_by_target', MagicMock(side_effect=(("0.2.5", "2.3.0"), ("0.2.5", "2.3.0"), ("2.3.0", "0.2.5"))))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.execute_sfputil_reset', MagicMock(return_value=True))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.execute_interface_startup', MagicMock(return_value=True))
    def test_cmis_fwutil_activate_success_single_bank(self):
        self.assertEqual(self.checkPass(['-p', 'Ethernet0', '-a', '-g', '2.3.0']), 0)
        assert cmis_fwutil.SonicPyAPIAndCommandsUtility.get_image_bank_by_field.call_count == 0

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_non_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_transceiver_remote_side_fw_upgrade_support', MagicMock(return_value=(False, None)))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.is_transceiver_with_single_bank', MagicMock(return_value=True))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_value_from_db_by_field', MagicMock(side_effect=["", "DEF8504-2C12-MB3"]))
    @patch('cmis_fwutil.CMISFWUtilSingleTarget.shutdown_interface_and_verify_link_down', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.set_port_dom_config', MagicMock(return_value=True))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_interface_admin_status', MagicMock(return_value="up"))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.run_command', MagicMock(side_effect=((0, "Firmware run in mode=0 success".encode("utf-8"), ""), (0, "Firmware commit successful".encode("utf-8"), ""))))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_image_bank_by_field', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_active_inactive_firmware_version_by_target', MagicMock(side_effect=(("0.2.5", "2.3.0"), ("0.2.5", "2.3.0"), ("2.3.0", "0.2.5"))))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.execute_sfputil_reset', MagicMock(return_value=True))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.execute_interface_startup', MagicMock(return_value=True))
    def test_cmis_fwutil_activate_success_single_bank_with_optoe_write_timeout_required(self):
        self.assertEqual(self.checkPass(['-p', 'Ethernet0', '-a', '-g', '2.3.0']), 0)
        assert cmis_fwutil.SonicPyAPIAndCommandsUtility.get_image_bank_by_field.call_count == 0

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_non_port_related_prerequisites', MagicMock(return_value=cmis_fwutil.ERROR_PRE_REQ_OS_CHECK))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_value_from_db_by_field', MagicMock(return_value=None))
    def test_cmis_fwutil_get_active_firmware_version_prerequisite_failure(self):
        return_value, cmd_output = self.checkFailAndGetOutput(['-p', 'Ethernet0', '-n'])
        self.assertEqual(return_value, cmis_fwutil.ERROR_PRE_REQ_OS_CHECK)
        self.assertEqual(cmd_output, cmis_fwutil.INVALID_FW_VERSION)
        assert cmis_fwutil.SonicPyAPIAndCommandsUtility.get_value_from_db_by_field.call_count == 0

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_non_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_transceiver_remote_side_fw_upgrade_support', MagicMock(return_value=(False, None)))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.is_transceiver_with_single_bank', MagicMock(return_value=False))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_value_from_db_by_field', MagicMock(return_value=None))
    def test_cmis_fwutil_get_active_firmware_version_None_failure(self):
        return_value, cmd_output = self.checkFailAndGetOutput(['-p', 'Ethernet0', '-n'])
        self.assertEqual(return_value, cmis_fwutil.ERROR_GET_FW_VERSION)
        self.assertEqual(cmd_output, cmis_fwutil.INVALID_FW_VERSION)
        assert cmis_fwutil.SonicPyAPIAndCommandsUtility.get_value_from_db_by_field.call_count == cmis_fwutil.MAX_GET_FW_VERSION_ATTEMPTS

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_non_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.is_transceiver_with_single_bank', MagicMock(return_value=False))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_transceiver_remote_side_fw_upgrade_support', MagicMock(return_value=(False, None)))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_value_from_db_by_field', MagicMock(side_effect=(None, "1.2.1")))
    def test_cmis_fwutil_get_active_firmware_version_success_second_attempt(self):
        return_value, cmd_output = self.checkPassAndGetOutput(['-p', 'Ethernet0', '-n'])
        self.assertEqual(return_value, 0)
        self.assertEqual(cmd_output, "1.2.1")
        assert cmis_fwutil.SonicPyAPIAndCommandsUtility.get_value_from_db_by_field.call_count == 2

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_non_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_transceiver_remote_side_fw_upgrade_support', MagicMock(return_value=(False, None)))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.is_transceiver_with_single_bank', MagicMock(return_value=False))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_value_from_db_by_field', MagicMock(return_value=("1.2.1")))
    def test_cmis_fwutil_get_active_firmware_version_success_first_attempt(self):
        return_value, cmd_output = self.checkPassAndGetOutput(['-p', 'Ethernet0', '-n'])
        self.assertEqual(return_value, 0)
        self.assertEqual(cmd_output, "1.2.1")
        assert cmis_fwutil.SonicPyAPIAndCommandsUtility.get_value_from_db_by_field.call_count == 1

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_non_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_port_related_prerequisites', MagicMock(return_value=cmis_fwutil.ERROR_PRE_REQ_FWUPGRADE_SUPPORT))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_transceiver_remote_side_fw_upgrade_support', MagicMock(return_value=(False, None)))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_value_from_db_by_field', MagicMock(return_value=None))
    def test_cmis_fwutil_get_inactive_firmware_version_prerequisite_failure(self):
        return_value, cmd_output = self.checkFailAndGetOutput(['-p', 'Ethernet0', '-o'])
        self.assertEqual(return_value, cmis_fwutil.ERROR_PRE_REQ_FWUPGRADE_SUPPORT)
        self.assertEqual(cmd_output, cmis_fwutil.INVALID_FW_VERSION)
        assert cmis_fwutil.SonicPyAPIAndCommandsUtility.get_value_from_db_by_field.call_count == 0

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_non_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_transceiver_remote_side_fw_upgrade_support', MagicMock(return_value=(False, None)))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.is_transceiver_with_single_bank', MagicMock(return_value=False))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_value_from_db_by_field', MagicMock(return_value=None))
    def test_cmis_fwutil_get_inactive_firmware_version_None_failure(self):
        return_value, cmd_output = self.checkFailAndGetOutput(['-p', 'Ethernet0', '-o'])
        self.assertEqual(return_value, cmis_fwutil.ERROR_GET_FW_VERSION)
        self.assertEqual(cmd_output, cmis_fwutil.INVALID_FW_VERSION)
        assert cmis_fwutil.SonicPyAPIAndCommandsUtility.get_value_from_db_by_field.call_count == cmis_fwutil.MAX_GET_FW_VERSION_ATTEMPTS

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_non_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_transceiver_remote_side_fw_upgrade_support', MagicMock(return_value=(False, None)))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.is_transceiver_with_single_bank', MagicMock(return_value=False))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_value_from_db_by_field', MagicMock(side_effect=(None, None, "1.2.1")))
    def test_cmis_fwutil_get_inactive_firmware_version_success_third_attempt(self):
        return_value, cmd_output = self.checkPassAndGetOutput(['-p', 'Ethernet0', '-o'])
        self.assertEqual(return_value, 0)
        self.assertEqual(cmd_output, "1.2.1")
        assert cmis_fwutil.SonicPyAPIAndCommandsUtility.get_value_from_db_by_field.call_count == 3

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_non_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_transceiver_remote_side_fw_upgrade_support', MagicMock(return_value=(False, None)))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.is_transceiver_with_single_bank', MagicMock(return_value=False))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_value_from_db_by_field', MagicMock(return_value=("1.2.1")))
    def test_cmis_fwutil_get_inactive_firmware_version_success_first_attempt(self):
        return_value, cmd_output = self.checkPassAndGetOutput(['-p', 'Ethernet0', '-o'])
        self.assertEqual(return_value, 0)
        self.assertEqual(cmd_output, "1.2.1")
        assert cmis_fwutil.SonicPyAPIAndCommandsUtility.get_value_from_db_by_field.call_count == 1

class CMISFWUtilMultiTargetTest(TestBase):
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_non_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.is_transceiver_present', MagicMock(return_value=True))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.is_transceiver_cmis_compliant', MagicMock(return_value=True))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_transceiver_remote_side_fw_upgrade_support', MagicMock(return_value=(True, cmis_fwutil.DEFAULT_TARGET_LIST)))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_value_from_db_by_field', MagicMock(side_effect=get_value_from_db_by_field_callback))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.set_port_dom_config', MagicMock(return_value=True))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_active_inactive_firmware_version_by_target', MagicMock(return_value=(("0.2.5", "1.2.1"))))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.firmware_download', MagicMock(return_value=(False, None)))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.update_transceiver_firmware_info_to_state_db', MagicMock(return_value=True))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.set_firmware_target')
    def test_firmware_download_with_existing_gold_firmware_success_ntargets(self, mock_set_firmware_target):
        self.assertEqual(self.checkPass(['-p', 'Ethernet0', '-d', 'path', '-g', '1.2.1']), 0)
        mock_set_firmware_target.return_value = True
        assert mock_set_firmware_target.call_args[0][0] == 0
        assert cmis_fwutil.SonicPyAPIAndCommandsUtility.firmware_download.call_count == 0
        assert cmis_fwutil.SonicPyAPIAndCommandsUtility.set_port_dom_config.call_count == 2
        assert cmis_fwutil.SonicPyAPIAndCommandsUtility.update_transceiver_firmware_info_to_state_db.call_count == 3

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_non_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.is_transceiver_present', MagicMock(return_value=True))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.is_transceiver_cmis_compliant', MagicMock(return_value=True))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_transceiver_remote_side_fw_upgrade_support', MagicMock(return_value=(True, cmis_fwutil.DEFAULT_TARGET_LIST)))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_value_from_db_by_field', MagicMock(side_effect=get_value_from_db_by_field_callback))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.set_port_dom_config', MagicMock(return_value=True))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_active_inactive_firmware_version_by_target', MagicMock(return_value=(("0.2.5", "1.2.1"))))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.firmware_download', MagicMock(return_value=(False, None)))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.update_transceiver_firmware_info_to_state_db', MagicMock(side_effect=[True, False]))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.set_firmware_target')
    def test_firmware_download_with_existing_gold_firmware_failure(self, mock_set_firmware_target):
        self.assertEqual(self.checkFail(['-p', 'Ethernet0', '-d', 'path', '-g', '1.2.1']), cmis_fwutil.ERROR_EXISTING_FW_DOWNLOAD_DB_UPDATE)
        mock_set_firmware_target.return_value = True
        assert mock_set_firmware_target.call_args[0][0] == 0
        assert cmis_fwutil.SonicPyAPIAndCommandsUtility.firmware_download.call_count == 0
        assert cmis_fwutil.SonicPyAPIAndCommandsUtility.set_port_dom_config.call_count == 2
        assert cmis_fwutil.SonicPyAPIAndCommandsUtility.update_transceiver_firmware_info_to_state_db.call_count == 2

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_non_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_transceiver_remote_side_fw_upgrade_support', MagicMock(return_value=(True, cmis_fwutil.DEFAULT_TARGET_LIST)))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_value_from_db_by_field', MagicMock(side_effect=get_value_from_db_by_field_callback))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.set_port_dom_config', MagicMock(return_value=True))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_active_inactive_firmware_version_by_target', MagicMock(return_value=(("0.2.5", "1.2.1"))))
    @patch('cmis_fwutil.CMISFWUtilSingleTarget.execute_firmware_download')
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.set_firmware_target')
    def test_execute_firmware_download_failure_e1(self, mock_set_firmware_target, mock_execute_firmware_download):
        mock_execute_firmware_download.side_effect = [0, cmis_fwutil.ERROR_FW_DOWNLOAD, cmis_fwutil.ERROR_FW_DOWNLOAD, cmis_fwutil.ERROR_FW_DOWNLOAD]
        self.assertEqual(self.checkFail(['-p', 'Ethernet0', '-d', 'path', '-g', '2.3.0']), cmis_fwutil.ERROR_FW_DOWNLOAD)
        mock_set_firmware_target.return_value = True
        assert mock_set_firmware_target.call_args[0][0] == cmis_fwutil.LOCAL_SIDE_FW_UPGRADE_TARGET
        assert mock_execute_firmware_download.call_count == 2
        assert cmis_fwutil.SonicPyAPIAndCommandsUtility.set_port_dom_config.call_count == 2

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_non_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_transceiver_remote_side_fw_upgrade_support', MagicMock(return_value=(True, cmis_fwutil.DEFAULT_TARGET_LIST)))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_value_from_db_by_field', MagicMock(side_effect=get_value_from_db_by_field_callback))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.set_port_dom_config', MagicMock(return_value=True))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_active_inactive_firmware_version_by_target', MagicMock(return_value=(("1.2.1", "0.2.5"))))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.update_transceiver_firmware_info_to_state_db', MagicMock(return_value=True))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_interface_admin_status', MagicMock(return_value="up"))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.execute_interface_startup', MagicMock(return_value=True))
    @patch('cmis_fwutil.CMISFWUtilSingleTarget.execute_firmware_run_and_commit', MagicMock(side_effect=[0, cmis_fwutil.ERROR_EXISTING_FW_RUN_AND_COMMIT_DB_UPDATE]))
    @patch('cmis_fwutil.CMISFWUtilSingleTarget.shutdown_interface_and_verify_link_down', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.set_firmware_target')
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.is_cmis_sm_in_terminal_state', AsyncMock(side_effect=['INSERTED', 'READY']))
    def test_cmis_fwutil_activate_failure_e1(self, mock_set_firmware_target):
        self.assertEqual(self.checkFail(['-p', 'Ethernet0', '-a', '-g', '1.2.1']), cmis_fwutil.ERROR_EXISTING_FW_RUN_AND_COMMIT_DB_UPDATE)
        mock_set_firmware_target.return_value = True
        assert mock_set_firmware_target.call_args[0][0] == 0
        assert cmis_fwutil.SonicPyAPIAndCommandsUtility.is_cmis_sm_in_terminal_state.call_count == 1
        assert cmis_fwutil.CMISFWUtilSingleTarget.shutdown_interface_and_verify_link_down.call_count == 0
        assert cmis_fwutil.SonicPyAPIAndCommandsUtility.execute_interface_startup.call_count == 0
        assert cmis_fwutil.SonicPyAPIAndCommandsUtility.set_port_dom_config.call_count == 2

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_non_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_transceiver_remote_side_fw_upgrade_support', MagicMock(return_value=(True, cmis_fwutil.DEFAULT_TARGET_LIST)))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_value_from_db_by_field', MagicMock(side_effect=get_value_from_db_by_field_callback))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.set_port_dom_config', MagicMock(return_value=True))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_active_inactive_firmware_version_by_target', MagicMock(return_value=(("1.2.1", "0.2.5"))))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.update_transceiver_firmware_info_to_state_db', MagicMock(return_value=True))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_interface_admin_status', MagicMock(return_value="up"))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.execute_interface_startup', MagicMock(return_value=True))
    @patch('cmis_fwutil.CMISFWUtilSingleTarget.shutdown_interface_and_verify_link_down', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.set_firmware_target')
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.is_cmis_sm_in_terminal_state', AsyncMock(side_effect=['INSERTED', 'READY']))
    def test_cmis_fwutil_inactive_fw_not_gold_e1(self, mock_set_firmware_target):
        self.assertEqual(self.checkFail(['-p', 'Ethernet0', '-a', '-g', '3.2.1']), cmis_fwutil.ERROR_INACTIVE_FW_NOT_GOLD_FW)
        mock_set_firmware_target.return_value = True
        assert mock_set_firmware_target.call_args[0][0] == 0
        assert cmis_fwutil.SonicPyAPIAndCommandsUtility.is_cmis_sm_in_terminal_state.call_count == 1
        assert cmis_fwutil.CMISFWUtilSingleTarget.shutdown_interface_and_verify_link_down.call_count == 0
        assert cmis_fwutil.SonicPyAPIAndCommandsUtility.execute_interface_startup.call_count == 0
        assert cmis_fwutil.SonicPyAPIAndCommandsUtility.set_port_dom_config.call_count == 2

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_non_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_transceiver_remote_side_fw_upgrade_support', MagicMock(return_value=(True, cmis_fwutil.DEFAULT_TARGET_LIST)))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_value_from_db_by_field', MagicMock(side_effect=get_value_from_db_by_field_callback))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.set_port_dom_config', MagicMock(return_value=True))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_active_inactive_firmware_version_by_target', MagicMock(return_value=(("1.2.1", "0.2.5"))))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.update_transceiver_firmware_info_to_state_db', MagicMock(return_value=True))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_interface_admin_status', MagicMock(return_value="up"))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.execute_interface_startup', MagicMock(return_value=False))
    @patch('cmis_fwutil.CMISFWUtilSingleTarget.execute_firmware_run_and_commit', MagicMock(return_value=0))
    @patch('cmis_fwutil.CMISFWUtilSingleTarget.shutdown_interface_and_verify_link_down', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.set_firmware_target')
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.is_cmis_sm_in_terminal_state', AsyncMock(side_effect=['INSERTED', 'READY']))
    def test_cmis_fwutil_activate_interface_startup_failure(self, mock_set_firmware_target):
        self.assertEqual(self.checkFail(['-p', 'Ethernet0', '-a', '-g', '1.2.1']), cmis_fwutil.ERROR_STARTUP_INTERFACE)
        mock_set_firmware_target.return_value = True
        assert mock_set_firmware_target.call_args[0][0] == 0
        assert cmis_fwutil.SonicPyAPIAndCommandsUtility.is_cmis_sm_in_terminal_state.call_count == 1
        assert cmis_fwutil.CMISFWUtilSingleTarget.shutdown_interface_and_verify_link_down.call_count == 1
        assert cmis_fwutil.SonicPyAPIAndCommandsUtility.execute_interface_startup.call_count == 1
        assert cmis_fwutil.SonicPyAPIAndCommandsUtility.set_port_dom_config.call_count == 2

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_non_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_transceiver_remote_side_fw_upgrade_support', MagicMock(return_value=(True, cmis_fwutil.DEFAULT_TARGET_LIST)))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_value_from_db_by_field', MagicMock(side_effect=get_value_from_db_by_field_callback))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.set_port_dom_config', MagicMock(return_value=True))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_active_inactive_firmware_version_by_target', MagicMock(return_value=(("1.2.1", "0.2.5"))))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.update_transceiver_firmware_info_to_state_db', MagicMock(return_value=True))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_interface_admin_status', MagicMock(return_value="up"))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.execute_interface_startup', MagicMock(return_value=True))
    @patch('cmis_fwutil.CMISFWUtilSingleTarget.execute_firmware_run_and_commit', MagicMock(side_effect=[0, 0, KeyError]))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.is_cmis_sm_in_terminal_state', AsyncMock(side_effect=['INSERTED', 'READY']))
    @patch('cmis_fwutil.CMISFWUtilSingleTarget.shutdown_interface_and_verify_link_down', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.set_firmware_target')
    def test_cmis_fwutil_activate_exception_e0_failure(self, mock_set_firmware_target):
        self.assertEqual(self.checkFail(['-p', 'Ethernet0', '-a', '-g', '0.2.5']), cmis_fwutil.ERROR_TARGET_FW_ACTIVATE_EXCEPTION)
        mock_set_firmware_target.return_value = True
        assert mock_set_firmware_target.call_args[0][0] == 0
        assert cmis_fwutil.SonicPyAPIAndCommandsUtility.is_cmis_sm_in_terminal_state.call_count == 1
        assert cmis_fwutil.CMISFWUtilSingleTarget.shutdown_interface_and_verify_link_down.call_count == 1
        assert cmis_fwutil.SonicPyAPIAndCommandsUtility.execute_interface_startup.call_count == 1
        assert cmis_fwutil.SonicPyAPIAndCommandsUtility.set_port_dom_config.call_count == 2

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_non_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_transceiver_remote_side_fw_upgrade_support', MagicMock(return_value=(True, cmis_fwutil.DEFAULT_TARGET_LIST)))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_value_from_db_by_field', MagicMock(side_effect=get_value_from_db_by_field_callback))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.set_port_dom_config', MagicMock(return_value=True))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_active_inactive_firmware_version_by_target', MagicMock(return_value=(("1.2.1", "0.2.5"))))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.update_transceiver_firmware_info_to_state_db', MagicMock(return_value=True))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_interface_admin_status', MagicMock(return_value="down"))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.execute_interface_startup', MagicMock(return_value=True))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.is_cmis_sm_in_terminal_state', AsyncMock(side_effect=['INSERTED', 'READY']))
    @patch('cmis_fwutil.CMISFWUtilSingleTarget.shutdown_interface_and_verify_link_down', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.set_firmware_target')
    def test_cmis_fwutil_activate_with_existing_gold_firmware_and_port_originally_admin_down_ntargets(self, mock_set_firmware_target):
        self.assertEqual(self.checkPass(['-p', 'Ethernet0', '-a', '-g', '1.2.1']), 0)
        mock_set_firmware_target.return_value = True
        assert mock_set_firmware_target.call_args[0][0] == 0
        assert cmis_fwutil.CMISFWUtilSingleTarget.shutdown_interface_and_verify_link_down.call_count == 0
        assert cmis_fwutil.SonicPyAPIAndCommandsUtility.execute_interface_startup.call_count == 0
        assert cmis_fwutil.SonicPyAPIAndCommandsUtility.set_port_dom_config.call_count == 2

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_non_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_transceiver_remote_side_fw_upgrade_support', MagicMock(return_value=(False, None)))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.is_transceiver_with_single_bank', MagicMock(return_value=False))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_value_from_db_by_field', MagicMock(return_value=("")))
    def test_cmis_fwutil_get_active_firmware_version_empty_db(self):
        return_value, cmd_output = self.checkFailAndGetOutput(['-p', 'Ethernet0', '-n'])
        self.assertEqual(return_value, cmis_fwutil.ERROR_GET_FW_VERSION)
        self.assertEqual(cmd_output, cmis_fwutil.INVALID_FW_VERSION)
        assert cmis_fwutil.SonicPyAPIAndCommandsUtility.get_value_from_db_by_field.call_count == 3

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_non_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_transceiver_remote_side_fw_upgrade_support', MagicMock(return_value=(True, cmis_fwutil.DEFAULT_TARGET_LIST)))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_value_from_db_by_field', MagicMock(return_value=("1.2.1")))
    def test_cmis_fwutil_get_active_firmware_version_success_first_attempt_ntargets(self):
        return_value, cmd_output = self.checkPassAndGetOutput(['-p', 'Ethernet0', '-n'])
        self.assertEqual(return_value, 0)
        self.assertEqual(cmd_output, "1.2.1")
        assert cmis_fwutil.SonicPyAPIAndCommandsUtility.get_value_from_db_by_field.call_count == 3

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_non_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_transceiver_remote_side_fw_upgrade_support', MagicMock(return_value=(True, cmis_fwutil.DEFAULT_TARGET_LIST)))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_value_from_db_by_field', MagicMock(side_effect=["1.2.1", "2.1.1", "1.2.1"]))
    def test_cmis_fwutil_get_active_firmware_2_targets_with_different_version_ntargets(self):
        return_value, cmd_output = self.checkFailAndGetOutput(['-p', 'Ethernet0', '-n'])
        self.assertEqual(return_value, cmis_fwutil.ERROR_GET_FW_VERSION)
        self.assertEqual(cmd_output, cmis_fwutil.INVALID_FW_VERSION)
        assert cmis_fwutil.SonicPyAPIAndCommandsUtility.get_value_from_db_by_field.call_count == 3

    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.load_port_config', MagicMock())
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_pport', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_first_lport_of_pport', MagicMock(return_value="Ethernet0"))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_non_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.CMISFWUtilFactory._verify_port_related_prerequisites', MagicMock(return_value=0))
    @patch('cmis_fwutil.SonicPyAPIXcvrUtility.get_transceiver_remote_side_fw_upgrade_support', MagicMock(return_value=(True, cmis_fwutil.DEFAULT_TARGET_LIST)))
    @patch('cmis_fwutil.SonicPyAPIAndCommandsUtility.get_value_from_db_by_field', MagicMock(return_value=("")))
    def test_cmis_fwutil_get_active_firmware_version_empty_db_ntargets(self):
        return_value, cmd_output = self.checkFailAndGetOutput(['-p', 'Ethernet0', '-n'])
        self.assertEqual(return_value, cmis_fwutil.ERROR_GET_FW_VERSION)
        self.assertEqual(cmd_output, cmis_fwutil.INVALID_FW_VERSION)
        assert cmis_fwutil.SonicPyAPIAndCommandsUtility.get_value_from_db_by_field.call_count == 3

if __name__ == '__main__':
    unittest.main()
