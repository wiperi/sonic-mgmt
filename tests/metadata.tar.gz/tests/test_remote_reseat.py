import asyncio
import time
import pytest
import os
import sys
import unittest
from unittest.mock import AsyncMock, patch, MagicMock

sys.path.insert( 0, '..' )
sys.modules['sonic_py_common'] = MagicMock()
sys.modules['utilities_common'] = MagicMock()
time.sleep = MagicMock()
import remote_reseat

SHOW_INTERFACE_STATUS_OUTPUT = """\
  Interface                Lanes    Speed    MTU    FEC    Alias    Vlan    Oper    Admin                                             Type    Asym PFC
-----------  -------------------  -------  -----  -----  -------  ------  ------  -------  -----------------------------------------------  ----------
  Ethernet0  2048,2049,2050,2051     400G   9100    N/A    etp0a  routed      down       up  QSFP-DD Double Density 8X Pluggable Transceiver         off""".encode("utf-8")

SHOW_INTERFACE_STATUS_OPER_UP_OUTPUT = """\
  Interface                Lanes    Speed    MTU    FEC    Alias    Vlan    Oper    Admin                                             Type    Asym PFC
-----------  -------------------  -------  -----  -----  -------  ------  ------  -------  -----------------------------------------------  ----------
  Ethernet0  2048,2049,2050,2051     400G   9100    N/A    etp0a  routed      up       up  QSFP-DD Double Density 8X Pluggable Transceiver         off""".encode("utf-8")

SFPUTIL_SHOW_PRESENCE_OUTPUT = """\
Port       Presence
---------  ----------
Ethernet0  Present""".encode("utf-8")

SFPUTIL_SHOW_EEPROM_OUTPUT = """\
Ethernet32: SFP EEPROM detected
        Active App Selection Host Lane 1: 3
        Active App Selection Host Lane 2: 3
        Active App Selection Host Lane 3: 3
        Active App Selection Host Lane 4: 3
        Active App Selection Host Lane 5: 1
        Active App Selection Host Lane 6: 1
        Active App Selection Host Lane 7: 1
        Active App Selection Host Lane 8: 1
        Active Firmware Version: 94.7.0
        Application Advertisement: 800G L C2M (placeholder) - Host Assign (0x1) - Undefined - Media Assign (0x1)
                                   800G S C2M (placeholder) - Host Assign (0x1) - Undefined - Media Assign (0x1)
                                   400GAUI-4-L C2M (Annex 120G) - Host Assign (0x11) - 400GBASE-DR4 (Cl 124) - Media Assign (0x11)
                                   400GAUI-4-S C2M (Annex 120G) - Host Assign (0x11) - 400GBASE-DR4 (Cl 124) - Media Assign (0x11)
                                   100GAUI-1-L C2M (Annex 120G) - Host Assign (0xff) - 100G-FR/100GBASE-FR1 (Cl 140) - Media Assign (0xff)
                                   100GAUI-1-S C2M (Annex 120G) - Host Assign (0xff) - 100G-FR/100GBASE-FR1 (Cl 140) - Media Assign (0xff)
        CMIS Revision: 5.0
        Connector: MPO 1x12
        Encoding: N/A
        Extended Identifier: Power Class 8 (17.0W Max)
        Extended RateSelect Compliance: N/A
        Hardware Revision: 1.11
        Host Electrical Interface: 800G L C2M (placeholder)
        Host Lane Assignment Options: 1
        Host Lane Count: 8
        Identifier: QSFP-DD Double Density 8X Pluggable Transceiver
        Inactive Firmware Version: 0.0.0
        Length Cable Assembly(m): 0.0
        Media Interface Code: Undefined
        Media Interface Technology: 1310 nm EML
        Media Lane Assignment Options: 1
        Media Lane Count: 8
        Nominal Bit Rate(100Mbs): 0
        Specification compliance: sm_media_interface
        Vendor Date Code(YYYY-MM-DD Lot): 2022-10-10   
        Vendor Name: CISCO-INNOLIGHT 
        Vendor OUI: 44-7c-7f
        Vendor PN: T-DH8CNT-NCI    
        Vendor Rev: 2C
        Vendor SN: INL264107KL     """.encode("utf-8")

SFPUTIL_SHOW_EEPROM_OUTPUT_DAC="""\
Ethernet76: SFP EEPROM detected
        Application Advertisement: N/A
        Connector: No separable connector
        Encoding: 64B/66B
        Extended Identifier: Power Class 1 Module (1.5W max.), No CLEI code present in Page 02h, No CDR in TX, No CDR in RX
        Extended RateSelect Compliance: Unknown
        Identifier: QSFP28 or later
        Length Cable Assembly(m): 1.0
        Nominal Bit Rate(100Mbs): 255
        Specification compliance:
                10/40G Ethernet Compliance Code: Unknown
                Extended Specification Compliance: 25GBASE-CR CA-25G-N or 50GBASE-CR2 with no FEC
                Fibre Channel Link Length: Unknown
                Fibre Channel Speed: Unknown
                Fibre Channel Transmission Media: Unknown
                Fibre Channel Transmitter Technology: Unknown
                Gigabit Ethernet Compliant Codes: Unknown
                SAS/SATA Compliance Codes: Unknown
                SONET Compliance Codes: Unknown
        Vendor Date Code(YYYY-MM-DD Lot): 2021-07-25   
        Vendor Name: Amphenol        
        Vendor OUI: 78-a7-14
        Vendor PN: NDAAFS-M205     
        Vendor Rev: E 
        Vendor SN: APF21292050YGH  """.encode("utf-8")

SFPUTIL_SHOW_EEPROM_OUTPUT_SFP = """\
Ethernet256: SFP EEPROM detected
        Application Advertisement: N/A
        Connector: LC
        Encoding: 64B/66B
        Extended Identifier: GBIC/SFP defined by two-wire interface ID
        Extended RateSelect Compliance: Unknown
        Identifier: SFP/SFP+/SFP28
        Length OM3(10m): 30.0
        Nominal Bit Rate(100Mbs): 103
        Specification compliance:
                10G Ethernet Compliance: 10GBASE-SR
                ESCON Compliance: Unknown
                Ethernet Compliance: Unknown
                Fibre Channel Link Length: Unknown
                Fibre Channel Speed: Unknown
                Fibre Channel Transmission Media: Unknown
                Fibre Channel Transmitter Technology: Unknown
                Infiniband Compliance: Unknown
                SFP+CableTechnology: Unknown
                SONET Compliance Codes: Unknown
        Vendor Date Code(YYYY-MM-DD Lot): 2009-06-27   
        Vendor Name: FINISAR CORP.   
        Vendor OUI: 00-90-65
        Vendor PN: FTLX8571D3BCL   
        Vendor Rev: A   
        Vendor SN: UFS073Z      """.encode("utf-8")

SFPUTIL_SHOW_EEPROM_OUTPUT_40GSR4="""\
Ethernet36: SFP EEPROM detected
        Application Advertisement: N/A
        Connector: Optical Pigtail
        Encoding: 64B/66B
        Extended Identifier: Power Class 1 Module (1.5W max. Power consumption), No CLEI code present in Page 02h, No CDR in TX, No CDR in RX
        Extended RateSelect Compliance: QSFP+ Rate Select Version 1
        Identifier: QSFP+ or later with SFF-8636 or SFF-8436
        Length OM1(m): 3.0
        Nominal Bit Rate(100Mbs): 103
        Specification compliance:
                10/40G Ethernet Compliance Code: 40GBASE-SR4
                Fibre Channel Link Length: Unknown
                Fibre Channel Speed: Unknown
                Fibre Channel Transmission Media: Unknown
                Fibre Channel Transmitter Technology: Unknown
                Gigabit Ethernet Compliant Codes: Unknown
                SAS/SATA Compliance Codes: Unknown
                SONET Compliance Codes: Unknown
        Vendor Date Code(YYYY-MM-DD Lot): 2015-10-01   
        Vendor Name: AOI             
        Vendor OUI: 00-00-00
        Vendor PN: AQOA9N03ADLN0723
        Vendor Rev: A 
        Vendor SN: 29015J20058   """.encode("utf-8")

SFPUTIL_SHOW_LPMODE_OFF_OUTPUT = """\
Port        Low-power Mode
----------  ----------------
Ethernet0  Off""".encode("utf-8")

SFPUTIL_SHOW_LPMODE_ON_OUTPUT = """\
Port        Low-power Mode
----------  ----------------
Ethernet0  On""".encode("utf-8")

class TestSonicUtil(object):
    @patch('subprocess.Popen')
    def test_run_command_success(self, mock_popen):
        sonic_utility = remote_reseat.SonicUtility()
        mock_popen.return_value.communicate.return_value = (b'test_output', b'')
        mock_popen.return_value.returncode = 0
        return_code, result, _ = sonic_utility.run_command("test_command")
        assert return_code == 0
        assert result == b'test_output'

    @patch('subprocess.Popen', MagicMock(side_effect=Exception("ValueError")))
    def test_run_command_exception(self):
        sonic_utility = remote_reseat.SonicUtility()
        return_code, result, _ = sonic_utility.run_command("test_command")
        assert return_code == None
        assert result == None

    @pytest.mark.parametrize(
            "run_command_return_value, expected_return_value",
            [
                ([None, '', ''], None),
                ([2, '', ''], None),
                ([0, "202305".encode("utf-8"), ''], "202305")
            ])
    def test_get_os_version(self, run_command_return_value, expected_return_value):
        mock_sonic_utility = remote_reseat.SonicUtility()
        mock_sonic_utility.run_command = MagicMock(return_value=run_command_return_value)
        output = mock_sonic_utility.get_os_version()
        assert output == expected_return_value

    @pytest.mark.parametrize(
            "run_command_return_value, expected_return_value",
            [
                ([None, '', ''], False),
                ([2, '', ''], False),
                ([0, SHOW_INTERFACE_STATUS_OUTPUT, ''], True)
            ])
    def test_is_interface_valid(self, run_command_return_value, expected_return_value):
        mock_sonic_utility = remote_reseat.SonicUtility()
        mock_sonic_utility.run_command = MagicMock(return_value=run_command_return_value)
        output = mock_sonic_utility.is_interface_valid("Ethernet0")
        assert output == expected_return_value

    @pytest.mark.parametrize(
            "run_command_return_value, expected_return_value",
            [
                ([None, '', ''], None),
                ([2, '', ''], None),
                ([0, SHOW_INTERFACE_STATUS_OUTPUT, ''], "down")
            ])
    def test_get_interface_oper_status(self, run_command_return_value, expected_return_value):
        mock_sonic_utility = remote_reseat.SonicUtility()
        mock_sonic_utility.run_command = MagicMock(return_value=run_command_return_value)
        output = mock_sonic_utility.get_interface_oper_status("Ethernet0")
        assert output == expected_return_value

    @pytest.mark.parametrize(
            "run_command_return_value, expected_return_value",
            [
                ([None, '', ''], None),
                ([2, '', ''], None),
                ([0, SHOW_INTERFACE_STATUS_OUTPUT, ''], "up")
            ])
    def test_get_interface_admin_status(self, run_command_return_value, expected_return_value):
        mock_sonic_utility = remote_reseat.SonicUtility()
        mock_sonic_utility.run_command = MagicMock(return_value=run_command_return_value)
        output = mock_sonic_utility.get_interface_admin_status("Ethernet0")
        assert output == expected_return_value

    @pytest.mark.parametrize(
            "run_command_return_value, expected_return_value",
            [
                ([None, '', ''], False),
                ([2, '', ''], False),
                ([0, SHOW_INTERFACE_STATUS_OUTPUT, ''], False)
            ])
    def test_is_admin_status_down(self, run_command_return_value, expected_return_value):
        mock_sonic_utility = remote_reseat.SonicUtility()
        mock_sonic_utility.run_command = MagicMock(return_value=run_command_return_value)
        output = mock_sonic_utility.is_admin_status_down("Ethernet0")
        assert output == expected_return_value

    @pytest.mark.parametrize(
            "run_command_return_value, expected_return_value",
            [
                ([None, '', ''], False),
                ([2, '', ''], False),
                ([0, SHOW_INTERFACE_STATUS_OUTPUT, ''], True)
            ])
    def test_is_link_status_down(self, run_command_return_value, expected_return_value):
        mock_sonic_utility = remote_reseat.SonicUtility()
        mock_sonic_utility.run_command = MagicMock(return_value=run_command_return_value)
        output = mock_sonic_utility.is_link_status_down("Ethernet0")
        assert output == expected_return_value

    @pytest.mark.parametrize(
            "run_command_return_value, expected_return_value",
            [
                ([None, '', ''], False),
                ([2, '', ''], False),
                ([0, SHOW_INTERFACE_STATUS_OPER_UP_OUTPUT, ''], True)
            ])
    def test_is_link_status_up(self, run_command_return_value, expected_return_value):
        mock_sonic_utility = remote_reseat.SonicUtility()
        mock_sonic_utility.run_command = MagicMock(return_value=run_command_return_value)
        output = asyncio.run(mock_sonic_utility.is_link_status_up("Ethernet0"))
        assert output == expected_return_value

    @pytest.mark.parametrize(
            "run_command_return_value, expected_return_value",
            [
                ([None, '', ''], False),
                ([2, '', ''], False),
                ([0, '', ''], True)
            ])
    def test_execute_interface_shutdown(self, run_command_return_value, expected_return_value):
        mock_sonic_utility = remote_reseat.SonicUtility()
        mock_sonic_utility.run_command = MagicMock(return_value=run_command_return_value)
        output = mock_sonic_utility.execute_interface_shutdown("Ethernet0", "")
        assert output == expected_return_value

    @pytest.mark.parametrize(
            "run_command_return_value, expected_return_value",
            [
                ([None, '', ''], False),
                ([2, '', ''], False),
                ([0, '', ''], True)
            ])
    def test_execute_interface_startup(self, run_command_return_value, expected_return_value):
        mock_sonic_utility = remote_reseat.SonicUtility()
        mock_sonic_utility.run_command = MagicMock(return_value=run_command_return_value)
        output = mock_sonic_utility.execute_interface_startup("Ethernet0", "")
        assert output == expected_return_value

    @pytest.mark.parametrize(
            "run_command_return_value, expected_return_value",
            [
                ([None, '', ''], False),
                ([2, '', ''], False),
                ([0, 'OK'.encode("utf-8"), ''], True)
            ])
    def test_execute_sfputil_reset(self, run_command_return_value, expected_return_value):
        mock_sonic_utility = remote_reseat.SonicUtility()
        mock_sonic_utility.run_command = MagicMock(return_value=run_command_return_value)
        output = mock_sonic_utility.execute_sfputil_reset("Ethernet0")
        assert output == expected_return_value

    @pytest.mark.parametrize(
            "run_command_return_value, expected_return_value",
            [
                ([None, '', ''], None),
                ([2, '', ''], None),
                ([0, "Failed".encode("utf-8"), ''], None),
                ([0, SFPUTIL_SHOW_PRESENCE_OUTPUT, ''], True)
            ])
    def test_is_transceiver_present(self, run_command_return_value, expected_return_value):
        mock_sonic_utility = remote_reseat.SonicUtility()
        mock_sonic_utility.run_command = MagicMock(return_value=run_command_return_value)
        output = mock_sonic_utility.is_transceiver_present("Ethernet0")
        assert output == expected_return_value

    @pytest.mark.parametrize(
            "run_command_return_value, expected_return_value",
            [
                ([None, '', ''], None),
                ([2, '', ''], None),
                ([0, 'Test'.encode("utf-8"), ''], None),
                ([0, SFPUTIL_SHOW_EEPROM_OUTPUT, ''], True),
                ([0, SFPUTIL_SHOW_EEPROM_OUTPUT_SFP, ''], False),
                ([0, SFPUTIL_SHOW_EEPROM_OUTPUT_DAC, ''], True)
            ])
    def test_get_transceiver_remote_reseat_support(self, run_command_return_value, expected_return_value):
        mock_sonic_utility = remote_reseat.SonicUtility()
        mock_sonic_utility.run_command = MagicMock(return_value=run_command_return_value)
        output = mock_sonic_utility.get_transceiver_remote_reseat_support("Ethernet0")
        assert output == expected_return_value

    @pytest.mark.parametrize(
            "run_command_return_value, expected_return_value",
            [
                ([None, '', ''], None),
                ([2, '', ''], None),
                ([0, 'A'.encode("utf-8"), ''], None),
                ([0, SHOW_INTERFACE_STATUS_OUTPUT, ''], True),
                ([0, SFPUTIL_SHOW_EEPROM_OUTPUT_40GSR4, ''], False),
                ([0, SFPUTIL_SHOW_EEPROM_OUTPUT_DAC, ''], False),
                ([0, SFPUTIL_SHOW_EEPROM_OUTPUT, ''], False)
            ])
    def test_is_lpmode_toggle_required(self, run_command_return_value, expected_return_value):
        mock_sonic_utility = remote_reseat.SonicUtility()
        mock_sonic_utility.run_command = MagicMock(return_value=run_command_return_value)
        output = mock_sonic_utility.is_lpmode_toggle_required("Ethernet0")
        assert output == expected_return_value

    @pytest.mark.parametrize(
            "run_command_return_value, enable, expected_return_value",
            [
                ([None, '', ''], True, False),
                ([2, '', ''], True, False),
                ([0, 'OK'.encode("utf-8"), ''], False, True),
                ([0, 'Failed'.encode("utf-8"), ''], True, False)
            ])
    def test_execute_sfputil_lpmode(self, run_command_return_value, enable, expected_return_value):
        mock_sonic_utility = remote_reseat.SonicUtility()
        mock_sonic_utility.run_command = MagicMock(return_value=run_command_return_value)
        output = mock_sonic_utility.execute_sfputil_lpmode("Ethernet0", enable)
        assert output == expected_return_value

    @pytest.mark.parametrize(
            "run_command_return_value, expected_return_value",
            [
                ([None, '', ''], None),
                ([2, '', ''], None),
                ([0, SFPUTIL_SHOW_LPMODE_OFF_OUTPUT, ''], "Off"),
                ([0, SFPUTIL_SHOW_LPMODE_ON_OUTPUT, ''], "On")
            ])
    def test_get_transceiver_lpmode_status(self, run_command_return_value, expected_return_value):
        mock_sonic_utility = remote_reseat.SonicUtility()
        mock_sonic_utility.run_command = MagicMock(return_value=run_command_return_value)
        output = mock_sonic_utility.get_transceiver_lpmode_status("Ethernet0")
        assert output == expected_return_value

class TestBase(unittest.TestCase):
    def checkCmd(self, success, testargs, sysExit=True, uid=0):
        testargs = ['./remote_reseat.py'] + testargs
        with patch.object(sys, 'argv', testargs):
            with patch.object(os, 'geteuid', return_value=uid):
                if sysExit:
                    with self.assertRaises(SystemExit) as cm:
                        loop = asyncio.new_event_loop()
                        asyncio.set_event_loop(loop)
                        try:
                            return_val = loop.run_until_complete(remote_reseat.main())
                        finally:
                            loop.close()
                    if success:
                        self.assertTrue(cm.exception.code == 0)
                    else:
                        self.assertTrue(cm.exception.code != 0)
                        return cm.exception.code
                else:
                    loop = asyncio.new_event_loop()
                    asyncio.set_event_loop(loop)
                    try:
                        return_val = loop.run_until_complete(remote_reseat.main())
                    finally:
                        loop.close()

        return return_val

    def checkPass(self, testargs):
        return self.checkCmd(True, testargs, sysExit=False) 

    def checkFail(self, testargs, userId=0):
        return self.checkCmd(False, testargs, sysExit=True, uid=userId)

    def checkFailWithoutSysExit(self, testargs, userId=0):
        return self.checkCmd(False, testargs, sysExit=False, uid=userId)

@patch('remote_reseat.I2C_WAIT_TIME_AFTER_RESET', 0.01)
@patch('remote_reseat.INTERFACE_LINK_UP_TIMEOUT', 0.01)
class RemoteReseatTest(TestBase):
    def setUp(self):
        self.mock_converter = MagicMock()
        self.mock_converter.alias_to_name.side_effect = lambda x: x  # return same value as input

        self.patcher = patch('remote_reseat.cli.InterfaceAliasConverter', return_value=self.mock_converter)
        self.patcher.start()

    def tearDown(self):
        self.patcher.stop()

    def test_non_sudo_caller(self):
        self.assertEqual(self.checkFail(['-p Ethernet0'], userId=1000), remote_reseat.ERROR_NON_SUDO)

    @patch('remote_reseat.SonicUtility.get_os_version', MagicMock(return_value=None))
    def test_prerequisite_os_version_None_failure(self):
        self.assertEqual(self.checkFailWithoutSysExit(['-p Ethernet0']), remote_reseat.ERROR_PRE_REQ_OS_CHECK)

    @patch('remote_reseat.SonicUtility.get_os_version', MagicMock(return_value="201911"))
    def test_prerequisite_os_version_unsupported_failure(self):
        self.assertEqual(self.checkFailWithoutSysExit(['-p Ethernet0']), remote_reseat.ERROR_PRE_REQ_OS_CHECK)

    @patch('remote_reseat.SonicUtility.get_os_version', MagicMock(return_value="202305"))
    @patch('remote_reseat.SonicUtility.is_interface_valid', MagicMock(return_value=False))
    def test_prerequisite_invalid_interface(self):
        self.assertIn(self.checkFailWithoutSysExit(['-p Ethernet0']), [remote_reseat.ERROR_PRE_REQ_INTERFACE_CHECK, remote_reseat.ERROR_PRE_REQ_INTERFACE_CHECK_FOR_CHASSIS])

    @patch('remote_reseat.SonicUtility.get_os_version', MagicMock(return_value="202305"))
    @patch('remote_reseat.SonicUtility.is_interface_valid', MagicMock(return_value=True))
    @patch('remote_reseat.SonicUtility.get_namespace', MagicMock(return_value=None))
    def test_prerequisite_get_namespace_None_failure(self):
        self.assertEqual(self.checkFailWithoutSysExit(['-p Ethernet0']), remote_reseat.ERROR_PRE_REQ_NAMESPACE_CHECK)

    @patch('remote_reseat.SonicUtility.get_os_version', MagicMock(return_value="202305"))
    @patch('remote_reseat.SonicUtility.is_interface_valid', MagicMock(return_value=True))
    @patch('remote_reseat.SonicUtility.get_namespace', MagicMock(return_value=''))
    @patch('remote_reseat.SonicUtility.is_admin_status_down', MagicMock(return_value=None))
    def test_prerequisite_admin_status_down_None_failure(self):
        self.assertEqual(self.checkFailWithoutSysExit(['-p Ethernet0']), remote_reseat.ERROR_PRE_REQ_ADMIN_STATUS_CHECK)

    @patch('remote_reseat.SonicUtility.get_os_version', MagicMock(return_value="202305"))
    @patch('remote_reseat.SonicUtility.is_interface_valid', MagicMock(return_value=True))
    @patch('remote_reseat.SonicUtility.get_namespace', MagicMock(return_value=''))
    @patch('remote_reseat.SonicUtility.is_admin_status_down', MagicMock(return_value=True))
    def test_prerequisite_admin_status_down(self):
        self.assertEqual(self.checkFailWithoutSysExit(['-p Ethernet0']), remote_reseat.ERROR_PRE_REQ_ADMIN_STATUS_CHECK)

    @patch('remote_reseat.SonicUtility.get_os_version', MagicMock(return_value="202305"))
    @patch('remote_reseat.SonicUtility.is_interface_valid', MagicMock(return_value=True))
    @patch('remote_reseat.SonicUtility.get_namespace', MagicMock(return_value=''))
    @patch('remote_reseat.SonicUtility.is_admin_status_down', MagicMock(return_value=False))
    @patch('remote_reseat.SonicUtility.is_transceiver_present', MagicMock(return_value=None))
    def test_prerequisite_transceiver_present_None_failure(self):
        self.assertEqual(self.checkFailWithoutSysExit(['-p Ethernet0']), remote_reseat.ERROR_PRE_REQ_PRESENCE_CHECK)

    @patch('remote_reseat.SonicUtility.get_os_version', MagicMock(return_value="202305"))
    @patch('remote_reseat.SonicUtility.is_interface_valid', MagicMock(return_value=True))
    @patch('remote_reseat.SonicUtility.get_namespace', MagicMock(return_value=''))
    @patch('remote_reseat.SonicUtility.is_admin_status_down', MagicMock(return_value=False))
    @patch('remote_reseat.SonicUtility.is_transceiver_present', MagicMock(return_value=False))
    def test_prerequisite_transceiver_present_failure(self):
        self.assertEqual(self.checkFailWithoutSysExit(['-p Ethernet0']), remote_reseat.ERROR_PRE_REQ_PRESENCE_CHECK)

    @patch('remote_reseat.SonicUtility.get_os_version', MagicMock(return_value="202305"))
    @patch('remote_reseat.SonicUtility.is_interface_valid', MagicMock(return_value=True))
    @patch('remote_reseat.SonicUtility.get_namespace', MagicMock(return_value=''))
    @patch('remote_reseat.SonicUtility.is_admin_status_down', MagicMock(return_value=False))
    @patch('remote_reseat.SonicUtility.is_transceiver_present', MagicMock(return_value=True))
    @patch('remote_reseat.SonicUtility.get_transceiver_remote_reseat_support', MagicMock(return_value=None))
    def test_prerequisite_transceiver_dac_None_failure(self):
        self.assertEqual(self.checkFailWithoutSysExit(['-p Ethernet0']), remote_reseat.ERROR_PRE_REQ_RRESEAT_SUPPORT)

    @patch('remote_reseat.SonicUtility.get_os_version', MagicMock(return_value="202305"))
    @patch('remote_reseat.SonicUtility.is_interface_valid', MagicMock(return_value=True))
    @patch('remote_reseat.SonicUtility.get_namespace', MagicMock(return_value=''))
    @patch('remote_reseat.SonicUtility.is_admin_status_down', MagicMock(return_value=False))
    @patch('remote_reseat.SonicUtility.is_transceiver_present', MagicMock(return_value=True))
    @patch('remote_reseat.SonicUtility.get_transceiver_remote_reseat_support', MagicMock(return_value=False))
    @patch('remote_reseat.RemoteReseat.execute_remote_reseat_procedure', MagicMock())
    def test_prerequisite_unsupported_transceiver(self):
        self.assertEqual(self.checkPass(['-p Ethernet0']) , 0)
        assert remote_reseat.RemoteReseat.execute_remote_reseat_procedure.call_count == 0

    @patch('remote_reseat.RemoteReseat.verify_prerequisites', MagicMock(return_value=remote_reseat.ERROR_PREREQUISITE_VERIFICATION))
    def test_prerequisite_failure(self):
        self.assertEqual(self.checkFailWithoutSysExit(['-p Ethernet0']), remote_reseat.ERROR_PREREQUISITE_VERIFICATION)

    @patch('remote_reseat.RemoteReseat.verify_prerequisites', MagicMock(side_effect=(0, remote_reseat.ERROR_PREREQUISITE_VERIFICATION, 0)))
    @patch('remote_reseat.RemoteReseat.execute_remote_reseat_procedure', AsyncMock(return_value=0))
    def test_prerequisite_with_multiple_ports(self):
        self.assertEqual(self.checkFailWithoutSysExit(['-p', 'Ethernet0', 'Ethernet2', 'Ethernet4']), remote_reseat.ERROR_PREREQUISITE_VERIFICATION)
        assert remote_reseat.RemoteReseat.execute_remote_reseat_procedure.call_count == 2

    @patch('remote_reseat.RemoteReseat.verify_prerequisites', MagicMock(side_effect=(0, AttributeError("Test"))))
    @patch('remote_reseat.RemoteReseat.execute_remote_reseat_procedure', AsyncMock(return_value=(0)))
    def test_prerequisite_exception(self):
        self.assertEqual(self.checkFailWithoutSysExit(['-p', 'Ethernet0', 'Ethernet2']), remote_reseat.ERROR_PREREQUISITE_VERIFICATION)
        assert remote_reseat.RemoteReseat.execute_remote_reseat_procedure.call_count == 1

    @patch('remote_reseat.RemoteReseat.verify_prerequisites', MagicMock(side_effect=(0, AttributeError("Test"))))
    @patch('remote_reseat.RemoteReseat.execute_remote_reseat_procedure', AsyncMock(return_value=(0)))
    def test_prerequisite_exception(self):
        self.assertEqual(self.checkFailWithoutSysExit(['-p', 'Ethernet0', 'Ethernet2']), remote_reseat.ERROR_PREREQUISITE_VERIFICATION)
        assert remote_reseat.RemoteReseat.execute_remote_reseat_procedure.call_count == 1

    @patch('remote_reseat.RemoteReseat.verify_prerequisites', MagicMock(side_effect=(0, 0, 0)))
    @patch('remote_reseat.RemoteReseat.execute_remote_reseat_procedure', AsyncMock(side_effect=(0, KeyError("Test"), 0)))
    def test_execute_remote_reseat_exception(self):
        self.assertEqual(self.checkFailWithoutSysExit(['-p', 'Ethernet0', 'Ethernet2', 'Ethernet4']), remote_reseat.ERROR_EXECUTE_REMOTE_RESEAT_EXCEPTION)
        assert remote_reseat.RemoteReseat.execute_remote_reseat_procedure.call_count == 3

    @patch('remote_reseat.SonicUtility.get_os_version', MagicMock(return_value="202305"))
    @patch('remote_reseat.SonicUtility.is_interface_valid', MagicMock(return_value=True))
    @patch('remote_reseat.SonicUtility.get_namespace', MagicMock(return_value=''))
    @patch('remote_reseat.SonicUtility.is_admin_status_down', MagicMock(return_value=False))
    @patch('remote_reseat.SonicUtility.is_transceiver_present', MagicMock(return_value=True))
    @patch('remote_reseat.SonicUtility.get_transceiver_remote_reseat_support', MagicMock(return_value=True))
    @patch('remote_reseat.SonicUtility.execute_interface_shutdown', MagicMock(return_value=None))
    @patch('remote_reseat.SonicUtility.execute_interface_startup', MagicMock(return_value=True))
    def test_remote_reseat_shutdown_interface_and_verify_link_down_None_error(self):
        self.assertEqual(self.checkFailWithoutSysExit(['-p', 'Ethernet0', '-r', '3']), remote_reseat.ERROR_SHUTDOWN_INTERFACE)
        assert remote_reseat.SonicUtility.execute_interface_startup.call_count == 3

    @patch('remote_reseat.RemoteReseat.verify_prerequisites', MagicMock(return_value=0))
    @patch('remote_reseat.SonicUtility.execute_interface_shutdown', MagicMock(return_value=True))
    @patch('remote_reseat.SonicUtility.wait_until', MagicMock(return_value=False))
    @patch('remote_reseat.SonicUtility.execute_interface_startup', MagicMock(return_value=True))
    def test_remote_reseat_shutdown_interface_and_verify_link_down_failure(self):
        self.assertEqual(self.checkFailWithoutSysExit(['-p Ethernet0']), remote_reseat.ERROR_SHUTDOWN_INTERFACE)
        assert remote_reseat.SonicUtility.execute_interface_startup.call_count == 1

    @patch('remote_reseat.RemoteReseat.verify_prerequisites', MagicMock(return_value=0))
    @patch('remote_reseat.SonicUtility.execute_interface_shutdown', MagicMock(return_value=True))
    @patch('remote_reseat.SonicUtility.wait_until', MagicMock(return_value=True))
    @patch('remote_reseat.SonicUtility.execute_sfputil_reset', MagicMock(return_value=False))
    @patch('remote_reseat.SonicUtility.execute_interface_startup', MagicMock(return_value=True))
    def test_remote_reseat_reset_failure(self):
        self.assertEqual(self.checkFailWithoutSysExit(['-p', 'Ethernet0', '-r', '3']), remote_reseat.ERROR_SFPUTIL_RESET)
        assert remote_reseat.SonicUtility.execute_interface_startup.call_count == 3

    @patch('remote_reseat.RemoteReseat.verify_prerequisites', MagicMock(return_value=0))
    @patch('remote_reseat.SonicUtility.execute_interface_shutdown', MagicMock(return_value=True))
    @patch('remote_reseat.SonicUtility.wait_until', MagicMock(return_value=True))
    @patch('remote_reseat.SonicUtility.execute_sfputil_reset', MagicMock(return_value=False))
    @patch('remote_reseat.SonicUtility.execute_interface_startup', MagicMock(return_value=False))
    def test_remote_reseat_reset_failure_followed_by_interface_startup_failure(self):
        self.assertEqual(self.checkFailWithoutSysExit(['-p', 'Ethernet0', '-r', '3']), remote_reseat.ERROR_STARTUP_INTERFACE)
        assert remote_reseat.SonicUtility.execute_interface_startup.call_count == 3

    @patch('remote_reseat.RemoteReseat.verify_prerequisites', MagicMock(return_value=0))
    @patch('remote_reseat.RemoteReseat.shutdown_interface_and_verify_link_down', MagicMock())
    @patch('remote_reseat.SonicUtility.execute_sfputil_reset', MagicMock(return_value=True))
    @patch('remote_reseat.SonicUtility.is_lpmode_toggle_required', MagicMock(return_value=None))
    @patch('remote_reseat.SonicUtility.execute_interface_startup', MagicMock(return_value=True))
    def test_remote_reseat_is_lpmode_toggle_required_None(self):
        self.assertEqual(self.checkFailWithoutSysExit(['-p Ethernet0']), remote_reseat.ERROR_LPMODE_TOGGLE_REQUIRED)
        assert remote_reseat.SonicUtility.execute_interface_startup.call_count == 1

    @patch('remote_reseat.RemoteReseat.verify_prerequisites', MagicMock(return_value=0))
    @patch('remote_reseat.RemoteReseat.shutdown_interface_and_verify_link_down', MagicMock())
    @patch('remote_reseat.SonicUtility.execute_sfputil_reset', MagicMock(return_value=True))
    @patch('remote_reseat.SonicUtility.is_lpmode_toggle_required', MagicMock(return_value=True))
    @patch('remote_reseat.SonicUtility.execute_sfputil_lpmode', MagicMock(return_value=None))
    @patch('remote_reseat.SonicUtility.execute_interface_startup', MagicMock(return_value=True))
    def test_remote_reseat_switch_to_lpmode_exec_failure(self):
        self.assertEqual(self.checkFailWithoutSysExit(['-p', 'Ethernet0', '-r', '3']), remote_reseat.ERROR_SFPUTIL_LPMODE)
        assert remote_reseat.SonicUtility.execute_sfputil_lpmode.call_count == 6
        assert remote_reseat.SonicUtility.execute_interface_startup.call_count == 3

    @patch('remote_reseat.RemoteReseat.verify_prerequisites', MagicMock(return_value=0))
    @patch('remote_reseat.RemoteReseat.shutdown_interface_and_verify_link_down', MagicMock())
    @patch('remote_reseat.SonicUtility.execute_sfputil_reset', MagicMock(return_value=True))
    @patch('remote_reseat.SonicUtility.is_lpmode_toggle_required', MagicMock(return_value=True))
    @patch('remote_reseat.SonicUtility.execute_sfputil_lpmode', MagicMock(return_value=None))
    @patch('remote_reseat.SonicUtility.execute_interface_startup', MagicMock(return_value=False))
    def test_remote_reseat_switch_to_lpmode_exec_failure_followed_by_interface_startup_failure(self):
        self.assertEqual(self.checkFailWithoutSysExit(['-p', 'Ethernet0', '-r', '3']), remote_reseat.ERROR_STARTUP_INTERFACE)
        assert remote_reseat.SonicUtility.execute_sfputil_lpmode.call_count == 6
        assert remote_reseat.SonicUtility.execute_interface_startup.call_count == 3

    @patch('remote_reseat.RemoteReseat.verify_prerequisites', MagicMock(return_value=0))
    @patch('remote_reseat.RemoteReseat.shutdown_interface_and_verify_link_down', MagicMock())
    @patch('remote_reseat.SonicUtility.execute_sfputil_reset', MagicMock(return_value=True))
    @patch('remote_reseat.SonicUtility.is_lpmode_toggle_required', MagicMock(return_value=True))
    @patch('remote_reseat.SonicUtility.execute_sfputil_lpmode', MagicMock())
    @patch('remote_reseat.SonicUtility.get_transceiver_lpmode_status', MagicMock(return_value=None))
    @patch('remote_reseat.SonicUtility.execute_interface_startup', MagicMock(return_value=True))
    def test_remote_reseat_verify_lpmode_None_failure_in_low_power_mode(self):
        self.assertEqual(self.checkFailWithoutSysExit(['-p Ethernet0']), remote_reseat.ERROR_SFPUTIL_LPMODE_VERIFICATION)
        assert remote_reseat.SonicUtility.execute_sfputil_lpmode.call_count == 2
        assert remote_reseat.SonicUtility.execute_interface_startup.call_count == 1

    @patch('remote_reseat.RemoteReseat.verify_prerequisites', MagicMock(return_value=0))
    @patch('remote_reseat.RemoteReseat.shutdown_interface_and_verify_link_down', MagicMock())
    @patch('remote_reseat.SonicUtility.execute_sfputil_reset', MagicMock(return_value=True))
    @patch('remote_reseat.SonicUtility.is_lpmode_toggle_required', MagicMock(return_value=True))
    @patch('remote_reseat.SonicUtility.execute_sfputil_lpmode', MagicMock(return_value=True))
    @patch('remote_reseat.SonicUtility.get_transceiver_lpmode_status', MagicMock(return_value="Off"))
    @patch('remote_reseat.SonicUtility.execute_interface_startup', MagicMock(return_value=True))
    def test_remote_reseat_invalid_verify_lpmode_in_low_power_mode(self):
        self.assertEqual(self.checkFailWithoutSysExit(['-p', 'Ethernet0', '-r', '3']), remote_reseat.ERROR_SFPUTIL_LPMODE_VERIFICATION)
        assert remote_reseat.SonicUtility.execute_sfputil_lpmode.call_count == 6
        assert remote_reseat.SonicUtility.execute_interface_startup.call_count == 3

    @patch('remote_reseat.RemoteReseat.verify_prerequisites', MagicMock(return_value=0))
    @patch('remote_reseat.RemoteReseat.shutdown_interface_and_verify_link_down', MagicMock())
    @patch('remote_reseat.SonicUtility.execute_sfputil_reset', MagicMock(return_value=True))
    @patch('remote_reseat.SonicUtility.is_lpmode_toggle_required', MagicMock(return_value=True))
    @patch('remote_reseat.SonicUtility.execute_sfputil_lpmode', MagicMock())
    @patch('remote_reseat.SonicUtility.get_transceiver_lpmode_status', MagicMock(return_value="On"))
    @patch('remote_reseat.SonicUtility.execute_interface_startup', MagicMock(return_value=True))
    def test_remote_reseat_invalid_verify_lpmode_in_high_power_mode(self):
        self.assertEqual(self.checkFailWithoutSysExit(['-p Ethernet0']), remote_reseat.ERROR_SFPUTIL_LPMODE_VERIFICATION)
        assert remote_reseat.SonicUtility.execute_sfputil_lpmode.call_count == 2
        assert remote_reseat.SonicUtility.execute_interface_startup.call_count == 1

    @patch('remote_reseat.RemoteReseat.verify_prerequisites', MagicMock(return_value=0))
    @patch('remote_reseat.RemoteReseat.shutdown_interface_and_verify_link_down', MagicMock())
    @patch('remote_reseat.SonicUtility.execute_sfputil_reset', MagicMock(return_value=True))
    @patch('remote_reseat.SonicUtility.is_lpmode_toggle_required', MagicMock(return_value=True))
    @patch('remote_reseat.SonicUtility.execute_sfputil_lpmode', MagicMock(side_effect=[True, False, False, False, False, False]))
    @patch('remote_reseat.SonicUtility.get_transceiver_lpmode_status', MagicMock(return_value="On"))
    @patch('remote_reseat.SonicUtility.execute_interface_startup', MagicMock(return_value=True))
    def test_remote_reseat_switch_to_high_power_mode_exec_failure(self):
        self.assertEqual(self.checkFailWithoutSysExit(['-p', 'Ethernet0', '-r', '3']), remote_reseat.ERROR_SFPUTIL_LPMODE)
        assert remote_reseat.SonicUtility.execute_sfputil_lpmode.call_count == 6
        assert remote_reseat.SonicUtility.execute_interface_startup.call_count == 3

    @patch('remote_reseat.RemoteReseat.verify_prerequisites', MagicMock(return_value=0))
    @patch('remote_reseat.RemoteReseat.shutdown_interface_and_verify_link_down', MagicMock())
    @patch('remote_reseat.SonicUtility.execute_sfputil_reset', MagicMock(return_value=True))
    @patch('remote_reseat.SonicUtility.is_lpmode_toggle_required', MagicMock(return_value=True))
    @patch('remote_reseat.SonicUtility.execute_sfputil_lpmode', MagicMock())
    @patch('remote_reseat.SonicUtility.get_transceiver_lpmode_status', MagicMock(return_value="On"))
    @patch('remote_reseat.SonicUtility.execute_interface_startup', MagicMock(return_value=False))
    def test_remote_reseat_startup_interface_failure(self):
        self.assertEqual(self.checkFailWithoutSysExit(['-p Ethernet0']), remote_reseat.ERROR_STARTUP_INTERFACE)

    @patch('remote_reseat.RemoteReseat.verify_prerequisites', MagicMock(return_value=0))
    @patch('remote_reseat.RemoteReseat.shutdown_interface_and_verify_link_down', MagicMock())
    @patch('remote_reseat.SonicUtility.execute_sfputil_reset', MagicMock(return_value=True))
    @patch('remote_reseat.SonicUtility.is_lpmode_toggle_required', MagicMock(return_value=False))
    @patch('remote_reseat.SonicUtility.execute_sfputil_lpmode', MagicMock())
    @patch('remote_reseat.SonicUtility.execute_interface_startup', MagicMock(return_value=True))
    @patch('remote_reseat.SonicUtility.get_interface_oper_status', MagicMock(return_value="down"))
    def test_remote_reseat_link_up_verification_failure(self):
        self.assertEqual(self.checkFailWithoutSysExit(['-p Ethernet0']), remote_reseat.ERROR_INTERFACE_OPER_STATUS_UP)

    @patch('remote_reseat.RemoteReseat.verify_prerequisites', MagicMock(return_value=0))
    @patch('remote_reseat.RemoteReseat.shutdown_interface_and_verify_link_down', MagicMock())
    @patch('remote_reseat.SonicUtility.execute_sfputil_reset', MagicMock(return_value=True))
    @patch('remote_reseat.SonicUtility.is_lpmode_toggle_required', MagicMock(return_value=False))
    @patch('remote_reseat.SonicUtility.execute_sfputil_lpmode', MagicMock())
    @patch('remote_reseat.SonicUtility.execute_interface_startup', MagicMock(return_value=True))
    @patch('remote_reseat.SonicUtility.wait_until', MagicMock(return_value=True))
    def test_remote_reseat_success(self):
        self.assertEqual(self.checkPass(['-p Ethernet0']), 0)

    @patch('remote_reseat.RemoteReseat.verify_prerequisites', MagicMock(return_value=0))
    @patch('remote_reseat.RemoteReseat.shutdown_interface_and_verify_link_down', MagicMock())
    @patch('remote_reseat.SonicUtility.execute_sfputil_reset', MagicMock(return_value=True))
    @patch('remote_reseat.SonicUtility.is_lpmode_toggle_required', MagicMock(return_value=False))
    @patch('remote_reseat.SonicUtility.execute_sfputil_lpmode', MagicMock())
    @patch('remote_reseat.SonicUtility.execute_interface_startup', MagicMock(return_value=True))
    @patch('remote_reseat.SonicUtility.wait_until', MagicMock(return_value=True))
    def test_remote_reseat_success_with_multiple_ports(self):
        self.assertEqual(self.checkPass(['-p', 'Ethernet0', 'Ethernet2', 'Ethernet4']), 0)

    @patch('remote_reseat.RemoteReseat.verify_prerequisites', MagicMock(return_value=0))
    @patch('remote_reseat.RemoteReseat.shutdown_interface_and_verify_link_down', MagicMock())
    @patch('remote_reseat.SonicUtility.execute_sfputil_reset', MagicMock(side_effect=(True, False, False, False)))
    @patch('remote_reseat.SonicUtility.is_lpmode_toggle_required', MagicMock(return_value=False))
    @patch('remote_reseat.SonicUtility.execute_sfputil_lpmode', MagicMock())
    @patch('remote_reseat.SonicUtility.execute_interface_startup', MagicMock(return_value=True))
    def test_remote_reseat_failure_for_1_port(self):
        self.assertEqual(self.checkFailWithoutSysExit(['-p', 'Ethernet0', 'Ethernet2', 'r', '3']), remote_reseat.ERROR_SFPUTIL_RESET)
        assert remote_reseat.SonicUtility.execute_interface_startup.call_count == 4

    @patch('remote_reseat.RemoteReseat.verify_prerequisites', MagicMock(return_value=0))
    @patch('remote_reseat.RemoteReseat.shutdown_interface_and_verify_link_down', MagicMock())
    @patch('remote_reseat.SonicUtility.execute_sfputil_reset', MagicMock(return_value=True))
    @patch('remote_reseat.SonicUtility.is_lpmode_toggle_required', MagicMock(return_value=False))
    @patch('remote_reseat.SonicUtility.execute_sfputil_lpmode', MagicMock())
    @patch('remote_reseat.SonicUtility.execute_interface_startup', MagicMock(return_value=True))
    @patch('remote_reseat.SonicUtility.wait_until', MagicMock())
    def test_remote_reseat_success_with_link_up_verification_skipped(self):
        self.assertEqual(self.checkPass(['-p', 'Ethernet0', '-d']), 0)
        assert remote_reseat.SonicUtility.wait_until.call_count == 0

if __name__ == '__main__':
    unittest.main()
