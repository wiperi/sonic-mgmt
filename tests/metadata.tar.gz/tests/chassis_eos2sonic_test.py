#!/usr/bin/env python
# Copyright (c) 2021 Arista Networks, Inc.  All rights reserved.
# Arista Networks, Inc. Confidential and Proprietary.

from __future__ import absolute_import, division, print_function
import os
import sys
import tempfile
import unittest
from io import StringIO

from mock import Mock, patch
# find absolute path of chassis_eos2sonic
chassis_eos2sonic_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
sys.path.insert(0, chassis_eos2sonic_path)
import chassis_eos2sonic

class TestBase(unittest.TestCase):
    def checkCmd(self, success, testargs, sysExit=True, raiseException=False):
        with patch('sys.stdout', new=StringIO()) as stdOutput:
            with patch.object(os, 'getuid', return_value=0):
                if raiseException:
                    with self.assertRaises(Exception) as e:
                        chassis_eos2sonic.main(
                            chassis_eos2sonic.parseArgs(testargs))
                elif sysExit:
                    with self.assertRaises(SystemExit) as cm:
                        chassis_eos2sonic.main(
                            chassis_eos2sonic.parseArgs(testargs))
                        if success:
                            self.assertTrue(cm.exception.code == 0)
                        else:
                            self.assertTrue(cm.exception.code != 0)
                else:
                    chassis_eos2sonic.main(
                        chassis_eos2sonic.parseArgs(testargs))

        return stdOutput.getvalue().strip()

    def checkPass(self, testargs):
        return self.checkCmd(True, testargs, sysExit=True)

    def checkFail(self, testargs):
        return self.checkCmd(False, testargs, sysExit=True)

    def checkException(self, testargs):
        return self.checkCmd(False, testargs, sysExit=False, raiseException=True)

    def checkReturn(self, testargs):
        return self.checkCmd(True, testargs, sysExit=False)


# TODO: Re-enable this test later this test does not work in python2.7
# class ParamsTest(TestBase):
#     def testHelp(self):
#         import pdb; pdb.set_trace()
#         output = self.checkPass(['-h'])
#         self.assertIn(
#             'Helper script to convert a chassis running EOS to SONiC', output)


class MiscTest(unittest.TestCase):
    def testParseKvLines(self):
        result = chassis_eos2sonic.parseKvLines([
            'foo: bar',
            'baz',
            'test: me'
        ])
        self.assertEqual({'foo': 'bar', 'test': 'me'}, result)

    def testParseKvFile(self):
        with tempfile.NamedTemporaryFile() as f:
            f.write(b'foo: bar\nbaz\ntest: me\n')
            f.flush()
            self.assertEqual({'foo': 'bar', 'test': 'me'},
                             chassis_eos2sonic.parseKvFile(f.name))

    def testReadFileContentsInt(self):
        with tempfile.NamedTemporaryFile() as f:
            f.write(b'42\n')
            f.flush()
            self.assertEqual(42,
                             chassis_eos2sonic.readFileContents(f.name, conv=int))


class ErrorCodeTest(unittest.TestCase):
    def testCodesUnique(self):
        errorCodes = [x for x in chassis_eos2sonic.__dict__.keys()
                      if x.startswith('ERR')]
        found = []
        for errorName in errorCodes:
            ec = getattr(chassis_eos2sonic, errorName)
            self.assertNotIn(ec, found)
            found.append(ec)

    def testCodeHasMsg(self):
        errorCodes = [x for x in chassis_eos2sonic.__dict__.keys()
                      if x.startswith('ERR')]
        for errorName in errorCodes:
            self.assertNotEqual(
                chassis_eos2sonic.ProvisioningError(
                    getattr(chassis_eos2sonic, errorName)).msg,
                'Unknown')

    @patch('chassis_eos2sonic.isRootUser', return_value=False)
    def testErrorAndExit(self, isRootUserMock):
        ret = chassis_eos2sonic.main(['install-local'])
        self.assertEqual(ret, chassis_eos2sonic.ERR_NOT_ROOT_USER)

    @patch('chassis_eos2sonic.isRootUser', return_value=True)
    @patch('chassis_eos2sonic.OperatingSystem.detect', return_value=None)
    def testErrorAndExit2(self, isRootUserMock, osDetectMock):
        ret = chassis_eos2sonic.main(['install-local'])
        self.assertEqual(ret, chassis_eos2sonic.ERR_FAILED_OS_DETECTION)
