import sys
import pytest
from unittest.mock import call, patch, MagicMock

sys.modules['sonic_platform'] = MagicMock()
sys.modules['sonic_py_common'] = MagicMock()

POSTUPGRADE_ACTIONS_DATA_DIR = '/postupgrade_actions_data_dir'

from postupgrade_actions import fix_rsyslog_plugin_config

class TestFixRsyslogPluginConfig(object):
    def setup_method(self):
        print('SETUP')

    def teardown_method(self):
        print('TEAR DOWN')

    @patch('postupgrade_actions.get_sonic_version_info')
    @patch('postupgrade_actions.exec_cmd')
    @patch('postupgrade_actions.POSTUPGRADE_ACTIONS_DATA_DIR', POSTUPGRADE_ACTIONS_DATA_DIR)
    def test_fix_rsyslog_plugin_config_version_correct(self, mock_cmd, mock_version_info):
        '''
        Test fix_rsyslog_plugin_config
        The build version is 20230531.20, postupgrade_actions should apply the fix
        '''
        mock_version_info.return_value = {'build_version': '20230531.20'}

        mock_cmd.side_effect = [
            (0, 'eventd\ngnmi\ntelemetry\nbgp\nswss'),
            (0, 'exected sudo chmod a+r {}/host_events.conf'.format(POSTUPGRADE_ACTIONS_DATA_DIR)),
            (0, 'executed sudo cp {}/host_events.conf /etc/rsyslog.d/'.format(POSTUPGRADE_ACTIONS_DATA_DIR)),
            (0, 'exected sudo chmod a+r {}/bgp_events.conf'.format(POSTUPGRADE_ACTIONS_DATA_DIR)),
            (0, 'executed docker cp {}/bgp_events.conf bgp:/etc/rsyslog.d/'.format(POSTUPGRADE_ACTIONS_DATA_DIR)),
            (0, 'exected sudo chmod a+r {}/swss_events.conf'.format(POSTUPGRADE_ACTIONS_DATA_DIR)),
            (0, 'executed docker cp {}/swss_events.conf swss:/etc/rsyslog.d/'.format(POSTUPGRADE_ACTIONS_DATA_DIR)),
            (0, 'exected sudo chmod a+r {}/dhcp_relay_events.conf'.format(POSTUPGRADE_ACTIONS_DATA_DIR)),
            (0, 'executed docker cp {}/dhcp_relay_events.conf dhcp_relay:/etc/rsyslog.d/'.format(POSTUPGRADE_ACTIONS_DATA_DIR)),
            (0, 'executed sudo systemctl reset-failed rsyslog'),
            (0, 'executed sudo systemctl restart rsyslog'),
            (0, '55'),
            (0, 'executed docker exec bgp kill -9 55'),
            (0, 'rsyslogd: stopped\nrsyslogd: started'),
            (0, '56'),
            (0, 'executed docker exec swss kill -9 56'),
            (0, 'rsyslogd: stopped\nrsyslogd: started'),
            (0, '57'),
            (0, 'executed docker exec dhcp_relay kill -9 57'),
            (0, 'rsyslogd: stopped\nrsyslogd: started'),
        ]

        fix_rsyslog_plugin_config()
        assert len(mock_cmd.call_args_list) == 20

        assert mock_cmd.call_args_list == [
            call("docker ps -a --format \{\{.Names\}\}"),
            call("sudo chmod a+r {}/host_events.conf".format(POSTUPGRADE_ACTIONS_DATA_DIR)),
            call("sudo cp {}/host_events.conf /etc/rsyslog.d/".format(POSTUPGRADE_ACTIONS_DATA_DIR)),
            call("sudo chmod a+r {}/bgp_events.conf".format(POSTUPGRADE_ACTIONS_DATA_DIR)),
            call("docker cp {}/bgp_events.conf bgp:/etc/rsyslog.d/".format(POSTUPGRADE_ACTIONS_DATA_DIR)),
            call("sudo chmod a+r {}/swss_events.conf".format(POSTUPGRADE_ACTIONS_DATA_DIR)),
            call("docker cp {}/swss_events.conf swss:/etc/rsyslog.d/".format(POSTUPGRADE_ACTIONS_DATA_DIR)),
            call("sudo chmod a+r {}/dhcp_relay_events.conf".format(POSTUPGRADE_ACTIONS_DATA_DIR)),
            call("docker cp {}/dhcp_relay_events.conf dhcp_relay:/etc/rsyslog.d/".format(POSTUPGRADE_ACTIONS_DATA_DIR)),
            call("sudo systemctl reset-failed rsyslog"),
            call("sudo systemctl restart rsyslog"),
            call("docker exec bgp ps auxww | grep rsyslog_plugin | awk '{print $2}'"),
            call("docker exec bgp kill -9 55"),
            call("docker exec bgp supervisorctl restart rsyslogd"),
            call("docker exec swss ps auxww | grep rsyslog_plugin | awk '{print $2}'"),
            call("docker exec swss kill -9 56"),
            call("docker exec swss supervisorctl restart rsyslogd"),
            call("docker exec dhcp_relay ps auxww | grep rsyslog_plugin | awk '{print $2}'"),
            call("docker exec dhcp_relay kill -9 57"),
            call("docker exec dhcp_relay supervisorctl restart rsyslogd")
        ]

    @patch('postupgrade_actions.get_sonic_version_info')
    @patch('postupgrade_actions.exec_cmd')
    def test_fix_rsyslog_plugin_config_version_incorrect(self, mock_cmd, mock_version_info):
        '''
        Test fix_rsyslog_plugin_config
        The build version is 20230531.28, postupgrade_actions should not apply the fix
        '''
        mock_version_info.return_value = {'build_version': '20230531.28'}
        fix_rsyslog_plugin_config()
        assert len(mock_cmd.call_args_list) == 0


    @patch('postupgrade_actions.get_sonic_version_info')
    @patch('postupgrade_actions.exec_cmd')
    def test_fix_rsyslog_plugin_config_version_incorrect_02(self, mock_cmd, mock_version_info):
        '''
        Test fix_rsyslog_plugin_config
        The build version is 20220531.49, postupgrade_actions should not apply the fix
        '''
        mock_version_info.return_value = {'build_version': '20220531.49'}
        fix_rsyslog_plugin_config()
        assert len(mock_cmd.call_args_list) == 0


    @patch('postupgrade_actions.get_sonic_version_info')
    @patch('postupgrade_actions.exec_cmd')
    def test_fix_rsyslog_plugin_config_slim_image(self, mock_cmd, mock_version_info):
        '''
        Test fix_rsyslog_plugin_config
        The build version is 20230531.20, postupgrade_actions should apply the fix
        '''
        mock_version_info.return_value = {'build_version': '20230531.20'}
        mock_cmd.side_effect = [
            (0, 'gnmi\ntelemetry\nbgp\nswss'),
        ]

        fix_rsyslog_plugin_config()
        assert len(mock_cmd.call_args_list) == 1

        assert mock_cmd.call_args_list == [
            call("docker ps -a --format \{\{.Names\}\}"),
        ]

    @patch('postupgrade_actions.get_sonic_version_info')
    @patch('postupgrade_actions.exec_cmd')
    @patch('postupgrade_actions.POSTUPGRADE_ACTIONS_DATA_DIR', POSTUPGRADE_ACTIONS_DATA_DIR)
    def test_fix_rsyslog_plugin_config_services_not_running(self, mock_cmd, mock_version_info):
        '''
        Test fix_rsyslog_plugin_config
        The build version is 20230531.20, postupgrade_actions should apply the fix
        '''
        mock_version_info.return_value = {'build_version': '20230531.20'}

        mock_cmd.side_effect = [
            (0, 'eventd\ngnmi\ntelemetry\nbgp\nswss'),
            (0, 'exected sudo chmod a+r {}/host_events.conf'.format(POSTUPGRADE_ACTIONS_DATA_DIR)),
            (0, 'executed sudo cp {}/host_events.conf /etc/rsyslog.d/'.format(POSTUPGRADE_ACTIONS_DATA_DIR)),
            (0, 'exected sudo chmod a+r {}/bgp_events.conf'.format(POSTUPGRADE_ACTIONS_DATA_DIR)),
            (0, 'executed docker cp {}/bgp_events.conf bgp:/etc/rsyslog.d/'.format(POSTUPGRADE_ACTIONS_DATA_DIR)),
            (0, 'exected sudo chmod a+r {}/swss_events.conf'.format(POSTUPGRADE_ACTIONS_DATA_DIR)),
            (0, 'executed docker cp {}/swss_events.conf swss:/etc/rsyslog.d/'.format(POSTUPGRADE_ACTIONS_DATA_DIR)),
            (0, 'exected sudo chmod a+r {}/dhcp_relay_events.conf'.format(POSTUPGRADE_ACTIONS_DATA_DIR)),
            (0, 'executed docker cp {}/dhcp_relay_events.conf dhcp_relay:/etc/rsyslog.d/'.format(POSTUPGRADE_ACTIONS_DATA_DIR)),
            (0, 'executed sudo systemctl reset-failed rsyslog'),
            (0, 'executed sudo systemctl restart rsyslog'),
            (1, 'Container 123 is not running.'),
            (1, 'Container 456 is not running'),
            (1, 'Container 789 is not running')
        ]

        fix_rsyslog_plugin_config()
        assert len(mock_cmd.call_args_list) == 14

        assert mock_cmd.call_args_list == [
            call("docker ps -a --format \{\{.Names\}\}"),
            call("sudo chmod a+r {}/host_events.conf".format(POSTUPGRADE_ACTIONS_DATA_DIR)),
            call("sudo cp {}/host_events.conf /etc/rsyslog.d/".format(POSTUPGRADE_ACTIONS_DATA_DIR)),
            call("sudo chmod a+r {}/bgp_events.conf".format(POSTUPGRADE_ACTIONS_DATA_DIR)),
            call("docker cp {}/bgp_events.conf bgp:/etc/rsyslog.d/".format(POSTUPGRADE_ACTIONS_DATA_DIR)),
            call("sudo chmod a+r {}/swss_events.conf".format(POSTUPGRADE_ACTIONS_DATA_DIR)),
            call("docker cp {}/swss_events.conf swss:/etc/rsyslog.d/".format(POSTUPGRADE_ACTIONS_DATA_DIR)),
            call("sudo chmod a+r {}/dhcp_relay_events.conf".format(POSTUPGRADE_ACTIONS_DATA_DIR)),
            call("docker cp {}/dhcp_relay_events.conf dhcp_relay:/etc/rsyslog.d/".format(POSTUPGRADE_ACTIONS_DATA_DIR)),
            call("sudo systemctl reset-failed rsyslog"),
            call("sudo systemctl restart rsyslog"),
            call("docker exec bgp ps auxww | grep rsyslog_plugin | awk '{print $2}'"),
            call("docker exec swss ps auxww | grep rsyslog_plugin | awk '{print $2}'"),
            call("docker exec dhcp_relay ps auxww | grep rsyslog_plugin | awk '{print $2}'")
        ]

    @patch('postupgrade_actions.get_sonic_version_info')
    @patch('postupgrade_actions.exec_cmd')
    @patch('postupgrade_actions.POSTUPGRADE_ACTIONS_DATA_DIR', POSTUPGRADE_ACTIONS_DATA_DIR)
    def test_fix_rsyslog_plugin_config_plugins_not_running(self, mock_cmd, mock_version_info):
        '''
        Test fix_rsyslog_plugin_config
        The build version is 20230531.20, postupgrade_actions should apply the fix
        '''
        mock_version_info.return_value = {'build_version': '20230531.20'}

        mock_cmd.side_effect = [
            (0, 'eventd\ngnmi\ntelemetry\nbgp\nswss'),
            (0, 'exected sudo chmod a+r {}/host_events.conf'.format(POSTUPGRADE_ACTIONS_DATA_DIR)),
            (0, 'executed sudo cp {}/host_events.conf /etc/rsyslog.d/'.format(POSTUPGRADE_ACTIONS_DATA_DIR)),
            (0, 'exected sudo chmod a+r {}/bgp_events.conf'.format(POSTUPGRADE_ACTIONS_DATA_DIR)),
            (0, 'executed docker cp {}/bgp_events.conf bgp:/etc/rsyslog.d/'.format(POSTUPGRADE_ACTIONS_DATA_DIR)),
            (0, 'exected sudo chmod a+r {}/swss_events.conf'.format(POSTUPGRADE_ACTIONS_DATA_DIR)),
            (0, 'executed docker cp {}/swss_events.conf swss:/etc/rsyslog.d/'.format(POSTUPGRADE_ACTIONS_DATA_DIR)),
            (0, 'exected sudo chmod a+r {}/dhcp_relay_events.conf'.format(POSTUPGRADE_ACTIONS_DATA_DIR)),
            (0, 'executed docker cp {}/dhcp_relay_events.conf dhcp_relay:/etc/rsyslog.d/'.format(POSTUPGRADE_ACTIONS_DATA_DIR)),
            (0, 'executed sudo systemctl reset-failed rsyslog'),
            (0, 'executed sudo systemctl restart rsyslog'),
            (0, ''),
            (0, 'rsyslogd: stopped\nrsyslogd: started'),
            (0, ''),
            (0, 'rsyslogd: stopped\nrsyslogd: started'),
            (0, ''),
            (0, 'rsyslogd: stopped\nrsyslogd: started')
        ]

        fix_rsyslog_plugin_config()
        assert len(mock_cmd.call_args_list) == 17

        assert mock_cmd.call_args_list == [
            call("docker ps -a --format \{\{.Names\}\}"),
            call("sudo chmod a+r {}/host_events.conf".format(POSTUPGRADE_ACTIONS_DATA_DIR)),
            call("sudo cp {}/host_events.conf /etc/rsyslog.d/".format(POSTUPGRADE_ACTIONS_DATA_DIR)),
            call("sudo chmod a+r {}/bgp_events.conf".format(POSTUPGRADE_ACTIONS_DATA_DIR)),
            call("docker cp {}/bgp_events.conf bgp:/etc/rsyslog.d/".format(POSTUPGRADE_ACTIONS_DATA_DIR)),
            call("sudo chmod a+r {}/swss_events.conf".format(POSTUPGRADE_ACTIONS_DATA_DIR)),
            call("docker cp {}/swss_events.conf swss:/etc/rsyslog.d/".format(POSTUPGRADE_ACTIONS_DATA_DIR)),
            call("sudo chmod a+r {}/dhcp_relay_events.conf".format(POSTUPGRADE_ACTIONS_DATA_DIR)),
            call("docker cp {}/dhcp_relay_events.conf dhcp_relay:/etc/rsyslog.d/".format(POSTUPGRADE_ACTIONS_DATA_DIR)),
            call("sudo systemctl reset-failed rsyslog"),
            call("sudo systemctl restart rsyslog"),
            call("docker exec bgp ps auxww | grep rsyslog_plugin | awk '{print $2}'"),
            call("docker exec bgp supervisorctl restart rsyslogd"),
            call("docker exec swss ps auxww | grep rsyslog_plugin | awk '{print $2}'"),
            call("docker exec swss supervisorctl restart rsyslogd"),
            call("docker exec dhcp_relay ps auxww | grep rsyslog_plugin | awk '{print $2}'"),
            call("docker exec dhcp_relay supervisorctl restart rsyslogd")
        ]
