import sys
import pytest
from unittest.mock import call, patch, mock_open, MagicMock

sys.modules['sonic_platform'] = MagicMock()
sys.modules['sonic_py_common'] = MagicMock()
from preinit_actions import fix_load_mgmt_config, verify_load_mgmt_config_code

CONFIG_MAIN_PATH = "/usr/local/lib/python3.9/dist-packages/config/main.py"
CONFIG_MAIN_BACKUP_PATH = CONFIG_MAIN_PATH + ".bak"
BACKUP_CMD = 'sudo cp {} {}'.format(CONFIG_MAIN_PATH, CONFIG_MAIN_BACKUP_PATH)
RESTORE_CMD = 'sudo cp {} {}'.format(CONFIG_MAIN_BACKUP_PATH, CONFIG_MAIN_PATH)

REMOVE_CMD = r"""sed -i "/^            sys.exit('File {{}} does not exist'.format(filepath))/,+9d" {}""".format(CONFIG_MAIN_PATH)

ADD_CMD = r"""sed -i 's/^        if not os.path.isfile(filepath):/        if os.path.isfile(filepath):\
            out0, rc0 = clicommon.run_command(["cat", filepath], display_cmd=True, return_cmd=True)\
            if rc0 != 0:\
                sys.exit("Exit: {{}}. Command: cat {{}} failed.".format(rc0, filepath))\
\
            out1, rc1 = clicommon.run_command(["kill", str(out0).strip("\\n")], display_cmd=True, return_cmd=True)\
            if rc1 != 0:\
                sys.exit("Exit: {{}}. Command: kill {{}} failed.".format(rc1, out0))\
            clicommon.run_command(["rm", "-f", filepath], display_cmd=True, return_cmd=True)/' {}""".format(CONFIG_MAIN_PATH)

MOCK_FILE_CONTENT = r"""        filepath = '/var/run/dhclient.eth0.pid'
        if os.path.isfile(filepath):
            out0, rc0 = clicommon.run_command(["cat", filepath], display_cmd=True, return_cmd=True)
            if rc0 != 0:
                sys.exit("Exit: {}. Command: cat {} failed.".format(rc0, filepath))

            out1, rc1 = clicommon.run_command(["kill", str(out0).strip("\n")], display_cmd=True, return_cmd=True)
            if rc1 != 0:
                sys.exit("Exit: {}. Command: kill {} failed.".format(rc1, out0))
            clicommon.run_command(["rm", "-f", filepath], display_cmd=True, return_cmd=True)
    click.echo("Please note loaded setting will be lost after system reboot. To preserve setting, run `config save`.")"""

MOCK_FILE_INCORRECT_CONTENT = """        filepath = '/var/run/dhclient.eth0.pid'
    click.echo("Please note loaded setting will be lost after system reboot. To preserve setting, run `config save`.")"""


class TestFixLoadMgmtConfig(object):
    def setup_method(self):
        print('SETUP')

    @patch('preinit_actions.log_error')
    @patch('preinit_actions.log_info')
    @patch('preinit_actions.exec_cmd')
    @patch('preinit_actions.verify_load_mgmt_config_code', MagicMock(return_value=True))
    @patch('preinit_actions.greater_than', MagicMock(return_value=False))
    @patch('sonic_py_common.get_sonic_version_info', MagicMock(return_value={'build_version': '20230531.08'}))
    def test_fix_load_mgmt_config_skip_patch(self, mock_exec_cmd, mock_log_info, mock_log_error):
        fix_load_mgmt_config()
        print(mock_log_info.call_args_list)

        assert mock_log_info.call_args_list == [
            call('fix_load_mgmt_config: already fixed, skipping.')
        ]

        mock_exec_cmd.assert_not_called()
        mock_log_error.assert_not_called()

    @patch('preinit_actions.log_error')
    @patch('preinit_actions.log_info')
    @patch('preinit_actions.exec_cmd')
    @patch('preinit_actions.verify_load_mgmt_config_code')
    @patch('preinit_actions.greater_than', MagicMock(return_value=False))
    @patch('sonic_py_common.get_sonic_version_info', MagicMock(return_value={'build_version': '20230531.08'}))
    def test_fix_load_mgmt_config_success_patch(self, mock_verify_load_mgmt_config_code, mock_exec_cmd, mock_log_info, mock_log_error):
        mock_verify_load_mgmt_config_code.side_effect = [False, True]
        fix_load_mgmt_config()
        print(mock_exec_cmd.call_args_list)
        print(mock_log_info.call_args_list)

        assert mock_exec_cmd.call_args_list == [
            call(BACKUP_CMD),
            call(REMOVE_CMD),
            call(ADD_CMD)
        ]

        assert mock_log_info.call_args_list == [
            call('fix_load_mgmt_config: backup config/main.py file successfully'),
            call('fix_load_mgmt_config: config/main.py file has been patched successfully')
        ]

        mock_log_error.assert_not_called()

    @patch('preinit_actions.log_error')
    @patch('preinit_actions.log_info')
    @patch('preinit_actions.exec_cmd')
    @patch('preinit_actions.verify_load_mgmt_config_code', MagicMock(return_value=False))
    @patch('preinit_actions.greater_than', MagicMock(return_value=False))
    @patch('sonic_py_common.get_sonic_version_info', MagicMock(return_value={'build_version': '20230531.08'}))
    def test_fix_load_mgmt_config_failed_patch(self, mock_exec_cmd, mock_log_info, mock_log_error):
        fix_load_mgmt_config()
        print(mock_exec_cmd.call_args_list)
        print(mock_log_info.call_args_list)
        print(mock_log_error.call_args_list)

        assert mock_exec_cmd.call_args_list == [
            call(BACKUP_CMD),
            call(REMOVE_CMD),
            call(ADD_CMD),
            call(RESTORE_CMD)
        ]

        assert mock_log_info.call_args_list == [
            call('fix_load_mgmt_config: backup config/main.py file successfully')
        ]

        assert mock_log_error.call_args_list == [
            call('fix_load_mgmt_config: failed to patch config/main.py file')
        ]

    def teardown_method(self):
        print('TEAR DOWN')


class TestVerifyLoadMgmtConfigCode(object):
    def setup_method(self):
        print('SETUP')

    @patch('preinit_actions.log_error')
    @patch("builtins.open", new_callable=mock_open, read_data=MOCK_FILE_CONTENT)
    def test_verify_load_mgmt_config_success(self, mock_file, mock_log_error):
        assert verify_load_mgmt_config_code("config/main.py")
        mock_log_error.assert_not_called()

    @patch('preinit_actions.log_error')
    @patch("builtins.open", new_callable=mock_open, read_data=MOCK_FILE_INCORRECT_CONTENT)
    def test_verify_load_mgmt_config_incorrect_content(self, mock_file, mock_log_error):
        assert not verify_load_mgmt_config_code("config/main.py")
        mock_log_error.assert_not_called()

    @patch('preinit_actions.log_error')
    @patch("builtins.open", side_effect=FileNotFoundError("File Not Found"))
    def test_verify_load_mgmt_config_code_file_not_found_error(self, mock_file, mock_log_error):
        assert not verify_load_mgmt_config_code("config/main.py")
        print(mock_log_error.call_args_list)
        assert mock_log_error.call_args_list == [
            call("verify_load_mgmt_config_code: Error accessing file {}: {}".format("config/main.py", "File Not Found"))
        ]

    @patch('preinit_actions.log_error')
    @patch("builtins.open", side_effect=PermissionError("Permission Denied"))
    def test_verify_load_mgmt_config_code_permission_error(self, mock_file, mock_log_error):
        assert not verify_load_mgmt_config_code("config/main.py")
        print(mock_log_error.call_args_list)
        assert mock_log_error.call_args_list == [
            call("verify_load_mgmt_config_code: Error accessing file {}: {}".format("config/main.py", "Permission Denied"))
        ]

    @patch('preinit_actions.log_error')
    @patch("builtins.open", side_effect=IOError("IO Error"))
    def test_verify_load_mgmt_config_code_io_error(self, mock_file, mock_log_error):
        assert not verify_load_mgmt_config_code("config/main.py")
        print(mock_log_error.call_args_list)
        assert mock_log_error.call_args_list == [
            call("verify_load_mgmt_config_code: Error accessing file {}: {}".format("config/main.py", "IO Error"))
        ]

    def teardown_method(self):
        print('TEAR DOWN')

