#!/usr/bin/env python

import os
import sys
import unittest
from io import BytesIO
from mock import patch, Mock
import time

sys.path.insert( 0, '..' )
sys.modules[ 'swsssdk' ] = Mock()
sys.modules['sonic_py_common'] = Mock()
time.sleep = Mock()
import traffic_shift

SAMPLE_SONIC_INSTALLER_LIST=" Current: SONiC-OS-20191130.84 \
                              Next: SONiC-OS-20191130.84 \
                              Available: \
                              SONiC-OS-20191130.84 \
                              SONiC-OS-20220531.01"
INVALID_SONIC_INSTALLER_LIST="Next: SONiC-OS-20191130.84 \
                              Available: \
                              SONiC-OS-20191130.84"                              
UNSUPPORTED_SONIC_INSTALLER_LIST=" Current: SONiC-OS-20181130.95 \
                              Next: SONiC-OS-20181130.95 \
                              Available: \
                              SONiC-OS-20181130.95"                              
TSC_RETURN_MAINTENANCE=[traffic_shift.RET_SUCCESS, "System Mode: Maintenance", None]
TSC_RETURN_NORMAL=[traffic_shift.RET_SUCCESS, "System Mode: Normal", None]

class TestBase(unittest.TestCase):
   def checkCmd(self, success, testargs, sysExit=True, uid=0):
      with patch('sys.stdout', new=BytesIO()) as stdOutput:
         testargs = [ './traffic_shift' ] + testargs
         with patch.object(sys, 'argv', testargs):
            with patch.object(os, 'geteuid', return_value=uid):
                if sysExit:
                    with self.assertRaises(SystemExit) as cm:
                        traffic_shift.main()
                    if success:
                        self.assertTrue(cm.exception.code == 0)
                    else:
                        self.assertTrue(cm.exception.code != 0)
                else:
                    traffic_shift.main()

      return stdOutput.getvalue().strip()

   def checkPass( self, testargs):
      return self.checkCmd( True, testargs, sysExit=True) 

   def checkFail(self, testargs):
      return self.checkCmd(False, testargs, sysExit=True)

   def checkReturn(self, testargs, userID=0):
      return self.checkCmd(True, testargs, sysExit=False, uid=userID)

class ParamsTest( TestBase ):
   def test_help(self):
      output = self.checkPass( [ '-h' ])
      self.assertIn( 'usage', output)

   def test_dryrun(self):
      output = self.checkFail( [ '--dryrun' ])
      self.assertIn('Usage', output)

   def test_invalid_oper(self):
      output = self.checkFail( ['check'])
      self.assertIn("Unsupported operation", output)

   def test_invalid_option(self):
      output = self.checkFail( [ 'away', '--force_bgp_bringup' ])
      self.assertIn('force_bgp_bringup is only supported with traffic_shift back', output)

   def test_unsupported_image(self):
      with patch('traffic_shift.check_version_for_tsa_support', return_value=False):
         output = self.checkReturn(['away'])
         self.assertIn('Device isolation using TSA is not supported in OS version', output)

   def test_non_sudo_caller(self):
      output = self.checkReturn(['away'], userID=1000)
      self.assertIn('Root privileges are required for this operation', output)

   def test_dryrun_tsa(self):
      with patch('traffic_shift.check_version_for_tsa_support', return_value=True):
         output = self.checkReturn( [ 'away', '--dryrun' ])
         self.assertIn('DRYRUN', output)
         self.assertIn('TSA', output)
         self.assertIn('config save',output)
         self.assertIn('Device isolation complete', output)

   def test_dryrun_tsb(self):
      with patch('traffic_shift.check_version_for_tsa_support', return_value=True):
         with patch('traffic_shift.bgp_session_bringup_required', return_value=False):
            output = self.checkReturn( [ 'back', '--dryrun' ])
            self.assertIn('DRYRUN', output)
            self.assertIn('TSB', output)
            self.assertIn('config save',output)
            self.assertIn('Device un-isolation complete', output)

   def test_dryrun_tsb_forcebgpbringup(self):
      with patch('traffic_shift.check_version_for_tsa_support', return_value=True):         
         output = self.checkReturn( [ 'back', '--force_bgp_bringup', '--dryrun' ])         
         self.assertIn('./bgp_neighbor startup 0.0.0.0 --dryrun', output)
         self.assertIn('DRYRUN', output)
         self.assertIn('TSB', output)
         self.assertIn('config save',output)
         self.assertIn('Device un-isolation complete', output)

   def test_get_current_os_version(self):
      sonic_os = traffic_shift.get_current_os_version(SAMPLE_SONIC_INSTALLER_LIST)
      self.assertIn('20191130', sonic_os)
      sonic_os = traffic_shift.get_current_os_version(INVALID_SONIC_INSTALLER_LIST)
      self.assertIs('',sonic_os)

   def test_check_version_for_tsa_support(self):
      with patch('traffic_shift.exec_cmd', 
                  return_value=[traffic_shift.RET_SUCCESS, 
                                 SAMPLE_SONIC_INSTALLER_LIST, 
                                 None]):
         self.assertTrue(traffic_shift.check_version_for_tsa_support())
      with patch('traffic_shift.exec_cmd', 
                  return_value=[traffic_shift.RET_SUCCESS, 
                          UNSUPPORTED_SONIC_INSTALLER_LIST, 
                          None]):
         self.assertFalse(traffic_shift.check_version_for_tsa_support())

   def test_process_traffic_shift(self):  
      ret = traffic_shift.process_traffic_shift('TSA', dryrun=True)
      self.assertTrue(ret == traffic_shift.RET_SUCCESS)
      with patch('traffic_shift.exec_cmd', return_value=[traffic_shift.RET_FAILED, '', None]):         
         ret = traffic_shift.process_traffic_shift('TSA', dryrun=True)
         self.assertTrue(ret == traffic_shift.RET_FAILED)

   def test_wait_for_traffic_state_update(self):            
      with patch('traffic_shift.exec_cmd', return_value=TSC_RETURN_MAINTENANCE):       
         ret = traffic_shift.wait_for_traffic_state_update('TSA', False)
         self.assertIs(ret, traffic_shift.RET_SUCCESS)
      with patch('traffic_shift.exec_cmd', return_value=TSC_RETURN_NORMAL):
         ret = traffic_shift.wait_for_traffic_state_update('TSB', False)
         self.assertIs(ret, traffic_shift.RET_SUCCESS)

   def test_failed_wait_for_traffic_state_update(self):
      with patch('traffic_shift.exec_cmd', return_value=TSC_RETURN_NORMAL):        
         ret = traffic_shift.wait_for_traffic_state_update('TSA', False)
         self.assertIs(ret, traffic_shift.RET_FAILED)
      with patch('traffic_shift.exec_cmd', return_value=TSC_RETURN_MAINTENANCE): 
         ret = traffic_shift.wait_for_traffic_state_update('TSB', False)
         self.assertIs(ret, traffic_shift.RET_FAILED)

   def test_bgp_session_bringup_required(self):
      with patch('traffic_shift.multi_asic.is_multi_asic', return_value=False):         
         with patch('traffic_shift.ConfigDBConnector') as config_db:
            with patch.object(config_db(), 'get_entry', 
                  return_value={'default_bgp_status':"up"}):               
               self.assertFalse(traffic_shift.bgp_session_bringup_required())
            with patch.object(config_db(), 'get_entry', 
                  return_value={'default_bgp_status':"down"}):               
               self.assertTrue(traffic_shift.bgp_session_bringup_required())
            with patch.object(config_db(), 'get_table', 
                  return_value={'10.0.0.0': {'admin_status': 'up', 'asn': '65200'}}):
               self.assertFalse(traffic_shift.bgp_session_bringup_required())
   
   def test_bgp_session_bringup_required_multi_asic(self):
      with patch('traffic_shift.multi_asic') as multi_asic:
         multi_asic.is_multi_asic = Mock(return_value=True)
         multi_asic.get_all_namespaces = Mock(return_value={'front_ns':['asic0','asic1']})       
         with patch('traffic_shift.ConfigDBConnector') as config_db:
            with patch.object(config_db(), 'get_entry', 
                  return_value={'default_bgp_status':"up"}):               
               self.assertFalse(traffic_shift.bgp_session_bringup_required())
            with patch.object(config_db(), 'get_entry', 
                  return_value={'default_bgp_status':"down"}):               
               self.assertTrue(traffic_shift.bgp_session_bringup_required())
            with patch.object(config_db(), 'get_table', 
                  return_value={'10.0.0.0': {'admin_status': 'up','asn': '65200'}}):
               self.assertFalse(traffic_shift.bgp_session_bringup_required())
            with patch.object(config_db(), 'get_table', 
                  return_value={'10.0.0.0': {'asn': '65200'}}):
               self.assertTrue(traffic_shift.bgp_session_bringup_required())
                         
if __name__ == '__main__':
   unittest.main( verbosity=2 )
