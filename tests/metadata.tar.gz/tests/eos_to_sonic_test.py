#!/usr/bin/env python
# Copyright (c) 2021 Arista Networks, Inc.  All rights reserved.
# Arista Networks, Inc. Confidential and Proprietary.

from __future__ import absolute_import, division, print_function

import logging
import os
import sys
import unittest
from io import BytesIO
from mock import patch
from mock import Mock

sys.path.insert( 0, '..' )
sys.modules[ 'PyClient' ] = Mock()
sys.modules[ 'Tac' ] = Mock()
import eos_to_sonic

class CapturableHandler( logging.StreamHandler ):
    @property
    def stream( self ):
        return sys.stdout
    @stream.setter
    def stream( self, value ):
        pass
logger = logging.getLogger( 'eos_to_sonic' )
logger.addHandler( CapturableHandler() )

class TestBase( unittest.TestCase ):
   def checkCmd( self, success, testargs, sysExit=True ):
      with patch( 'sys.stdout', new=BytesIO() ) as stdOutput:
         testargs = [ './eos_to_sonic.py' ] + testargs
         with patch.object( sys, 'argv', testargs ):
            with patch.object( os, 'getuid', return_value=0 ):
               with patch( 'eos_to_sonic.Utils.getFsInfo', return_value={
                           'type': 'ext4', 'available': '2048000' } ):
                  if sysExit:
                     with self.assertRaises( SystemExit ) as cm:
                        eos_to_sonic.main()
                     if success:
                        self.assertTrue( cm.exception.code == 0 )
                     else:
                        self.assertTrue( cm.exception.code != 0 )
                  else:
                     eos_to_sonic.main()

      return stdOutput.getvalue().strip()

   def checkPass( self, testargs ):
      return self.checkCmd( True, testargs, sysExit=True )

   def checkFail( self, testargs ):
      return self.checkCmd( False, testargs, sysExit=True )

   def checkReturn( self, testargs ):
      return self.checkCmd( True, testargs, sysExit=False )

class ParamsTest( TestBase ):
   def testHelp( self ):
      output = self.checkPass( [ '-h' ] )
      self.assertIn( 'Tool to install and boot SONiC from EOS.', output )

   def testDestNotExist( self ):
      with patch.object( os.path, 'ismount', return_value=False ):
         output = self.checkFail( [] )
      self.assertIn( 'mount point from argument does not exist', output )

   def testErrorToFindInstalled( self ):
      with patch.object( os.path, 'ismount', return_value=True ):
         with patch( 'eos_to_sonic.Utils.run', return_value='' ):
            output = self.checkFail( [ '-k' ] )
      self.assertIn( 'Error to find SONiC image installed', output )

   def testInstallWithSwiNotExisting( self ):
      with patch.object( os.path, 'ismount', return_value=True ):
         with patch( 'eos_to_sonic.Utils.runShowCmd', return_value='' ):
            output = self.checkFail( [ '-i' ] )
            self.assertIn( 'SWI for SONiC not existing', output )
            output = self.checkFail( [ '-i', '-s /tmp/none-exist' ] )
            self.assertIn( 'SWI for SONiC not existing:  /tmp/none-exist', output )

   def testDryRun( self ):
      with patch.object( os.path, 'ismount', return_value=True ):
         with patch( 'eos_to_sonic.Utils.runShowCmd', return_value='' ):
            with patch.object( os.path, 'isfile', return_value=True ):
               with patch( 'eos_to_sonic.Utils.getInstalledSonic',
                           return_value='/tmp/none-exist' ):
                  with patch( 'eos_to_sonic.App' ):
                     with patch( 'eos_to_sonic.Utils.run' ):
                        output = self.checkReturn( [ '--dryRun' ] )
                        self.assertIn( 'WARNING: Mount point for dry run is '
                                       'unmounted', output )

   def testVersionCheck( self ):
      with patch.object( os.path, 'ismount', return_value=True ):
         with patch( 'eos_to_sonic.Utils.runShowCmd', return_value='' ):
            with patch.object( os.path, 'isfile', return_value=True ):
               with patch( 'eos_to_sonic.App.install', return_value='' ):
                  self.checkFail( [ '-i', '-s /tmp/none-exist', '--eosVer=4.20.3F',
                                    '--sonicVer=42.0.0', '--platform=foo' ] )
                  self.checkFail( [ '-i', '-s /tmp/none-exist', '--eosVer=4.20.4F',
                                    '--sonicVer=42.0.0', '--platform=Gardena' ] )
                  self.checkFail( [ '-i', '-s /tmp/none-exist', '--eosVer=4.20.3F',
                                    '--sonicVer=ars', '--platform=Gardena' ] )
                  self.checkReturn( [ '-i', '-s /tmp/none-exist', '--eosVer=4.20.3F',
                                    '--sonicVer=42.0.0', '--platform=Gardena' ] )

   def testDefaultHwSku( self ):
      with patch.object( os.path, 'ismount', return_value=True ):
         with patch( 'eos_to_sonic.Utils.run', return_value='' ):
            output = self.checkFail( [ '--arpHelperIPs=127.0.0.1' ] )
            self.assertNotIn( 'In ARP helper mode, hwSku must be provided by ' \
                              'argument -w', output )
            self.assertIn( 'SONiC mount point is', output )
            output = self.checkFail( [] )
            self.assertIn( 'SONiC mount point is', output )

   def testNtpCheck( self ):
      with patch.object( os.path, 'ismount', return_value=True ):
         with patch( 'eos_to_sonic.Utils.runShowCmd',
                     return_value='unsynchronised' ):
            output = self.checkFail( [] )
            self.assertIn( 'Clock is not synced with NTP', output )
         with patch( 'eos_to_sonic.Utils.runShowCmd',
                     return_value='Ntp is disabled' ):
            output = self.checkFail( [] )
            self.assertIn( 'Clock is not synced with NTP', output )

if __name__ == '__main__':
   unittest.main( verbosity=2 )
