import sys
import pytest
from unittest.mock import mock_open, call, patch, MagicMock

sys.modules['sonic_platform'] = MagicMock()
sys.modules['sonic_py_common'] = MagicMock()
from postupgrade_actions import verify_fix_timeout_gendump, fix_timeout_gendump

GENDUMP_PATH = '/usr/local/bin/generate_dump'
BACKUP_CMD = 'sudo cp {} {}.bak'.format(GENDUMP_PATH, GENDUMP_PATH)
RESTORE_CMD = 'sudo cp {}.bak {}'.format(GENDUMP_PATH, GENDUMP_PATH)

GENDUMP_PATH_201911 = '/usr/bin/generate_dump'
BACKUP_CMD_201911 = 'sudo cp {} {}.bak'.format(GENDUMP_PATH_201911, GENDUMP_PATH_201911)

MOCK_FILE_CONTENT = """        t)
            if ! [[ ${OPTARG} =~ ^[0-9]+$ ]]; then
                echo "Invalid timeout value: ${OPTARG}, Please enter a numeric value."
                exit 1
            fi"""

MOCK_FILE_INCORRECT_CONTENT = """        t)
            TIMEOUT_MIN="${OPTARG}" """

EXPECTED_CODE = """        t)
            if ! [[ ${OPTARG} =~ ^[0-9]+$ ]]; then
                echo "Invalid timeout value: ${OPTARG}, Please enter a numeric value."
                exit 1
            fi"""

REPLACE_CMD = r"""sudo sed -i 's/^        t)/        t)\
            if ! [[ ${{OPTARG}} =~ ^[0-9]+$ ]]; then\
                echo "Invalid timeout value: ${{OPTARG}}, Please enter a numeric value."\
                exit {}\
            fi/' {}"""

GENDUMP_VERIFY_CMD = "sudo generate_dump -t '5 abc'"


class TestVerifyFixTimeoutGendump(object):
    def setup_method(self):
        print('SETUP')

    @patch('postupgrade_actions.log_error')
    @patch('builtins.open', new_callable=mock_open, read_data=MOCK_FILE_CONTENT)
    def test_verify_fix_timeout_gendump_success(self, mock_file, mock_log_error):
        result = verify_fix_timeout_gendump(GENDUMP_PATH, EXPECTED_CODE)
        assert result is True
        mock_log_error.assert_not_called()

    @patch('postupgrade_actions.log_error')
    @patch('builtins.open', new_callable=mock_open, read_data=MOCK_FILE_CONTENT)
    def test_verify_fix_timeout_gendump_unexpected_code(self, mock_file, mock_log_error):
        result = verify_fix_timeout_gendump(GENDUMP_PATH, MOCK_FILE_INCORRECT_CONTENT)
        assert result is False
        mock_log_error.assert_not_called()

    @patch('postupgrade_actions.log_error')
    @patch('builtins.open', side_effect=FileNotFoundError)
    def test_verify_fix_timeout_gendump_file_not_found(self, mock_file, mock_log_error):
        result = verify_fix_timeout_gendump(GENDUMP_PATH, 'any content')
        assert result is False
        mock_log_error.assert_called_once_with("verify_fix_timeout_gendump: Error accessing file {}: ".format(GENDUMP_PATH))

    def teardown_method(self):
        print('TEAR DOWN')


class TestFixTimeoutGendump(object):
    def setup_method(self):
        print('SETUP')

    @patch('postupgrade_actions.log_info')
    @patch('postupgrade_actions.exec_cmd')
    @patch('postupgrade_actions.verify_fix_timeout_gendump', MagicMock(return_value=True))
    @patch('postupgrade_actions.get_sonic_version_info', MagicMock(return_value={'build_version': '20201231.68'}))
    def test_fix_timeout_gendump_skip_patch(self, mock_exec_cmd, mock_log_info):
        fix_timeout_gendump()

        print(mock_log_info.call_args_list)
        assert mock_log_info.call_args_list == [
            call('fix_timeout_gendump: already fixed')
        ]

        mock_exec_cmd.assert_not_called()

    @patch('postupgrade_actions.log_error')
    @patch('postupgrade_actions.log_info')
    @patch('postupgrade_actions.exec_cmd')
    @patch('postupgrade_actions.verify_fix_timeout_gendump', MagicMock(side_effect=[False, True]))
    @patch('postupgrade_actions.get_sonic_version_info', MagicMock(return_value={'build_version': '20201231.68'}))
    def test_fix_timeout_gendump_success_patch(self, mock_exec_cmd, mock_log_info, mock_log_error):
        mock_exec_cmd.side_effect = [(0, 'success'), (0, 'success'), (1, 'Invalid timeout value: 5 abc, Please enter a numeric value.')]
        fix_timeout_gendump()

        print(mock_exec_cmd.call_args_list)
        print(mock_log_info.call_args_list)
        print(mock_log_error.call_args_list)
        assert mock_exec_cmd.call_args_list == [
            call(BACKUP_CMD),
            call(cmd=REPLACE_CMD.format('1', GENDUMP_PATH), verbose=False),
            call(GENDUMP_VERIFY_CMD)
        ]

        assert mock_log_info.call_args_list == [
            call('fix_timeout_gendump: backup generate_dump'),
            call('fix_timeout_gendump: generate_dump fixed successfully')
        ]

    @patch('postupgrade_actions.log_error')
    @patch('postupgrade_actions.log_info')
    @patch('postupgrade_actions.exec_cmd')
    @patch('postupgrade_actions.verify_fix_timeout_gendump', MagicMock(return_value=False))
    @patch('postupgrade_actions.get_sonic_version_info', MagicMock(return_value={'build_version': '20191130.68'}))
    def test_fix_timeout_gendump_failed_replace(self, mock_exec_cmd, mock_log_info, mock_log_error):
        mock_exec_cmd.side_effect = [(0, 'success'), (1, 'failed')]

        fix_timeout_gendump()
        print(mock_exec_cmd.call_args_list)
        print(mock_log_info.call_args_list)
        print(mock_log_error.call_args_list)

        assert mock_exec_cmd.call_args_list == [
            call(BACKUP_CMD_201911),
            call(cmd=REPLACE_CMD.format('1', GENDUMP_PATH_201911), verbose=False),
        ]

        assert mock_log_info.call_args_list == [
            call('fix_timeout_gendump: backup generate_dump'),
        ]

        assert mock_log_error.call_args_list == [
            call('fix_timeout_gendump: replace command failed with rc=1, out=failed'),
        ]

    @patch('postupgrade_actions.log_error')
    @patch('postupgrade_actions.log_info')
    @patch('postupgrade_actions.exec_cmd')
    @patch('postupgrade_actions.verify_fix_timeout_gendump', MagicMock(return_value=False))
    @patch('postupgrade_actions.get_sonic_version_info', MagicMock(return_value={'build_version': '20230531.68'}))
    def test_fix_timeout_gendump_patch_failed(self, mock_exec_cmd, mock_log_info, mock_log_error):
        mock_exec_cmd.side_effect = [(0, 'success'), (0, 'success'), (1, 'failed')]

        fix_timeout_gendump()
        print(mock_exec_cmd.call_args_list)
        print(mock_log_info.call_args_list)
        print(mock_log_error.call_args_list)

        assert mock_exec_cmd.call_args_list == [
            call(BACKUP_CMD),
            call(cmd=REPLACE_CMD.format('$EXT_GENERAL', GENDUMP_PATH), verbose=False),
            call(RESTORE_CMD)
        ]

        assert mock_log_info.call_args_list == [
            call('fix_timeout_gendump: backup generate_dump'),
        ]

        assert mock_log_error.call_args_list == [
            call('fix_timeout_gendump: patch failed')
        ]

    @patch('postupgrade_actions.log_error')
    @patch('postupgrade_actions.log_info')
    @patch('postupgrade_actions.exec_cmd')
    @patch('postupgrade_actions.verify_fix_timeout_gendump', MagicMock(side_effect=[False, True]))
    @patch('postupgrade_actions.get_sonic_version_info', MagicMock(return_value={'build_version': '20230531.68'}))
    def test_fix_timeout_gendump_cmd_verify_failed(self, mock_exec_cmd, mock_log_info, mock_log_error):
        mock_exec_cmd.side_effect = [(0, 'success'), (0, 'success'), (0, 'success'), (1, 'failed')]

        fix_timeout_gendump()
        print(mock_exec_cmd.call_args_list)
        print(mock_log_info.call_args_list)
        print(mock_log_error.call_args_list)

        assert mock_exec_cmd.call_args_list == [
            call(BACKUP_CMD),
            call(cmd=REPLACE_CMD.format('$EXT_GENERAL', GENDUMP_PATH), verbose=False),
            call(GENDUMP_VERIFY_CMD),
            call(RESTORE_CMD)
        ]

        assert mock_log_info.call_args_list == [
            call('fix_timeout_gendump: backup generate_dump'),
        ]

        assert mock_log_error.call_args_list == [
            call('fix_timeout_gendump: verify generate_dump command failed')
        ]

    def teardown_method(self):
        print('TEAR DOWN')
