import sys
import pytest
from unittest.mock import call, patch, MagicMock

sys.modules['sonic_platform'] = MagicMock()
sys.modules['sonic_py_common'] = MagicMock()

POSTUPGRADE_ACTIONS_DATA_DIR = '/postupgrade_actions_data_dir'

class TestACMS(object):
    def setup_method(self):
        print('SETUP')

    def teardown_method(self):
        print('TEAR DOWN')

    @patch('postupgrade_actions.get_sonic_version_info')
    @patch('postupgrade_actions.exec_cmd')
    def test_fix_acms_dns_ipv6_01(self, mock_cmd, mock_version_info):
        '''
        Test fix_acms_dns_ipv6
        The build version is 20230531.20, postupgrade_actions should apply the fix
        '''
        from postupgrade_actions import fix_acms_dns_ipv6
        mock_version_info.return_value = {'build_version': '20230531.20'}
        fix_acms_dns_ipv6()
        assert len(mock_cmd.call_args_list) == 6
        assert mock_cmd.call_args_list[-1] == call("sudo systemctl restart acms")

    @patch('postupgrade_actions.get_sonic_version_info')
    @patch('postupgrade_actions.exec_cmd')
    def test_fix_acms_dns_ipv6_02(self, mock_cmd, mock_version_info):
        '''
        Test fix_acms_dns_ipv6
        The build version is 20230531.26, postupgrade_actions should not apply the fix
        '''
        from postupgrade_actions import fix_acms_dns_ipv6
        mock_version_info.return_value = {'build_version': '20230531.26'}
        fix_acms_dns_ipv6()
        assert len(mock_cmd.call_args_list) == 0

    @patch('postupgrade_actions.get_sonic_version_info')
    @patch('postupgrade_actions.exec_cmd')
    @patch('postupgrade_actions.os.path.exists')
    def test_clean_acms_certs_01(self, mock_exist, mock_cmd, mock_version_info):
        '''
        Test clean_acms_certs
        The build version is 20230531.100
        ACMS is not running
        Chained certificate exists
        '''
        from postupgrade_actions import clean_acms_certs
        mock_version_info.return_value = {'build_version': '20230531.100'}
        mock_exist.return_value = True
        mock_cmd.return_value = (0, "restapi")
        clean_acms_certs()
        assert mock_cmd.call_args_list == [
            call("docker ps --filter status=running --format \{\{.Names\}\}")
        ]

    @patch('postupgrade_actions.get_sonic_version_info')
    @patch('postupgrade_actions.exec_cmd')
    @patch('postupgrade_actions.os.path.exists')
    def test_clean_acms_certs_02(self, mock_exist, mock_cmd, mock_version_info):
        '''
        Test clean_acms_certs
        The build version is 20230531.100
        ACMS is running
        Chained certificate does not exist
        '''
        from postupgrade_actions import clean_acms_certs
        mock_version_info.return_value = {'build_version': '20230531.100'}
        mock_exist.return_value = False
        mock_cmd.return_value = (0, "acms")
        clean_acms_certs()
        assert mock_cmd.call_args_list == [
            call("docker ps --filter status=running --format \{\{.Names\}\}")
        ]

    @patch('postupgrade_actions.get_sonic_version_info')
    @patch('postupgrade_actions.exec_cmd')
    @patch('postupgrade_actions.os.path.exists')
    def test_clean_acms_certs_03(self, mock_exist, mock_cmd, mock_version_info):
        '''
        Test clean_acms_certs
        The build version is 20230531.100
        ACMS is running and restapi is running
        Chained certificate exists
        '''
        from postupgrade_actions import clean_acms_certs
        mock_version_info.return_value = {'build_version': '20230531.100'}
        mock_exist.return_value = True
        mock_cmd.return_value = (0, "acms restapi")
        clean_acms_certs()
        assert mock_cmd.call_args_list == [
            call("docker ps --filter status=running --format \{\{.Names\}\}"),
            call("sudo rm /etc/sonic/credentials/restapiserver*"),
            call("sudo docker exec acms supervisorctl restart cert_converter"),
            call("sudo systemctl reset-failed restapi"),
            call("sudo systemctl restart restapi")
        ]
