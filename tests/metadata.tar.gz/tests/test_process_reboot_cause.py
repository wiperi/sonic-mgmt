import os
import sys
import pytest
import json
import unittest 
from unittest.mock import call, patch, MagicMock

# Add mocked_libs path so that the file under test can load mocked modules from there
tests_path = os.path.dirname(os.path.abspath(__file__))
mocked_libs_path = os.path.join(tests_path, "mocked_libs")
sys.path.insert(0, mocked_libs_path)

from mocked_libs import sonic_py_common
sys.modules['swsscommon'] = MagicMock()

import process_reboot_cause as orig_process_reboot_cause
import ex_handling_process_reboot_cause as patched_process_reboot_cause

MOCK_REBOOT_CAUSE_HISTORY_DIR = "mock-reboot-cause/history/"

class TestProcRebootCause(unittest.TestCase):

    @patch('process_reboot_cause.REBOOT_CAUSE_HISTORY_DIR', MOCK_REBOOT_CAUSE_HISTORY_DIR)
    def test_orig_process_reboot_cause(self):

        with self.assertRaises(json.decoder.JSONDecodeError) as jdex:
            orig_process_reboot_cause.read_reboot_cause_files_and_save_state_db()

        exception = jdex.exception
        assert isinstance(jdex.exception, json.decoder.JSONDecodeError)
        assert sys.modules['sonic_py_common.logger'].Logger.info_call_count == 0


    @patch('ex_handling_process_reboot_cause.REBOOT_CAUSE_HISTORY_DIR', MOCK_REBOOT_CAUSE_HISTORY_DIR)
    def test_patched_process_reboot_cause(self):
        patched_process_reboot_cause.read_reboot_cause_files_and_save_state_db()

        # 1 for badfile.json, 1 for emptyfile.json
        assert sys.modules['sonic_py_common.logger'].Logger.info_call_count == 2




