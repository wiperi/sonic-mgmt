import sys
import pytest
from unittest.mock import call, patch, MagicMock

sys.modules['sonic_platform'] = MagicMock()
sys.modules['sonic_py_common'] = MagicMock()

from postupgrade_actions import update_telemetry_deb

class TestUpdateTelemetry(object):
    def setup_method(self):
        print('SETUP')

    def teardown_method(self):
        print('TEAR DOWN')

    @patch('postupgrade_actions.get_switch_type')
    @patch('postupgrade_actions.get_cloudtype_config')
    @patch('postupgrade_actions.get_sonic_version_info')
    @patch('postupgrade_actions.exec_cmd')
    def test_update_telemetry_version_correct(self, mock_cmd, mock_version_info, mock_get_cloudtype_config, mock_get_switch_type):
        '''
        Test update_telemetry_deb
        The build version is 20230531.20, postupgrade_actions should apply the fix
        '''
        mock_version_info.return_value = {'build_version': '20230531.20'}
        mock_get_cloudtype_config.return_value = "public"
        mock_get_switch_type.return_value = "ToRRouter"

        mock_cmd.side_effect = [
            (0, 'executed: mkdir -p /tmp/telemetry_tmp'),
            (0, 'up'),
            (0, '200'),
            (0, '200'),
            (0, 'f567b6e2019m3l3c2ed971a11f9698f0  /tmp/telemetry_tmp/telemetry_202305.deb.gz'),
            (0, 'f567b6e2019m3l3c2ed971a11f9698f0'),
            (0, 'docker-telemetry'),
            (0, 'executed: gzip -d /tmp/telemetry_tmp/telemetry_202305.deb.gz'),
            (0, 'executed: dpkg -x /tmp/telemetry_tmp/telemetry_202305.deb /tmp/telemetry_tmp'),
            (0, 'executed: docker cp /tmp/telemetry_tmp/usr/sbin/telemetry telemetry:/usr/sbin/'),
            (0, 'executed: sudo systemctl reset-failed telemetry'),
            (0, 'executed: sudo systemctl restart telemetry'),
            (0, 'executed: rm -rf /tmp/telemetry_tmp')
        ]

        update_telemetry_deb()
        assert len(mock_cmd.call_args_list) == 13

        assert mock_cmd.call_args_list == [
            call("mkdir -p /tmp/telemetry_tmp"),
            call("cat /sys/class/net/eth0/operstate | tr -d '\n\r'"),
            call("curl --interface eth0 -s --connect-timeout 10 -w \"%{http_code}\" http://10.20.17.0/networkfirmware/ACS/telemetry_202305.deb.gz -o /tmp/telemetry_tmp/telemetry_202305.deb.gz"),
            call("curl --interface eth0 -s --connect-timeout 10 -w \"%{http_code}\" http://10.20.17.0/networkfirmware/ACS/telemetry_202305.deb.gz.md5 -o /tmp/telemetry_tmp/telemetry_202305.deb.gz.md5"),
            call("md5sum /tmp/telemetry_tmp/telemetry_202305.deb.gz"),
            call("cat /tmp/telemetry_tmp/telemetry_202305.deb.gz.md5 | tr -d '\n\r'"),
            call("docker images --format \{\{.Repository\}\}"),
            call("gzip -d /tmp/telemetry_tmp/telemetry_202305.deb.gz"),
            call("dpkg -x /tmp/telemetry_tmp/telemetry_202305.deb /tmp/telemetry_tmp"),
            call("docker cp /tmp/telemetry_tmp/usr/sbin/telemetry telemetry:/usr/sbin/"),
            call("sudo systemctl reset-failed telemetry"),
            call("sudo systemctl restart telemetry"),
            call("rm -rf /tmp/telemetry_tmp")
        ]

    @patch('postupgrade_actions.get_switch_type')
    @patch('postupgrade_actions.get_cloudtype_config')
    @patch('postupgrade_actions.get_sonic_version_info')
    @patch('postupgrade_actions.exec_cmd')
    def test_update_telemetry_version_correct_fairfax(self, mock_cmd, mock_version_info, mock_get_cloudtype_config, mock_get_switch_type):
        '''
        Test update_telemetry_deb
        The cloudtype is fairfax and version is correct, postupgrade_actions should apply the fix
        '''
        mock_version_info.return_value = {'build_version': '20230531.20'}
        mock_get_cloudtype_config.return_value = "fairfax"
        mock_get_switch_type.return_value = "ToRRouter"

        mock_cmd.side_effect = [
            (0, 'executed: mkdir -p /tmp/telemetry_tmp'),
            (0, 'up'),
            (0, '200'),
            (0, '200'),
            (0, 'f567b6e2019m3l3c2ed971a11f9698f0  /tmp/telemetry_tmp/telemetry_202305.deb.gz'),
            (0, 'f567b6e2019m3l3c2ed971a11f9698f0'),
            (0, 'docker-telemetry'),
            (0, 'executed: gzip -d /tmp/telemetry_tmp/telemetry_202305.deb.gz'),
            (0, 'executed: dpkg -x /tmp/telemetry_tmp/telemetry_202305.deb /tmp/telemetry_tmp'),
            (0, 'executed: docker cp /tmp/telemetry_tmp/usr/sbin/telemetry telemetry:/usr/sbin/'),
            (0, 'executed: sudo systemctl reset-failed telemetry'),
            (0, 'executed: sudo systemctl restart telemetry'),
            (0, 'executed: rm -rf /tmp/telemetry_tmp')
        ]

        update_telemetry_deb()
        assert len(mock_cmd.call_args_list) == 13

        assert mock_cmd.call_args_list == [
            call("mkdir -p /tmp/telemetry_tmp"),
            call("cat /sys/class/net/eth0/operstate | tr -d '\n\r'"),
            call("curl --interface eth0 -s --connect-timeout 10 -w \"%{http_code}\" http://10.76.128.17/networkfirmware/ACS/telemetry_202305.deb.gz -o /tmp/telemetry_tmp/telemetry_202305.deb.gz"),
            call("curl --interface eth0 -s --connect-timeout 10 -w \"%{http_code}\" http://10.76.128.17/networkfirmware/ACS/telemetry_202305.deb.gz.md5 -o /tmp/telemetry_tmp/telemetry_202305.deb.gz.md5"),
            call("md5sum /tmp/telemetry_tmp/telemetry_202305.deb.gz"),
            call("cat /tmp/telemetry_tmp/telemetry_202305.deb.gz.md5 | tr -d '\n\r'"),
            call("docker images --format \{\{.Repository\}\}"),
            call("gzip -d /tmp/telemetry_tmp/telemetry_202305.deb.gz"),
            call("dpkg -x /tmp/telemetry_tmp/telemetry_202305.deb /tmp/telemetry_tmp"),
            call("docker cp /tmp/telemetry_tmp/usr/sbin/telemetry telemetry:/usr/sbin/"),
            call("sudo systemctl reset-failed telemetry"),
            call("sudo systemctl restart telemetry"),
            call("rm -rf /tmp/telemetry_tmp")
        ]

    @patch('postupgrade_actions.get_switch_type')
    @patch('postupgrade_actions.get_cloudtype_config')
    @patch('postupgrade_actions.get_sonic_version_info')
    @patch('postupgrade_actions.exec_cmd')
    def test_update_telemetry_version_incorrect(self, mock_cmd, mock_version_info, mock_get_cloudtype_config, mock_get_switch_type):
        '''
        Test update_telemetry_deb
        The build version is 20230531.26, postupgrade_actions should not apply the fix
        '''
        mock_version_info.return_value = {'build_version': '20230531.26'}
        mock_get_cloudtype_config.return_value = "public"
        mock_get_switch_type.return_value = "ToRRouter"
        update_telemetry_deb()
        assert len(mock_cmd.call_args_list) == 0

    @patch('postupgrade_actions.get_switch_type')
    @patch('postupgrade_actions.get_cloudtype_config')
    @patch('postupgrade_actions.get_sonic_version_info')
    @patch('postupgrade_actions.exec_cmd')
    def test_update_telemetry_version_incorrect_02(self, mock_cmd, mock_version_info, mock_get_cloudtype_config, mock_get_switch_type):
        '''
        Test update_telemetry_deb
        The build version is 20220531.21, postupgrade_actions should not apply the fix
        '''
        mock_version_info.return_value = {'build_version': '20220531.21'}
        mock_get_cloudtype_config.return_value = "public"
        mock_get_switch_type.return_value = "ToRRouter"
        update_telemetry_deb()
        assert len(mock_cmd.call_args_list) == 0

    @patch('postupgrade_actions.get_switch_type')
    @patch('postupgrade_actions.get_cloudtype_config')
    @patch('postupgrade_actions.get_sonic_version_info')
    @patch('postupgrade_actions.exec_cmd')
    def test_update_telemetry_mgfx(self, mock_cmd, mock_version_info, mock_get_cloudtype_config, mock_get_switch_type):
        '''
        Test update_telemetry_deb
        Switch type is mgfx, postupgrade_actions should not apply the fix
        '''
        mock_version_info.return_value = {'build_version': '20230531.20'}
        mock_get_cloudtype_config.return_value = "public"
        mock_get_switch_type.return_value = 'MgmtToRRouter'
        update_telemetry_deb()
        assert len(mock_cmd.call_args_list) == 0

    @patch('postupgrade_actions.get_switch_type')
    @patch('postupgrade_actions.get_cloudtype_config')
    @patch('postupgrade_actions.get_sonic_version_info')
    @patch('postupgrade_actions.exec_cmd')
    def test_update_telemetry_cloudtype_incorrect(self, mock_cmd, mock_version_info, mock_get_cloudtype_config, mock_get_switch_type):
        '''
        Test update_telemetry_deb
        The cloudtype is mooncake, postupgrade_actions should not apply the fix
        '''
        mock_version_info.return_value = {'build_version': '20230531.20'}
        mock_get_cloudtype_config.return_value = "mooncake"
        mock_get_switch_type.return_value = "ToRRouter"
        update_telemetry_deb()
        assert len(mock_cmd.call_args_list) == 0

    @patch('postupgrade_actions.get_switch_type')
    @patch('postupgrade_actions.get_cloudtype_config')
    @patch('postupgrade_actions.get_sonic_version_info')
    @patch('postupgrade_actions.exec_cmd')
    def test_update_telemetry_slim(self, mock_cmd, mock_version_info, mock_get_cloudtype_config, mock_get_switch_type):
        '''
        Test update_telemetry_deb
        The build version is 20230531.20, postupgrade_actions should apply the fix
        '''
        mock_version_info.return_value = {'build_version': '20230531.20'}
        mock_get_cloudtype_config.return_value = "public"
        mock_get_switch_type.return_value = "ToRRouter"

        mock_cmd.side_effect = [
            (0, 'executed: mkdir -p /tmp/telemetry_tmp'),
            (0, 'up'),
            (0, '200'),
            (0, '200'),
            (0, 'f567b6e2019m3l3c2ed971a11f9698f0  /tmp/telemetry_tmp/telemetry_202305.deb.gz'),
            (0, 'f567b6e2019m3l3c2ed971a11f9698f0'),
            (0, 'docker-gnmi'),
            (0, 'executed: gzip -d /tmp/telemetry_tmp/telemetry_202305.deb.gz'),
            (0, 'executed: dpkg -x /tmp/telemetry_tmp/telemetry_202305.deb /tmp/telemetry_tmp'),
            (0, 'executed: docker cp /tmp/telemetry_tmp/usr/sbin/telemetry gnmi:/usr/sbin/'),
            (0, 'executed: sudo systemctl reset-failed gnmi'),
            (0, 'executed: sudo systemctl restart gnmi'),
            (0, 'executed: rm -rf /tmp/telemetry_tmp')
        ]

        update_telemetry_deb()
        assert len(mock_cmd.call_args_list) == 13

        assert mock_cmd.call_args_list == [
            call("mkdir -p /tmp/telemetry_tmp"),
            call("cat /sys/class/net/eth0/operstate | tr -d '\n\r'"),
            call("curl --interface eth0 -s --connect-timeout 10 -w \"%{http_code}\" http://10.20.17.0/networkfirmware/ACS/telemetry_202305.deb.gz -o /tmp/telemetry_tmp/telemetry_202305.deb.gz"),
            call("curl --interface eth0 -s --connect-timeout 10 -w \"%{http_code}\" http://10.20.17.0/networkfirmware/ACS/telemetry_202305.deb.gz.md5 -o /tmp/telemetry_tmp/telemetry_202305.deb.gz.md5"),
            call("md5sum /tmp/telemetry_tmp/telemetry_202305.deb.gz"),
            call("cat /tmp/telemetry_tmp/telemetry_202305.deb.gz.md5 | tr -d '\n\r'"),
            call("docker images --format \{\{.Repository\}\}"),
            call("gzip -d /tmp/telemetry_tmp/telemetry_202305.deb.gz"),
            call("dpkg -x /tmp/telemetry_tmp/telemetry_202305.deb /tmp/telemetry_tmp"),
            call("docker cp /tmp/telemetry_tmp/usr/sbin/telemetry gnmi:/usr/sbin/"),
            call("sudo systemctl reset-failed gnmi"),
            call("sudo systemctl restart gnmi"),
            call("rm -rf /tmp/telemetry_tmp")
        ]

    @patch('postupgrade_actions.get_switch_type')
    @patch('postupgrade_actions.get_cloudtype_config')
    @patch('postupgrade_actions.get_sonic_version_info')
    @patch('postupgrade_actions.exec_cmd')
    def test_update_telemetry_ipv6(self, mock_cmd, mock_version_info, mock_get_cloudtype_config, mock_get_switch_type):
        '''
        Test update_telemetry_deb
        The build version is 20230531.20, postupgrade_actions should apply the fix
        '''
        mock_version_info.return_value = {'build_version': '20230531.20'}
        mock_get_cloudtype_config.return_value = "public"
        mock_get_switch_type.return_value = "ToRRouter"

        mock_cmd.side_effect = [
            (0, 'executed: mkdir -p /tmp/telemetry_tmp'),
            (0, 'up'),
            (0, '000'),
            (0, '200'),
            (0, '000'),
            (0, '200'),
            (0, 'f567b6e2019m3l3c2ed971a11f9698f0  /tmp/telemetry_tmp/telemetry_202305.deb.gz'),
            (0, 'f567b6e2019m3l3c2ed971a11f9698f0'),
            (0, 'docker-telemetry'),
            (0, 'executed: gzip -d /tmp/telemetry_tmp/telemetry_202305.deb.gz'),
            (0, 'executed: dpkg -x /tmp/telemetry_tmp/telemetry_202305.deb /tmp/telemetry_tmp'),
            (0, 'executed: docker cp /tmp/telemetry_tmp/usr/sbin/telemetry telemetry:/usr/sbin/'),
            (0, 'executed: sudo systemctl reset-failed telemetry'),
            (0, 'executed: sudo systemctl restart telemetry'),
            (0, 'executed: rm -rf /tmp/telemetry_tmp')
        ]

        update_telemetry_deb()
        assert len(mock_cmd.call_args_list) == 15

        assert mock_cmd.call_args_list == [
            call("mkdir -p /tmp/telemetry_tmp"),
            call("cat /sys/class/net/eth0/operstate | tr -d '\n\r'"),
            call("curl --interface eth0 -s --connect-timeout 10 -w \"%{http_code}\" http://10.20.17.0/networkfirmware/ACS/telemetry_202305.deb.gz -o /tmp/telemetry_tmp/telemetry_202305.deb.gz"),
            call("curl --interface eth0 -s --connect-timeout 10 -w \"%{http_code}\" http://[2001:506:28:100c::1]/networkfirmware/ACS/telemetry_202305.deb.gz -o /tmp/telemetry_tmp/telemetry_202305.deb.gz"),
            call("curl --interface eth0 -s --connect-timeout 10 -w \"%{http_code}\" http://10.20.17.0/networkfirmware/ACS/telemetry_202305.deb.gz.md5 -o /tmp/telemetry_tmp/telemetry_202305.deb.gz.md5"),
            call("curl --interface eth0 -s --connect-timeout 10 -w \"%{http_code}\" http://[2001:506:28:100c::1]/networkfirmware/ACS/telemetry_202305.deb.gz.md5 -o /tmp/telemetry_tmp/telemetry_202305.deb.gz.md5"),
            call("md5sum /tmp/telemetry_tmp/telemetry_202305.deb.gz"),
            call("cat /tmp/telemetry_tmp/telemetry_202305.deb.gz.md5 | tr -d '\n\r'"),
            call("docker images --format \{\{.Repository\}\}"),
            call("gzip -d /tmp/telemetry_tmp/telemetry_202305.deb.gz"),
            call("dpkg -x /tmp/telemetry_tmp/telemetry_202305.deb /tmp/telemetry_tmp"),
            call("docker cp /tmp/telemetry_tmp/usr/sbin/telemetry telemetry:/usr/sbin/"),
            call("sudo systemctl reset-failed telemetry"),
            call("sudo systemctl restart telemetry"),
            call("rm -rf /tmp/telemetry_tmp")
        ]

    @patch('postupgrade_actions.get_switch_type')
    @patch('postupgrade_actions.get_cloudtype_config')
    @patch('postupgrade_actions.get_sonic_version_info')
    @patch('postupgrade_actions.exec_cmd')
    def test_update_telemetry_non_mgmt_port(self, mock_cmd, mock_version_info, mock_get_cloudtype_config, mock_get_switch_type):
        '''
        Test update_telemetry_deb
        The build version is 20230531.20, postupgrade_actions should apply the fix
        '''
        mock_version_info.return_value = {'build_version': '20230531.20'}
        mock_get_cloudtype_config.return_value = "public"
        mock_get_switch_type.return_value = "ToRRouter"

        mock_cmd.side_effect = [
            (0, 'executed: mkdir -p /tmp/telemetry_tmp'),
            (0, 'down'),
            (0, '200'),
            (0, '200'),
            (0, 'f567b6e2019m3l3c2ed971a11f9698f0 /tmp/telemetry_tmp/telemetry_202305.deb.gz'),
            (0, 'f567b6e2019m3l3c2ed971a11f9698f0'),
            (0, 'docker-telemetry'),
            (0, 'executed: gzip -d /tmp/telemetry_tmp/telemetry_202305.deb.gz'),
            (0, 'executed: dpkg -x /tmp/telemetry_tmp/telemetry_202305.deb /tmp/telemetry_tmp'),
            (0, 'executed: docker cp /tmp/telemetry_tmp/usr/sbin/telemetry telemetry:/usr/sbin/'),
            (0, 'executed: sudo systemctl reset-failed telemetry'),
            (0, 'executed: sudo systemctl restart telemetry'),
            (0, 'executed: rm -rf /tmp/telemetry_tmp')
        ]

        update_telemetry_deb()
        assert len(mock_cmd.call_args_list) == 13

        assert mock_cmd.call_args_list == [
            call("mkdir -p /tmp/telemetry_tmp"),
            call("cat /sys/class/net/eth0/operstate | tr -d '\n\r'"),
            call("curl -s --connect-timeout 10 -w \"%{http_code}\" http://10.20.17.0/networkfirmware/ACS/telemetry_202305.deb.gz -o /tmp/telemetry_tmp/telemetry_202305.deb.gz"),
            call("curl -s --connect-timeout 10 -w \"%{http_code}\" http://10.20.17.0/networkfirmware/ACS/telemetry_202305.deb.gz.md5 -o /tmp/telemetry_tmp/telemetry_202305.deb.gz.md5"),
            call("md5sum /tmp/telemetry_tmp/telemetry_202305.deb.gz"),
            call("cat /tmp/telemetry_tmp/telemetry_202305.deb.gz.md5 | tr -d '\n\r'"),
            call("docker images --format \{\{.Repository\}\}"),
            call("gzip -d /tmp/telemetry_tmp/telemetry_202305.deb.gz"),
            call("dpkg -x /tmp/telemetry_tmp/telemetry_202305.deb /tmp/telemetry_tmp"),
            call("docker cp /tmp/telemetry_tmp/usr/sbin/telemetry telemetry:/usr/sbin/"),
            call("sudo systemctl reset-failed telemetry"),
            call("sudo systemctl restart telemetry"),
            call("rm -rf /tmp/telemetry_tmp")
        ]

    @patch('postupgrade_actions.get_switch_type')
    @patch('postupgrade_actions.get_cloudtype_config')
    @patch('postupgrade_actions.get_sonic_version_info')
    @patch('postupgrade_actions.exec_cmd')
    def test_update_telemetry_failed_retries_01(self, mock_cmd, mock_version_info, mock_get_cloudtype_config, mock_get_switch_type):
        '''
        Test update_telemetry_deb
        The build version is 20230531.20, postupgrade_actions should apply the fix
        '''
        mock_version_info.return_value = {'build_version': '20230531.20'}
        mock_get_cloudtype_config.return_value = "public"
        mock_get_switch_type.return_value = "ToRRouter"

        mock_cmd.side_effect = [
            (0, 'executed: mkdir -p /tmp/telemetry_tmp'),
            (0, 'up'),
            (0, '500'),
            (0, '500'),
            (0, '200'),
            (0, '500'),
            (0, '200'),
            (0, 'f567b6e2019m3l3c2ed971a11f9698f0  /tmp/telemetry_tmp/telemetry_202305.deb.gz'),
            (0, 'f567b6e2019m3l3c2ed971a11f9698f0'),
            (0, 'docker-telemetry'),
            (0, 'executed: gzip -d /tmp/telemetry_tmp/telemetry_202305.deb.gz'),
            (0, 'executed: dpkg -x /tmp/telemetry_tmp/telemetry_202305.deb /tmp/telemetry_tmp'),
            (0, 'executed: docker cp /tmp/telemetry_tmp/usr/sbin/telemetry telemetry:/usr/sbin/'),
            (0, 'executed: sudo systemctl reset-failed telemetry'),
            (0, 'executed: sudo systemctl restart telemetry'),
            (0, 'executed: rm -rf /tmp/telemetry_tmp')
        ]

        update_telemetry_deb()
        assert len(mock_cmd.call_args_list) == 16

        assert mock_cmd.call_args_list == [
            call("mkdir -p /tmp/telemetry_tmp"),
            call("cat /sys/class/net/eth0/operstate | tr -d '\n\r'"),
            call("curl --interface eth0 -s --connect-timeout 10 -w \"%{http_code}\" http://10.20.17.0/networkfirmware/ACS/telemetry_202305.deb.gz -o /tmp/telemetry_tmp/telemetry_202305.deb.gz"),
            call("curl --interface eth0 -s --connect-timeout 10 -w \"%{http_code}\" http://10.20.17.0/networkfirmware/ACS/telemetry_202305.deb.gz.md5 -o /tmp/telemetry_tmp/telemetry_202305.deb.gz.md5"),
            call("curl --interface eth0 -s --connect-timeout 10 -w \"%{http_code}\" http://10.20.17.0/networkfirmware/ACS/telemetry_202305.deb.gz -o /tmp/telemetry_tmp/telemetry_202305.deb.gz"),
            call("curl --interface eth0 -s --connect-timeout 10 -w \"%{http_code}\" http://10.20.17.0/networkfirmware/ACS/telemetry_202305.deb.gz.md5 -o /tmp/telemetry_tmp/telemetry_202305.deb.gz.md5"),
            call("curl --interface eth0 -s --connect-timeout 10 -w \"%{http_code}\" http://10.20.17.0/networkfirmware/ACS/telemetry_202305.deb.gz.md5 -o /tmp/telemetry_tmp/telemetry_202305.deb.gz.md5"),
            call("md5sum /tmp/telemetry_tmp/telemetry_202305.deb.gz"),
            call("cat /tmp/telemetry_tmp/telemetry_202305.deb.gz.md5 | tr -d '\n\r'"),
            call("docker images --format \{\{.Repository\}\}"),
            call("gzip -d /tmp/telemetry_tmp/telemetry_202305.deb.gz"),
            call("dpkg -x /tmp/telemetry_tmp/telemetry_202305.deb /tmp/telemetry_tmp"),
            call("docker cp /tmp/telemetry_tmp/usr/sbin/telemetry telemetry:/usr/sbin/"),
            call("sudo systemctl reset-failed telemetry"),
            call("sudo systemctl restart telemetry"),
            call("rm -rf /tmp/telemetry_tmp")
        ]

    @patch('postupgrade_actions.get_switch_type')
    @patch('postupgrade_actions.get_cloudtype_config')
    @patch('postupgrade_actions.get_sonic_version_info')
    @patch('postupgrade_actions.exec_cmd')
    def test_update_telemetry_failed_retries_02(self, mock_cmd, mock_version_info, mock_get_cloudtype_config, mock_get_switch_type):
        '''
        Test update_telemetry_deb
        The build version is 20230531.20, postupgrade_actions should apply the fix
        '''
        mock_version_info.return_value = {'build_version': '20230531.20'}
        mock_get_cloudtype_config.return_value = "public"
        mock_get_switch_type.return_value = "ToRRouter"

        mock_cmd.side_effect = [
            (0, 'executed: mkdir -p /tmp/telemetry_tmp'),
            (0, 'up'),
            (0, '500'),
            (0, '500'),
            (0, '500'),
            (0, '500'),
            (0, '500'),
            (0, '500'),
            (0, '500'),
            (0, '500'),
            (0, '500'),
            (0, '500'),
        ]

        update_telemetry_deb()
        assert len(mock_cmd.call_args_list) == 12

        assert mock_cmd.call_args_list == [
            call("mkdir -p /tmp/telemetry_tmp"),
            call("cat /sys/class/net/eth0/operstate | tr -d '\n\r'"),
            call("curl --interface eth0 -s --connect-timeout 10 -w \"%{http_code}\" http://10.20.17.0/networkfirmware/ACS/telemetry_202305.deb.gz -o /tmp/telemetry_tmp/telemetry_202305.deb.gz"),
            call("curl --interface eth0 -s --connect-timeout 10 -w \"%{http_code}\" http://10.20.17.0/networkfirmware/ACS/telemetry_202305.deb.gz.md5 -o /tmp/telemetry_tmp/telemetry_202305.deb.gz.md5"),
            call("curl --interface eth0 -s --connect-timeout 10 -w \"%{http_code}\" http://10.20.17.0/networkfirmware/ACS/telemetry_202305.deb.gz -o /tmp/telemetry_tmp/telemetry_202305.deb.gz"),
            call("curl --interface eth0 -s --connect-timeout 10 -w \"%{http_code}\" http://10.20.17.0/networkfirmware/ACS/telemetry_202305.deb.gz.md5 -o /tmp/telemetry_tmp/telemetry_202305.deb.gz.md5"),
            call("curl --interface eth0 -s --connect-timeout 10 -w \"%{http_code}\" http://10.20.17.0/networkfirmware/ACS/telemetry_202305.deb.gz -o /tmp/telemetry_tmp/telemetry_202305.deb.gz"),
            call("curl --interface eth0 -s --connect-timeout 10 -w \"%{http_code}\" http://10.20.17.0/networkfirmware/ACS/telemetry_202305.deb.gz.md5 -o /tmp/telemetry_tmp/telemetry_202305.deb.gz.md5"),
            call("curl --interface eth0 -s --connect-timeout 10 -w \"%{http_code}\" http://10.20.17.0/networkfirmware/ACS/telemetry_202305.deb.gz -o /tmp/telemetry_tmp/telemetry_202305.deb.gz"),
            call("curl --interface eth0 -s --connect-timeout 10 -w \"%{http_code}\" http://10.20.17.0/networkfirmware/ACS/telemetry_202305.deb.gz.md5 -o /tmp/telemetry_tmp/telemetry_202305.deb.gz.md5"),
            call("curl --interface eth0 -s --connect-timeout 10 -w \"%{http_code}\" http://10.20.17.0/networkfirmware/ACS/telemetry_202305.deb.gz -o /tmp/telemetry_tmp/telemetry_202305.deb.gz"),
            call("curl --interface eth0 -s --connect-timeout 10 -w \"%{http_code}\" http://10.20.17.0/networkfirmware/ACS/telemetry_202305.deb.gz.md5 -o /tmp/telemetry_tmp/telemetry_202305.deb.gz.md5"),
        ]

    @patch('postupgrade_actions.get_switch_type')
    @patch('postupgrade_actions.get_cloudtype_config')
    @patch('postupgrade_actions.get_sonic_version_info')
    @patch('postupgrade_actions.exec_cmd')
    def test_update_telemetry_failed_retries_03(self, mock_cmd, mock_version_info, mock_get_cloudtype_config, mock_get_switch_type):
        '''
        Test update_telemetry_deb
        The build version is 20230531.20, postupgrade_actions should apply the fix
        '''
        mock_version_info.return_value = {'build_version': '20230531.20'}
        mock_get_cloudtype_config.return_value = "public"
        mock_get_switch_type.return_value = "ToRRouter"

        mock_cmd.side_effect = [
            (0, 'executed: mkdir -p /tmp/telemetry_tmp'),
            (0, 'up'),
            (0, '404'),
            (0, '000'),
            (0, '404'),
            (0, '000'),
        ]

        update_telemetry_deb()
        assert len(mock_cmd.call_args_list) == 6

        assert mock_cmd.call_args_list == [
            call("mkdir -p /tmp/telemetry_tmp"),
            call("cat /sys/class/net/eth0/operstate | tr -d '\n\r'"),
            call("curl --interface eth0 -s --connect-timeout 10 -w \"%{http_code}\" http://10.20.17.0/networkfirmware/ACS/telemetry_202305.deb.gz -o /tmp/telemetry_tmp/telemetry_202305.deb.gz"),
            call("curl --interface eth0 -s --connect-timeout 10 -w \"%{http_code}\" http://[2001:506:28:100c::1]/networkfirmware/ACS/telemetry_202305.deb.gz -o /tmp/telemetry_tmp/telemetry_202305.deb.gz"),
            call("curl --interface eth0 -s --connect-timeout 10 -w \"%{http_code}\" http://10.20.17.0/networkfirmware/ACS/telemetry_202305.deb.gz.md5 -o /tmp/telemetry_tmp/telemetry_202305.deb.gz.md5"),
            call("curl --interface eth0 -s --connect-timeout 10 -w \"%{http_code}\" http://[2001:506:28:100c::1]/networkfirmware/ACS/telemetry_202305.deb.gz.md5 -o /tmp/telemetry_tmp/telemetry_202305.deb.gz.md5"),
        ]

    @patch('postupgrade_actions.get_switch_type')
    @patch('postupgrade_actions.get_cloudtype_config')
    @patch('postupgrade_actions.get_sonic_version_info')
    @patch('postupgrade_actions.exec_cmd')
    def test_update_telemetry_failed_retries_04(self, mock_cmd, mock_version_info, mock_get_cloudtype_config, mock_get_switch_type):
        '''
        Test update_telemetry_deb
        The build version is 20230531.20, postupgrade_actions should apply the fix
        '''
        mock_version_info.return_value = {'build_version': '20230531.20'}
        mock_get_cloudtype_config.return_value = "public"
        mock_get_switch_type.return_value = "ToRRouter"

        mock_cmd.side_effect = [
            (0, 'executed: mkdir -p /tmp/telemetry_tmp'),
            (0, 'up'),
            (0, '500'),
            (0, '200'),
            (0, '500'),
            (0, '500'),
            (0, '500'),
            (0, '500'),
        ]

        update_telemetry_deb()
        assert len(mock_cmd.call_args_list) == 8

        assert mock_cmd.call_args_list == [
            call("mkdir -p /tmp/telemetry_tmp"),
            call("cat /sys/class/net/eth0/operstate | tr -d '\n\r'"),
            call("curl --interface eth0 -s --connect-timeout 10 -w \"%{http_code}\" http://10.20.17.0/networkfirmware/ACS/telemetry_202305.deb.gz -o /tmp/telemetry_tmp/telemetry_202305.deb.gz"),
            call("curl --interface eth0 -s --connect-timeout 10 -w \"%{http_code}\" http://10.20.17.0/networkfirmware/ACS/telemetry_202305.deb.gz.md5 -o /tmp/telemetry_tmp/telemetry_202305.deb.gz.md5"),
            call("curl --interface eth0 -s --connect-timeout 10 -w \"%{http_code}\" http://10.20.17.0/networkfirmware/ACS/telemetry_202305.deb.gz -o /tmp/telemetry_tmp/telemetry_202305.deb.gz"),
            call("curl --interface eth0 -s --connect-timeout 10 -w \"%{http_code}\" http://10.20.17.0/networkfirmware/ACS/telemetry_202305.deb.gz -o /tmp/telemetry_tmp/telemetry_202305.deb.gz"),
            call("curl --interface eth0 -s --connect-timeout 10 -w \"%{http_code}\" http://10.20.17.0/networkfirmware/ACS/telemetry_202305.deb.gz -o /tmp/telemetry_tmp/telemetry_202305.deb.gz"),
            call("curl --interface eth0 -s --connect-timeout 10 -w \"%{http_code}\" http://10.20.17.0/networkfirmware/ACS/telemetry_202305.deb.gz -o /tmp/telemetry_tmp/telemetry_202305.deb.gz"),
        ]
