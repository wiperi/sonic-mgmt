#!/usr/bin/env python

from __future__ import absolute_import, division, print_function

import logging
import os
import sys
import unittest
from mock import patch
from mock import Mock
from unittest.mock import MagicMock
from io import StringIO, BytesIO
from unittest import TestCase
import time

sys.path.insert(0, "..")
sys.modules["swsssdk"] = Mock()
sys.modules["sonic_py_common"] = Mock()
sys.modules['sonic_platform'] = Mock()
sys.modules['sonic_platform_base'] = Mock()
sys.modules['sonic_platform_base.sonic_sfp'] = Mock()
sys.modules['sonic_platform_base.sonic_sfp.sfputilhelper'] = Mock()
time.sleep = Mock()

from postupgrade_actions_data import bcm_40g_phy_reinit_cint_script
from postupgrade_actions_data.bcm_40g_phy_reinit_cint_script import *

py_verrsion = sys.version_info[0]


logger = logging.getLogger( 'bcm_40g_phy_reinit_cint_script' )


class TestBcm40GPhyReInit(TestCase):


    @patch('postupgrade_actions_data.bcm_40g_phy_reinit_cint_script.CintTool.obtainPortList', MagicMock(return_value=['Ethernet0', 'Ethernet4']))
    @patch('postupgrade_actions_data.bcm_40g_phy_reinit_cint_script.CintTool.runBcmCmd', MagicMock(return_value=True))
    @patch('postupgrade_actions_data.bcm_40g_phy_reinit_cint_script.Th40GFiberConfigurator.initPortMapping', MagicMock(return_value=True))
    @patch('swsssdk.SonicV2Connector', MagicMock(return_value=['Ethernet0', 'Ethernet4']))
    def test_configurator_exec(self):
        """
            Validates the overall execution on bcm_40g_phy_reinit_cint_script script.
        """
        config = bcm_40g_phy_reinit_cint_script.Th40GFiberConfigurator()
        ret = config.exec()
        self.assertTrue(ret == None)


    @patch('postupgrade_actions_data.bcm_40g_phy_reinit_cint_script.CintTool.obtainPortList', MagicMock(return_value=['Ethernet0', 'Ethernet4']))
    @patch('postupgrade_actions_data.bcm_40g_phy_reinit_cint_script.CintTool.runBcmCmd', MagicMock(return_value=True))
    @patch('postupgrade_actions_data.bcm_40g_phy_reinit_cint_script.Th40GFiberConfigurator.initPortMapping', MagicMock(return_value=True))
    @patch('sonic_platform_base.sonic_sfp.sfputilhelper.SfpUtilHelper')
    @patch('swsssdk.SonicV2Connector', MagicMock(return_value=['Ethernet0', 'Ethernet4']))
    @patch('sonic_platform.platform.Platform.get_chassis.get_sfp', MagicMock(return_value=True))
    def test_xcvrtool_initSfps(self, sfputil):
        """
            Validates the xcvr tool inisfps.
        """
        mock_object = MagicMock()
        sfputil.get_logical_to_physical.return_value = ['0', '1']
        tool = bcm_40g_phy_reinit_cint_script.XcvrTool()
        intfs = ['Ethernet0']
        ret = tool.initSfps(intfs)
        self.assertTrue(ret == True)


    @patch('postupgrade_actions_data.bcm_40g_phy_reinit_cint_script.CintTool.obtainPortList', MagicMock(return_value=['Ethernet0', 'Ethernet4']))
    @patch('postupgrade_actions_data.bcm_40g_phy_reinit_cint_script.CintTool.runBcmCmd', MagicMock(return_value=True))
    @patch('postupgrade_actions_data.bcm_40g_phy_reinit_cint_script.Th40GFiberConfigurator.initPortMapping', MagicMock(return_value=True))
    @patch('swsssdk.SonicV2Connector', MagicMock(return_value=['Ethernet0', 'Ethernet4']))
    def test_xcvrtool_txdisable(self):
        """
            Validates the xcvr tool txdisable.
        """
        mock_object = MagicMock()
        tool = bcm_40g_phy_reinit_cint_script.XcvrTool()
        portInfo = 'Ethernet0'
        disable = False
        ret = tool.txDisable(portInfo, disable)
        self.assertTrue(ret == None)

