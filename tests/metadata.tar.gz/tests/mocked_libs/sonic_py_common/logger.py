class Logger():
    info_call_count = 0
    def __init__(self, log_identifier):
        pass
    
    def log_info(self, msg):
        Logger.info_call_count += 1