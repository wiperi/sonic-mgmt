import sys
import pytest
from unittest.mock import call, patch, MagicMock

sys.modules['sonic_platform'] = MagicMock()
sys.modules['sonic_py_common'] = MagicMock()
from postupgrade_actions import fix_sudoers_cat_command

CHECK_FIXED_SUDOERS = r"cat /etc/sudoers | grep '/bin/cat /var/log/syslog, /bin/cat /var/log/syslog.1 /var/log/syslog, /bin/cat /var/log/syslog.1, \\'"
CHECK_UNKNOWN_SUDOERS = r"cat /etc/sudoers | grep '/bin/cat /var/log/syslog\*, \\'"
REPLACE_SUDOERS = r"s|/bin/cat /var/log/syslog\*, \\|/bin/cat /var/log/syslog, /bin/cat /var/log/syslog.1 /var/log/syslog, /bin/cat /var/log/syslog.1, \\|g"
POSTUPGRADE_ACTIONS_DATA_DIR = '/postupgrade_actions_data_dir'

class TestFixCat(object):
    def setup_method(self):
        print('SETUP')

    @patch('postupgrade_actions.log_info')
    @patch('postupgrade_actions.exec_cmd')
    @patch('postupgrade_actions.POSTUPGRADE_ACTIONS_DATA_DIR', POSTUPGRADE_ACTIONS_DATA_DIR)
    @patch('sonic_py_common.get_sonic_version_info', MagicMock(return_value={'build_version': '20201231.85'}))
    def test_fix_sudoers_cat_success_update(self, mock_exec_cmd, mock_log_info):
        mock_exec_cmd.side_effect = [
            (1, 'pre-check cat in sudoers: not updated for cat issue, updating now'),
            (0, 'pre-check not supported sudoers'),
            (0, 'cat sudoers script is updated succesfully'),
            (0, 'post-check cat in sudoers: successfully updated')
        ]

        fix_sudoers_cat_command()
        print(mock_exec_cmd.call_args_list)
        print(mock_log_info.call_args_list)

        assert mock_exec_cmd.call_args_list == [
            call(cmd=CHECK_FIXED_SUDOERS,verbose=False),
            call(cmd=CHECK_UNKNOWN_SUDOERS,verbose=False),
            call("sudo bash {}/fix_sudo.sh '{}'".format(POSTUPGRADE_ACTIONS_DATA_DIR, REPLACE_SUDOERS)),
            call(cmd=CHECK_FIXED_SUDOERS,verbose=False)
        ]

        assert mock_log_info.call_args_list == [
            call('fix_sudoers_cat_command: sudoers fixed: post-check cat in sudoers: successfully updated')
        ]

    @patch('postupgrade_actions.log_error')
    @patch('postupgrade_actions.exec_cmd')
    @patch('postupgrade_actions.POSTUPGRADE_ACTIONS_DATA_DIR', POSTUPGRADE_ACTIONS_DATA_DIR)
    @patch('sonic_py_common.get_sonic_version_info', MagicMock(return_value={'build_version': '20201231.85'}))
    def test_fix_sudoers_cat_failed_update(self, mock_exec_cmd, mock_log_error):
        mock_exec_cmd.side_effect = [
            (1, 'pre-check cat in sudoers: not updated for cat issue, updating now'),
            (0, 'pre-check not supported sudoers'),
            (0, 'cat sudoers script is updated succesfully'),
            (1, 'post-check cat in sudoers: unsuccessfully updated')
        ]

        fix_sudoers_cat_command()
        print(mock_exec_cmd.call_args_list)
        print(mock_log_error.call_args_list)

        assert mock_exec_cmd.call_args_list == [
            call(cmd=CHECK_FIXED_SUDOERS,verbose=False),
            call(cmd=CHECK_UNKNOWN_SUDOERS,verbose=False),
            call("sudo bash {}/fix_sudo.sh '{}'".format(POSTUPGRADE_ACTIONS_DATA_DIR, REPLACE_SUDOERS)),
            call(cmd=CHECK_FIXED_SUDOERS,verbose=False)
        ]

        assert mock_log_error.call_args_list == [
            call('fix_sudoers_cat_command: sudoers fix failed: post-check cat in sudoers: unsuccessfully updated')
        ]

    @patch('postupgrade_actions.log_info')
    @patch('postupgrade_actions.exec_cmd')
    @patch('postupgrade_actions.POSTUPGRADE_ACTIONS_DATA_DIR', POSTUPGRADE_ACTIONS_DATA_DIR)
    @patch('sonic_py_common.get_sonic_version_info', MagicMock(return_value={'build_version': '20201231.85'}))
    def test_fix_sudoers_cat_already_update(self, mock_exec_cmd, mock_log_info):
        mock_exec_cmd.side_effect = [
            (0, 'pre-check cat in sudoers: already updated'),
        ]

        fix_sudoers_cat_command()
        print(mock_exec_cmd.call_args_list)
        print(mock_log_info.call_args_list)

        assert mock_exec_cmd.call_args_list == [
            call(cmd=CHECK_FIXED_SUDOERS,verbose=False),
        ]

        assert mock_log_info.call_args_list == [
            call('fix_sudoers_cat_command: sudoers already fixed: pre-check cat in sudoers: already updated')
        ]

    @patch('postupgrade_actions.log_info')
    @patch('postupgrade_actions.exec_cmd')
    @patch('postupgrade_actions.POSTUPGRADE_ACTIONS_DATA_DIR', POSTUPGRADE_ACTIONS_DATA_DIR)
    @patch('sonic_py_common.get_sonic_version_info', MagicMock(return_value={'build_version': '20201231.85'}))
    def test_fix_sudoers_cat_unknown(self, mock_exec_cmd, mock_log_info):
        mock_exec_cmd.side_effect = [
            (1, 'pre-check cat in sudoers: already updated'),
            (1, 'pre-check not supported sudoers'),
        ]

        fix_sudoers_cat_command()
        print(mock_exec_cmd.call_args_list)
        print(mock_log_info.call_args_list)

        assert mock_exec_cmd.call_args_list == [
            call(cmd=CHECK_FIXED_SUDOERS,verbose=False),
            call(cmd=CHECK_UNKNOWN_SUDOERS,verbose=False),
        ]

        assert mock_log_info.call_args_list == [
            call('fix_sudoers_cat_command:unknown sudoers: pre-check not supported sudoers , skip fix.')
        ]

    def teardown_method(self):
        print('TEAR DOWN')
