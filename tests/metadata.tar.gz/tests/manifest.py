import json
import os
import hashlib
import sys

if sys.version_info.major == 2:
    from pathlib2 import Path
else:
    from pathlib import Path

WINDOWS_LINE_ENDING = b'\r\n'
UNIX_LINE_ENDING = b'\n'

class IllegalArgumentError(ValueError):
    pass

class Manifest(object):
    def __init__(self):
        self.files = {}

    def add_file(self, file):
        self.files[file.path] = file

    def dump(self):
        root = {}
        root['Files'] = []
        for file in sorted(self.files.values(), key = lambda f: f.path):
            root['Files'].append(file.dump())
        return root

    def flush(self, target):
        with open(target, 'w') as f:
            f.write(json.dumps(self.dump(), indent=2, sort_keys=True))

    def update(self, script_root, exclude):
        files = {}
        for file_path in iter_files(script_root, exclude):
            relative_path = get_relative_file_path(file_path, script_root)
            if relative_path not in self.files:
                file = File(relative_path)
            else:
                file = self.files[relative_path]
            length, hash = get_file_metadata(get_actual_file_path(file_path))
            file.update_property('Md5Hash', hash)
            file.update_property('Length', length)
            files[relative_path] = file
        self.files = files

    def apply_ops(self, ops):
        for op in ops:
            path = op[0]
            if path not in self.files:
                raise IllegalArgumentError("File {} does not exist in scripts directory.".format(path))
            file = self.files[path]
            action = op[1]
            if action == "add":
                args = op[2:]
                or_index = [i for i in range(len(args)) if args[i] == "or"]
                or_index.append(len(args))
                prev_index = -1
                for index in or_index:
                    file.add_match_rule(args[prev_index+1: index])
                    prev_index = index
            else:
                raise IllegalArgumentError("Action {} is not recognized.".format(action))

    @staticmethod
    def load(file_path):
        manifest = Manifest()
        with open(file_path, 'r') as f:
            obj = json.load(f)
            for file in obj['Files']:
                file_obj = File.load(file)
                manifest.files[file_obj.path] = file_obj
        return manifest

class File(object):
    def __init__(self, path):
        self.path = path
        self.information = {}
        self.match_rules = []

    def update_property(self, name, value):
        self.information[name] = str(value)

    def dump(self):
        file = {}
        file['Path'] = self.path
        file['Information'] = {}
        file['Information']['Property'] = {}
        for p_name in sorted(self.information.keys(), key = lambda p_name: p_name):
            file['Information']['Property'][p_name] = self.information[p_name]

        file['MatchRules'] = []
        for rule in self.match_rules:
            file['MatchRules'].append(rule.dump())
        return file

    def is_match(self, info):
        res = [match_rule.is_match(info) for match_rule in self.match_rules]
        return len(res) == 0 or any(res)

    def add_match_rule(self, args):
        match_rule = MatchRule()
        and_index = [i for i in range(len(args)) if args[i] == "and"]
        and_index.append(len(args))
        prev_index = -1
        for index in and_index:
            match_rule.add_condition(args[prev_index+1: index])
            prev_index = index
        self.match_rules.append(match_rule)

    @staticmethod
    def load(file_dict):
        if 'Path' not in file_dict:
            raise Exception('Path is required for File object')

        file = File(file_dict['Path'])
        if 'Information' in file_dict and 'Property' in file_dict['Information']:
            for prop_name, prop_val in file_dict['Information']['Property'].items():
                file.update_property(prop_name, prop_val)

        if 'MatchRules' in file_dict:
            for rule_dict in file_dict['MatchRules']:
                file.match_rules.append(MatchRule.load(rule_dict))

        return file

class MatchRule(object):
    TYPE = set(['AnyOf', 'NoneOf', 'Equal', 'NotEqual', 'LessThan', 'LessThanOrEq', 'GreaterThan', 'GreaterThanOrEq', 'Regex'])

    def __init__(self):
        self.description = None
        self.conditions = []

    def add_condition(self, args):
        if len(args) != 3:
            raise IllegalArgumentError("Adding condition requires 3 arguments, see help: {}".format(args))
        name, type, value = args
        if type not in MatchRule.TYPE:
            raise ValueError("Not support type " + type)
        self.conditions.append((name, type, value))

    def dump(self):
        rule = {}
        if self.description:
            rule['Description'] = self.description
        rule['Conditions'] = []
        for condition in sorted(self.conditions, key = lambda c: c[0]):
            c = {}
            c['Name'], c['Type'], c['Value'] = condition
            rule['Conditions'].append(c)
        return rule

    def is_match(self, info):
        return all([condition_is_match(condition, info) for condition in self.conditions])

    @staticmethod
    def load(rule_dict):
        rule = MatchRule()
        if 'Description' in rule_dict:
            rule.description = rule_dict['Description']

        if 'Conditions' in rule_dict:
            for condition in rule_dict['Conditions']:
                rule.add_condition([condition['Name'], condition['Type'], condition['Value']])
        return rule

def greater_than(left, right):
    left_list = left.split(".")
    right_list = right.split(".")
    if len(left_list) != len(right_list):
        return left > right
    l_first = left_list[0]
    r_first = right_list[0]
    if l_first == r_first:
        if len(left_list) == 1:
            return False
        return greater_than(left[len(l_first)+1:], right[len(r_first)+1:])
    if l_first.isdigit() and r_first.isdigit():
        return int(l_first) > int(r_first)
    return l_first > r_first

def condition_is_match(condition, info):
    name, type, value = condition
    if name not in info:
        return True
    info_value = info[name]
    values = value.split(",")
    if type == "AnyOf":
        return info_value in values
    if type == "NoneOf":
        return info_value not in values
    if len(values) != 1:
        raise ValueError("MatchRule type " + type + " should only have one value provided, but " + value + " is in the manifest")
    if type == "Equal":
        return info_value == value
    if type == "NotEqual":
        return info_value != value
    if type == "LessThan":
        return not greater_than(info_value, value) and not info_value != value
    if type == "LessThanOrEq":
        return not greater_than(info_value, value)
    if type == "GreaterThan":
        return greater_than(info_value, value)
    if type == "GreaterThanOrEq":
        return greater_than(info_value, value) or info_value == value
    if type == "Regex":
        import re
        return re.match("^"+value+"$", info_value) != None
    raise ValueError("Unrecognised match type " + type)

def iter_files(root, exclude):
    for parent, dir_names, file_names in os.walk(root):
        for file_name in file_names:
            path = Path(os.path.join(parent, file_name))
            path_str = get_relative_file_path(path, root)
            filter = False
            for excluded_dir in exclude:
                if path_str.startswith(excluded_dir):
                    filter = True
                    break
            if filter:
                continue
            yield path

def get_actual_file_path(path):
    return str(path.as_posix())

def get_relative_file_path(path, prefix):
    path = str(path.as_posix())
    if path.startswith(prefix):
        return path[len(prefix):]
    return path

def get_file_metadata(filePath):
    with open(filePath, "rb") as f:
        content = f.read()
    content = content.replace(WINDOWS_LINE_ENDING, UNIX_LINE_ENDING)
    hash = hashlib.md5(content).hexdigest()
    return len(content), hash
