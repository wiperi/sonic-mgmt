#!/usr/bin/env python

import pytest
import subprocess
import imp
import os
import cleanup_firmware

# Mock output for "sonic_installer list"
BASIC_INSTALLER_LIST = """Current: SONiC-OS-20181130.31
Next: SONiC-OS-20181130.31
Available:
SONiC-OS-20181130.31
SONiC-OS-20181130.50
"""

LONG_INSTALLER_LIST = """Current: SONiC-OS-20181130.50
Next: SONiC-OS-20191130.20
Available:
SONiC-OS-20180330.134
SONiC-OS-20181130.31
SONiC-OS-20181130.50
SONiC-OS-20191130.1
SONiC-OS-20191130.20
SONiC-OS-20200430.13
"""

SINGLE_INSTALLER_LIST = """Current: SONiC-OS-20181130.31
Next: SONiC-OS-20181130.31
Available:
SONiC-OS-20181130.31
"""

CISCO_INSTALLER_LIST = """Command: /usr/local/bin/autoboot.sh -c
image-20181130.70/sonic-nbi-cisco.ks

Current: SONiC-OS-20181130.31
Next: SONiC-OS-20181130.31
Available:
SONiC-OS-20181130.31
SONiC-OS-20181130.50
"""

# Expected output from parsing "sonic_installer list"
BASIC_PARSED_INSTALLER_LIST = ("SONiC-OS-20181130.31", "SONiC-OS-20181130.31", ["SONiC-OS-20181130.31", "SONiC-OS-20181130.50"])

# Expected images to be removed after running the cleanup script with different
# levels of disk utilization
BASIC_REMOVED_IMAGES_HIGH_UTIL = ["SONiC-OS-20181130.50"]

LONG_REMOVED_IMAGES_LOW_UTIL = ["SONiC-OS-20180330.134", "SONiC-OS-20181130.31", "SONiC-OS-20191130.1"]
LONG_REMOVED_IMAGES_HIGH_UTIL = ["SONiC-OS-20180330.134", "SONiC-OS-20181130.31", "SONiC-OS-20191130.1", "SONiC-OS-20200430.13"]


def mock_sonic_installer_list(mock_output):
    """
        Returns a method to be used in place of "sonic_installer list."
        This method will return the specified mock output when called in
        cleanup_firmware.
    """
    return lambda x: mock_output


def mock_low_disk_util():
    """
        Simulates a level of disk usage 10% lower than the threshold
        specified in cleanup_firmware.
    """
    return cleanup_firmware.DISK_CLEANUP_PCT_THRESHOLD - 10


def mock_threshold_disk_util():
    """
        Simulates a level of disk usage exactly at the threshold
        specified in cleanup_firmware.
    """
    return cleanup_firmware.DISK_CLEANUP_PCT_THRESHOLD


def mock_high_disk_util():
    """
        Simulates a level of disk usage 10% higher than the threshold
        specified in cleanup_firmware.
    """
    return cleanup_firmware.DISK_CLEANUP_PCT_THRESHOLD + 10


class TestCleanupFirmware(object):
    def setup_method(self, method):
        """
            Before each method we want to setup a method to track which
            images would be removed by cleanup_firmware given the test
            setup.
        """
        self.removed_firmwares = []
        cleanup_firmware.rm_firmware = lambda name: self.removed_firmwares.append(name)

    def test_parse_logic(self):
        """
            Validates that parse_list correctly parses the output of
            sonic_installer list.
        """
        (current_img, next_img, images) = cleanup_firmware.parse_list(BASIC_INSTALLER_LIST)
        assert current_img == BASIC_PARSED_INSTALLER_LIST[0]
        assert next_img == BASIC_PARSED_INSTALLER_LIST[1]
        assert set(images) == set(BASIC_PARSED_INSTALLER_LIST[2])

    def test_cisco_parse_logic(self):
        """
            Validates that parse_list correctly parses the output of
            sonic_installer list on Cisco devices.
        """
        (current_img, next_img, images) = cleanup_firmware.parse_list(CISCO_INSTALLER_LIST)
        assert current_img == BASIC_PARSED_INSTALLER_LIST[0]
        assert next_img == BASIC_PARSED_INSTALLER_LIST[1]
        assert set(images) == set(BASIC_PARSED_INSTALLER_LIST[2])

    def test_basic_cleanup_low_util(self):
        """
            Validates that no images are deleted when only one extra image
            exists and the disk has free space.
        """
        subprocess.check_output = mock_sonic_installer_list(BASIC_INSTALLER_LIST)
        cleanup_firmware.get_disk_utilization = mock_low_disk_util

        cleanup_firmware.main()
        assert len(self.removed_firmwares) == 0

    def test_basic_cleanup_high_util(self):
        """
            Validates that extra images are still deleted when the disk is
            close to full.
        """
        subprocess.check_output = mock_sonic_installer_list(BASIC_INSTALLER_LIST)
        cleanup_firmware.get_disk_utilization = mock_high_disk_util

        cleanup_firmware.main()
        assert set(self.removed_firmwares) == set(BASIC_REMOVED_IMAGES_HIGH_UTIL)

    def test_basic_cleanup_threshold_util(self):
        """
            Validates that extra images are still deleted when the disk is
            right at the cleanup threshold.
        """
        subprocess.check_output = mock_sonic_installer_list(BASIC_INSTALLER_LIST)
        cleanup_firmware.get_disk_utilization = mock_threshold_disk_util

        cleanup_firmware.main()
        assert set(self.removed_firmwares) == set(BASIC_REMOVED_IMAGES_HIGH_UTIL)

    def test_long_cleanup_low_util(self):
        """
            Validates that one, and only one, extra image is kept when the
            disk has free space.
        """
        subprocess.check_output = mock_sonic_installer_list(LONG_INSTALLER_LIST)
        cleanup_firmware.get_disk_utilization = mock_low_disk_util

        cleanup_firmware.main()
        assert set(self.removed_firmwares) == set(LONG_REMOVED_IMAGES_LOW_UTIL)

    def test_long_cleanup_high_util(self):
        """
            Validates that ALL extra images are still deleted when the disk is
            close to full.
        """
        subprocess.check_output = mock_sonic_installer_list(LONG_INSTALLER_LIST)
        cleanup_firmware.get_disk_utilization = mock_high_disk_util

        cleanup_firmware.main()
        assert set(self.removed_firmwares) == set(LONG_REMOVED_IMAGES_HIGH_UTIL)

    def test_long_cleanup_threshold_util(self):
        """
            Validates that ALL extra images are still deleted when the disk is
            right at the cleanup threshold.
        """
        subprocess.check_output = mock_sonic_installer_list(LONG_INSTALLER_LIST)
        cleanup_firmware.get_disk_utilization = mock_threshold_disk_util

        cleanup_firmware.main()
        assert set(self.removed_firmwares) == set(LONG_REMOVED_IMAGES_HIGH_UTIL)

    def test_single_cleanup_threshold_util(self):
        """
            Validates that no images are deleted when no extra images exist.
        """
        subprocess.check_output = mock_sonic_installer_list(SINGLE_INSTALLER_LIST)
        cleanup_firmware.get_disk_utilization = mock_threshold_disk_util

        cleanup_firmware.main()
        assert len(self.removed_firmwares) == 0
