import pytest
import subprocess


def test_tabs_presence():
    """
    This test checks for the presence of TABs in metadata scripts.
    Usage of TABs (instead of spaces) in metadata scripts is not permitted.
    This is because HWProxy converts TABs in metadata scripts to ".", while
    transferring the scripts to the device. This leads to file corruption issues.
    Related sev2 ICM: https://portal.microsofticm.com/imp/v3/incidents/details/251079689
    """
    # Use grep to find non-binary files with tab:
    # r - recursive,
    # I - ignore binary files,
    # P - regex as defined by Perl (Perl has \t as tab)
    cmd = "grep --exclude-dir='\.pytest_cache' -rIP '\t' ../*"
    sp = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout, _ = sp.communicate()

    if stdout:
        pytest.fail("Usage of tabs is prohibited in metadata scripts. Failing scripts:\n{}".format(stdout))
