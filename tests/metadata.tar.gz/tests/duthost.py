import subprocess
import re

try:
    from sonic_py_common.device_info import get_sonic_version_info
except ImportError:
    try:
        from sonic_device_util import get_sonic_version_info
    except ImportError:
        from sonic_platform import get_sonic_version_info

def get_build_version():
    return get_sonic_version_info()['build_version']

def get_platform():
    command = "sonic-cfggen -d -v DEVICE_METADATA.localhost.platform"
    proc = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
    out, err = proc.communicate()

    if proc.returncode != 0:
        return None

    out = out.decode('utf-8')
    platform = out.rstrip('\n')
    return platform

def get_hwsku():
    command = "sonic-cfggen -d -v DEVICE_METADATA.localhost.hwsku"
    proc = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
    out, err = proc.communicate()

    if proc.returncode != 0:
        return None

    out = out.decode('utf-8')
    hwsku = out.rstrip('\n')
    return hwsku

def get_hostname():
    command = "hostname"
    proc = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
    out, err = proc.communicate()

    if proc.returncode != 0:
        return None

    out = out.decode('utf-8')
    hostname = out.rstrip('\n')
    return hostname

def get_snmp_hostname():
    command = "docker exec -i snmp hostname"
    proc = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
    out, err = proc.communicate()

    if proc.returncode != 0:
        return None

    out = out.decode('utf-8')
    hostname = out.rstrip('\n')
    return hostname

def get_switch_type():
    command = "sonic-cfggen -d -v DEVICE_METADATA.localhost.type"
    proc = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
    out, err = proc.communicate()

    if proc.returncode != 0:
        return None

    out = out.decode('utf-8')
    switch_type = out.rstrip('\n')
    return switch_type

def get_asic_type():
    command = "show platform summary"
    proc = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
    out, err = proc.communicate()

    if proc.returncode != 0:
        log_error("Unable to determine ASIC type")
        return None

    out = out.decode('utf-8')
    platform_summary = out.rstrip('\n')

    for line in platform_summary.splitlines():
        if line.startswith('ASIC:'):
            return line.strip().split()[1]

    return None

def get_reboot_cause():
    command = "show reboot-cause"
    proc = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
    out, err = proc.communicate()

    if proc.returncode != 0:
        log_error("Unable to determine reboot-cause")
        return None

    out = out.decode('utf-8')
    reboot_cause = out.rstrip('\n')

    pattern = re.match("User issued \'(.*)\' command", reboot_cause)
    if pattern:
        return pattern.group(1)

    return None

def get_port_channels():
    command = "show interfaces portchannel"
    proc = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
    out, err = proc.communicate()

    if proc.returncode != 0:
        return None

    out = out.decode('utf-8')
    return out
