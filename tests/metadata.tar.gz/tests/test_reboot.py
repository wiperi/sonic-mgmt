import sys
import pytest
from unittest.mock import call, patch, MagicMock

sys.modules['sonic_platform'] = MagicMock()
sys.modules['sonic_py_common'] = MagicMock()
from postupgrade_actions import main

POSTUPGRADE_ACTIONS_DATA_DIR = '/postupgrade_actions_data_dir'


class TestReboot(object):
    def setup_method(self):
        print('SETUP')

    def teardown_method(self):
        print('TEAR DOWN')

    @patch('postupgrade_actions.get_reboot_cause')
    @patch('postupgrade_actions.sys.exit')
    @patch('postupgrade_actions.exec_cmd', MagicMock(return_value=(0, "\n\n")))
    @patch('postupgrade_actions.get_uptime', MagicMock(return_value=1000))
    @patch('postupgrade_actions.check_device_health', MagicMock(return_value=True))
    @patch('postupgrade_actions.time.sleep', MagicMock())
    @patch('postupgrade_actions.os.geteuid', MagicMock(return_value=0))
    @patch('postupgrade_actions.POSTUPGRADE_ACTIONS_DATA_DIR', POSTUPGRADE_ACTIONS_DATA_DIR)
    @patch('postupgrade_actions.get_sonic_version_info', MagicMock(return_value={'build_version': '20201231.100'}))
    def test_warm_reboot(self, mock_exit, mock_reboot_cause):
        mock_reboot_cause.return_value = "warm-reboot"
        main()
        assert mock_exit.call_args_list == [
            call(0)
        ]

    @patch('postupgrade_actions.get_reboot_cause')
    @patch('postupgrade_actions.sys.exit')
    @patch('postupgrade_actions.exec_cmd', MagicMock(return_value=(0, "\n\n")))
    @patch('postupgrade_actions.get_uptime', MagicMock(return_value=1000))
    @patch('postupgrade_actions.check_device_health', MagicMock(return_value=True))
    @patch('postupgrade_actions.time.sleep', MagicMock())
    @patch('postupgrade_actions.os.geteuid', MagicMock(return_value=0))
    @patch('postupgrade_actions.POSTUPGRADE_ACTIONS_DATA_DIR', POSTUPGRADE_ACTIONS_DATA_DIR)
    @patch('postupgrade_actions.get_sonic_version_info', MagicMock(return_value={'build_version': '20201231.100'}))
    def test_cold_reboot(self, mock_exit, mock_reboot_cause):
        mock_reboot_cause.return_value = "cold-reboot"
        main()
        assert mock_exit.call_args_list == [
            call(0)
        ]

    @patch('postupgrade_actions.get_reboot_cause')
    @patch('postupgrade_actions.sys.exit')
    @patch('postupgrade_actions.exec_cmd', MagicMock(return_value=(0, "\n\n")))
    @patch('postupgrade_actions.get_uptime', MagicMock(return_value=1000))
    @patch('postupgrade_actions.check_device_health', MagicMock(return_value=True))
    @patch('postupgrade_actions.time.sleep', MagicMock())
    @patch('postupgrade_actions.os.geteuid', MagicMock(return_value=0))
    @patch('postupgrade_actions.POSTUPGRADE_ACTIONS_DATA_DIR', POSTUPGRADE_ACTIONS_DATA_DIR)
    @patch('postupgrade_actions.get_sonic_version_info', MagicMock(return_value={'build_version': '20201231.100'}))
    def test_other_reboot(self, mock_exit, mock_reboot_cause):
        mock_reboot_cause.return_value = None
        main()
        assert mock_exit.call_args_list == [
            call(0)
        ]
