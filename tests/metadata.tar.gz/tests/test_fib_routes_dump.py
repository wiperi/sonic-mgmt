import os
import pytest
import subprocess
import unittest
from unittest import TestCase
import json
import ast

import mock
from fib_dump import FibBase

IP_FIB_V4 = """\
  No.  Vrf    Route               Nexthop                                  Ifname
-----  -----  ------------------  ---------------------------------------  -----------------------------------------------------------
    1         192.168.104.0/25    10.0.0.57,10.0.0.59,10.0.0.61,10.0.0.63  PortChannel101,PortChannel102,PortChannel103,PortChannel104
    2         192.168.104.128/25  -                                        PortChannel101,PortChannel102,PortChannel103,PortChannel104
    3         192.168.112.0/25    10.0.0.57,10.0.0.59,10.0.0.61,10.0.0.63  -
    4         192.168.120.0/25    10.0.0.57,10.0.0.59,10.0.0.61,10.0.0.63  PortChannel101,PortChannel102,PortChannel103,PortChannel104
    5  Red    192.168.112.128/25  10.0.0.57,10.0.0.59,10.0.0.61,10.0.0.63  PortChannel101,PortChannel102,PortChannel103,PortChannel104
Total number of entries 5\

"""

IP_FIB_V6 = """\
  No.  Vrf    Route                Nexthop                              Ifname
-----  -----  -------------------  -----------------------------------  -----------------------------------------------------------
    1         20c0:fe28:0:80::/64  fc00::72,fc00::76,fc00::7a,fc00::7e  PortChannel101,PortChannel102,PortChannel103,PortChannel104
    2         20c0:fe28::/64       fc00::72,fc00::76,fc00::7a,fc00::7e  PortChannel101,PortChannel102,PortChannel103,PortChannel104
    3         20c0:fe30:0:80::/64  -                                    PortChannel101,PortChannel102,PortChannel103,PortChannel104
Total number of entries 3\

"""

IP_FIB_SPECIFIC = """\
  No.  Vrf    Route             Nexthop                                  Ifname
-----  -----  ----------------  ---------------------------------------  --------
    1         192.168.112.0/25  10.0.0.57,10.0.0.59,10.0.0.61,10.0.0.63  -
Total number of entries 1\

"""

IP_FIB_EMPTY = """\
No.    Vrf    Route    Nexthop    Ifname
-----  -----  -------  ---------  --------
Total number of entries 0\

"""

FIB_DATA = ['192.168.104.0/25', '10.0.0.57,10.0.0.59,10.0.0.61,10.0.0.63',
            'PortChannel101,PortChannel102,PortChannel103,PortChannel104', \
            'VRF-Red:192.168.112.128/25', '10.0.0.57,10.0.0.59,10.0.0.61,10.0.0.63',
            'PortChannel101,PortChannel102,PortChannel103,PortChannel104', \
            '20c0:fe28:0:80::/64', 'fc00::72,fc00::76,fc00::7a,fc00::7e',
            'PortChannel101,PortChannel102,PortChannel103,PortChannel104', \
            '20c0:fe30:0:80::/64', '-', 'PortChannel101,PortChannel102,PortChannel103,PortChannel104', \
            '192.168.120.0/25', '10.0.0.57,10.0.0.59,10.0.0.61,10.0.0.63',
            'PortChannel101,PortChannel102,PortChannel103,PortChannel104', \
            '192.168.104.128/25', '-', 'PortChannel101,PortChannel102,PortChannel103,PortChannel104', \
            '20c0:fe28::/64', 'fc00::72,fc00::76,fc00::7a,fc00::7e',
            'PortChannel101,PortChannel102,PortChannel103,PortChannel104', \
            '192.168.112.0/25', '10.0.0.57,10.0.0.59,10.0.0.61,10.0.0.63', '-']

FIB_ENTRY_LIST = [('192.168.104.0/25', '10.0.0.57,10.0.0.59,10.0.0.61,10.0.0.63',
                   'PortChannel101,PortChannel102,PortChannel103,PortChannel104'), \
                  ('192.168.104.128/25', '-', 'PortChannel101,PortChannel102,PortChannel103,PortChannel104'), \
                  ('192.168.112.0/25', '10.0.0.57,10.0.0.59,10.0.0.61,10.0.0.63', '-'), \
                  ('192.168.120.0/25', '10.0.0.57,10.0.0.59,10.0.0.61,10.0.0.63',
                   'PortChannel101,PortChannel102,PortChannel103,PortChannel104'), \
                  ('20c0:fe28:0:80::/64', 'fc00::72,fc00::76,fc00::7a,fc00::7e',
                   'PortChannel101,PortChannel102,PortChannel103,PortChannel104'), \
                  ('20c0:fe28::/64', 'fc00::72,fc00::76,fc00::7a,fc00::7e',
                   'PortChannel101,PortChannel102,PortChannel103,PortChannel104'), \
                  ('20c0:fe30:0:80::/64', '-', 'PortChannel101,PortChannel102,PortChannel103,PortChannel104'), \
                  ('VRF-Red:192.168.112.128/25', '10.0.0.57,10.0.0.59,10.0.0.61,10.0.0.63',
                   'PortChannel101,PortChannel102,PortChannel103,PortChannel104')]

FIB_ENTRY_LIST_V4 = [('192.168.104.0/25', '10.0.0.57,10.0.0.59,10.0.0.61,10.0.0.63',
                      'PortChannel101,PortChannel102,PortChannel103,PortChannel104'), \
                     ('192.168.104.128/25', '-', 'PortChannel101,PortChannel102,PortChannel103,PortChannel104'), \
                     ('192.168.112.0/25', '10.0.0.57,10.0.0.59,10.0.0.61,10.0.0.63', '-'), \
                     ('192.168.120.0/25', '10.0.0.57,10.0.0.59,10.0.0.61,10.0.0.63',
                      'PortChannel101,PortChannel102,PortChannel103,PortChannel104'), \
                     ('VRF-Red:192.168.112.128/25', '10.0.0.57,10.0.0.59,10.0.0.61,10.0.0.63',
                      'PortChannel101,PortChannel102,PortChannel103,PortChannel104')]

FIB_ENTRY_LIST_V6 = [('20c0:fe28:0:80::/64', 'fc00::72,fc00::76,fc00::7a,fc00::7e',
                      'PortChannel101,PortChannel102,PortChannel103,PortChannel104'), \
                     ('20c0:fe28::/64', 'fc00::72,fc00::76,fc00::7a,fc00::7e',
                      'PortChannel101,PortChannel102,PortChannel103,PortChannel104'), \
                     ('20c0:fe30:0:80::/64', '-', 'PortChannel101,PortChannel102,PortChannel103,PortChannel104')]


class TestFibshow(TestCase):
    def setUp(self):
        self.fib_dump = FibBase()

    @mock.patch.object(FibBase, "fetch_fib_data")
    def test_process_fib_data(self, mock_fetch_fib_data):
        mock_fetch_fib_data.return_value = FIB_DATA
        fib_entry_list = self.fib_dump.process_fib_data()
        self.assertTrue(fib_entry_list == FIB_ENTRY_LIST)

    @mock.patch.object(FibBase, "process_fib_data")
    def test_display_v4(self, mock_process_fib_data):
        mock_process_fib_data.return_value = FIB_ENTRY_LIST
        filename = self.fib_dump.display("-4", None)
        _, output, _ = self.fib_dump.run_cmd("cat {}".format(filename))
        self.assertTrue(output == IP_FIB_V4)

    @mock.patch.object(FibBase, "process_fib_data")
    def test_display_v6(self, mock_process_fib_data):
        mock_process_fib_data.return_value = FIB_ENTRY_LIST
        filename = self.fib_dump.display("-6", None)
        _, output, _ = self.fib_dump.run_cmd("cat {}".format(filename))
        self.assertTrue(output == IP_FIB_V6)

    @mock.patch.object(FibBase, "process_fib_data")
    def test_display_specific_prefix(self, mock_process_fib_data):
        mock_process_fib_data.return_value = FIB_ENTRY_LIST
        filename = self.fib_dump.display(None, "192.168.112.0/25")
        _, output, _ = self.fib_dump.run_cmd("cat {}".format(filename))
        self.assertTrue(output == IP_FIB_SPECIFIC)

    @mock.patch.object(FibBase, "process_fib_data")
    def test_display_v4_empty(self, mock_process_fib_data):
        mock_process_fib_data.return_value = FIB_ENTRY_LIST_V6
        filename = self.fib_dump.display("-4", None)
        _, output, _ = self.fib_dump.run_cmd("cat {}".format(filename))
        self.assertTrue(output == IP_FIB_EMPTY)

    @mock.patch.object(FibBase, "process_fib_data")
    def test_display_v6_empty(self, mock_process_fib_data):
        mock_process_fib_data.return_value = FIB_ENTRY_LIST_V4
        filename = self.fib_dump.display("-6", None)
        _, output, _ = self.fib_dump.run_cmd("cat {}".format(filename))
        self.assertTrue(output == IP_FIB_EMPTY)

    @mock.patch.object(FibBase, "process_fib_data")
    def test_display_specific_prefix_empty(self, mock_process_fib_data):
        mock_process_fib_data.return_value = FIB_ENTRY_LIST
        filename = self.fib_dump.display(None, "192.168.112.65/25")
        _, output, _ = self.fib_dump.run_cmd("cat {}".format(filename))
        self.assertTrue(output == IP_FIB_EMPTY)


if __name__ == "__main__":
    unittest.main(verbosity=2)
