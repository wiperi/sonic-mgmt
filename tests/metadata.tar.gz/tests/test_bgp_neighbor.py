#!/usr/bin/env python

import os
import sys
import unittest
from io import StringIO, BytesIO
from mock import patch, Mock
import time

sys.path.insert(0, "..")
sys.modules["swsssdk"] = Mock()
sys.modules["sonic_py_common"] = Mock()
time.sleep = Mock()
import bgp_neighbor
from bgp_neighbor import *
from unittest import TestCase

py_verrsion = sys.version_info[0]

SAMPLE_SONIC_INSTALLER_LIST = " Current: SONiC-OS-20191130.84 \
                              Next: SONiC-OS-20191130.84 \
                              Available: \
                              SONiC-OS-20191130.84 \
                              SONiC-OS-20220531.01"
SAMPLE_SONIC_INSTALLER_LIST_WITH_EMPTY_LINE = " Current: SONiC-OS-20191130.84 \
                              Next: SONiC-OS-20191130.84 \
                                \n\n\
                              Available: \
                              SONiC-OS-20191130.84 \
                              SONiC-OS-20220531.01"
INVALID_SONIC_INSTALLER_LIST = "Next: SONiC-OS-20191130.84 \
                              Available: \
                              SONiC-OS-20191130.84"
UNSUPPORTED_SONIC_INSTALLER_LIST = " Current: SONiC-OS-20181130.95 \
                              Next: SONiC-OS-20181130.95 \
                              Available: \
                              SONiC-OS-20181130.95"

BGP_SHOW_OUTPUT_TSA = "  neighbor TIER2_V6 route-map TO_TIER2_V6 out\n\
  neighbor TIER2_V4 route-map TO_TIER2_V4 out\n\
  neighbor TIER0_V4 route-map TO_TIER0_V4 out\n\
  neighbor TIER0_V6 route-map TO_TIER0_V6 out\n\
route-map TO_TIER0_V6 deny 30\n\
route-map TO_TIER0_V6 permit 20\n\
route-map TO_TIER2_V6 deny 30\n\
route-map TO_TIER2_V6 permit 20\n\
route-map TO_TIER0_V4 deny 30\n\
route-map TO_TIER0_V4 permit 20\n\
route-map TO_TIER2_V4 deny 30\n\
route-map TO_TIER2_V4 permit 20\
"

BGP_SHOW_OUTPUT_TSA_WITHOUT_RM = "route-map TO_TIER0_V6 deny 30\n\
route-map TO_TIER0_V6 permit 20\n\
route-map TO_TIER2_V6 deny 30\n\
route-map TO_TIER2_V6 permit 20\n\
route-map TO_TIER0_V4 deny 30\n\
route-map TO_TIER0_V4 permit 20\n\
route-map TO_TIER2_V4 deny 30\n\
route-map TO_TIER2_V4 permit 20\
"

BGP_SHOW_OUTPUT_TSA_WITHOUT_POLICY = "  neighbor TIER2_V6 route-map TO_TIER2_V6 out\n\
  neighbor TIER2_V4 route-map TO_TIER2_V4 out\n\
  neighbor TIER0_V4 route-map TO_TIER0_V4 out\n\
  neighbor TIER0_V6 route-map TO_TIER0_V6 out\n\
route-map TO_TIER0_V6 deny 30\n\
route-map TO_TIER0_V6 permit 20\n\
route-map TO_TIER2_V6 deny 30\n\
route-map TO_TIER2_V6 permit 20\
"

BGP_SHOW_OUTPUT_TSB = "  neighbor TIER2_V6 route-map TO_TIER2_V6 out\n\
  neighbor TIER2_V4 route-map TO_TIER2_V4 out\n\
  neighbor TIER0_V4 route-map TO_TIER0_V4 out\n\
  neighbor TIER0_V6 route-map TO_TIER0_V6 out\
"

BGP_SHOW_OUTPUT_TSB_WITH_POLICY = "  neighbor TIER2_V6 route-map TO_TIER2_V6 out\n\
  neighbor TIER2_V4 route-map TO_TIER2_V4 out\n\
  neighbor TIER0_V4 route-map TO_TIER0_V4 out\n\
  neighbor TIER0_V6 route-map TO_TIER0_V6 out\n\
route-map TO_TIER0_V6 deny 30\n\
route-map TO_TIER0_V6 permit 20\n\
route-map TO_TIER2_V6 deny 30\n\
route-map TO_TIER2_V6 permit 20\
"

SONIC_GET_LOOPBACK_IP = "LOOPBACK_INTERFACE|Loopback0|10.1.0.32/32\n\
LOOPBACK_INTERFACE|Loopback0\n\
LOOPBACK_INTERFACE|Loopback0|FC00:1::32/128\
"

bgp_gr_cacls = [
    "iptables {} OUTPUT --protocol tcp --destination-port 179 --tcp-flags FIN FIN -j DROP",
    "iptables {} OUTPUT --protocol tcp --source-port 179 --tcp-flags FIN FIN -j DROP",
    "ip6tables {} OUTPUT --protocol tcp --destination-port 179 --tcp-flags FIN FIN -j DROP",
    "ip6tables {} OUTPUT --protocol tcp --source-port 179 --tcp-flags FIN FIN -j DROP",
]

BGP_SHOW_STATUS = "10.0.0.1       4  65200       4859       1791         0      0       0  00:00:08   Idle (Admin)    ARISTA01T2\n\
10.0.0.5       4  65200       4859       1791         0      0       0  00:00:09   Idle (Admin)    ARISTA03T2\n\
10.0.0.9       4  65200       4859       1748         0      0       0  00:00:09   Idle (Admin)    ARISTA05T2\n\
10.0.0.13      4  65200       4859       1748         0      0       0  00:00:09   Idle (Admin)    ARISTA07T2\n\
"


def mock_config_db_get_entry(key, field):
    return {
        "hwsku": "Force10-S6000",
        "synchronous_mode": "enable",
        "default_bgp_status": "down",
        "type": "LeafRouter",
        "region": "None",
        "hostname": "str-s6000-acs-8",
        "platform": "x86_64-dell_s6000_s1220-r0",
        "mac": "ec:f4:bb:fe:80:84",
        "default_pfcwd_status": "enable",
        "bgp_asn": "65100",
        "buffer_model": "traditional",
        "cloudtype": "None",
        "docker_routing_config_mode": "separated",
        "deployment_id": "1",
    }


def mock_config_db_get_entry_tor(key, field):
    return {
        "hwsku": "Force10-S6000",
        "synchronous_mode": "enable",
        "default_bgp_status": "down",
        "type": "ToRRouter",
        "region": "None",
        "hostname": "str-s6000-acs-8",
        "platform": "x86_64-dell_s6000_s1220-r0",
        "mac": "ec:f4:bb:fe:80:84",
        "default_pfcwd_status": "enable",
        "bgp_asn": "65100",
        "buffer_model": "traditional",
        "cloudtype": "None",
        "docker_routing_config_mode": "separated",
        "deployment_id": "1",
    }


def mock_config_db_get_entry_mgmt_tor(key, field):
    return {
        "hwsku": "Force10-S6000",
        "synchronous_mode": "enable",
        "default_bgp_status": "down",
        "type": "MgmtToRRouter",
        "region": "None",
        "hostname": "str-s6000-acs-8",
        "platform": "x86_64-dell_s6000_s1220-r0",
        "mac": "ec:f4:bb:fe:80:84",
        "default_pfcwd_status": "enable",
        "bgp_asn": "65100",
        "buffer_model": "traditional",
        "cloudtype": "None",
        "docker_routing_config_mode": "separated",
        "deployment_id": "1",
    }

def mock_config_db_get_entry_dual_tor(key, field):
    return {
        "hwsku": "Force10-S6000",
        "synchronous_mode": "enable",
        "default_bgp_status": "down",
        "type": "ToRRouter",
        "subtype": "DualTor",
        "region": "None",
        "hostname": "str-s6000-acs-8",
        "platform": "x86_64-dell_s6000_s1220-r0",
        "mac": "ec:f4:bb:fe:80:84",
        "default_pfcwd_status": "enable",
        "bgp_asn": "65100",
        "buffer_model": "traditional",
        "cloudtype": "None",
        "docker_routing_config_mode": "separated",
        "deployment_id": "1",
    }

def mock_config_db_get_entry_spine_router(key, field):
    return {
        "hwsku": "Force10-S6000",
        "synchronous_mode": "enable",
        "default_bgp_status": "down",
        "type": "SpineRouter",
        "region": "None",
        "hostname": "str-s6000-acs-8",
        "platform": "x86_64-dell_s6000_s1220-r0",
        "mac": "ec:f4:bb:fe:80:84",
        "default_pfcwd_status": "enable",
        "bgp_asn": "65100",
        "buffer_model": "traditional",
        "cloudtype": "None",
        "docker_routing_config_mode": "separated",
        "deployment_id": "1",
    }


def mock_config_db_get_table(table_name):
    if table_name == "BGP_NEIGHBOR":
        return {
            "10.0.0.1": {
                "rrclient": "0",
                "name": "ARISTA01T2",
                "local_addr": "10.0.0.0",
                "nhopself": "0",
                "admin_status": "up",
                "holdtime": "10",
                "asn": "65200",
                "keepalive": "3",
            },
            "10.0.0.5": {
                "rrclient": "0",
                "name": "ARISTA03T2",
                "local_addr": "10.0.0.4",
                "nhopself": "0",
                "admin_status": "up",
                "holdtime": "10",
                "asn": "65200",
                "keepalive": "3",
            },
            "10.0.0.33": {
                "rrclient": "0",
                "name": "ARISTA01T0",
                "local_addr": "10.0.0.32",
                "nhopself": "0",
                "admin_status": "up",
                "holdtime": "10",
                "asn": "64001",
                "keepalive": "3",
            },
            "10.0.0.35": {
                "rrclient": "0",
                "name": "ARISTA02T0",
                "local_addr": "10.0.0.34",
                "nhopself": "0",
                "admin_status": "up",
                "holdtime": "10",
                "asn": "64002",
                "keepalive": "3",
            },
        }

    elif table_name == "DEVICE_NEIGHBOR_METADATA":
        return {
            "ARISTA01T2": {
                "type": "SpineRouter",
                "mgmt_addr": "172.16.131.32",
                "hwsku": "Arista-VM",
                "lo_addr": "None",
            },
            "ARISTA03T2": {
                "type": "SpineRouter",
                "mgmt_addr": "172.16.131.33",
                "hwsku": "Arista-VM",
                "lo_addr": "None",
            },
            "ARISTA01T0": {
                "type": "ToRRouter",
                "mgmt_addr": "172.16.131.40",
                "hwsku": "Arista-VM",
                "lo_addr": "None",
            },
            "ARISTA02T0": {
                "type": "ToRRouter",
                "mgmt_addr": "172.16.131.41",
                "hwsku": "Arista-VM",
                "lo_addr": "None",
            },
        }

def mock_config_db_get_table_spine_router(table_name):
    if table_name == "BGP_NEIGHBOR":
        return {
            "10.0.0.1": {
                "rrclient": "0",
                "name": "ARISTA01T1",
                "local_addr": "10.0.0.0",
                "nhopself": "0",
                "admin_status": "up",
                "holdtime": "10",
                "asn": "65200",
                "keepalive": "3",
            },
            "10.0.0.5": {
                "rrclient": "0",
                "name": "ARISTA03T1",
                "local_addr": "10.0.0.4",
                "nhopself": "0",
                "admin_status": "up",
                "holdtime": "10",
                "asn": "65200",
                "keepalive": "3",
            },
            "10.0.0.33": {
                "rrclient": "0",
                "name": "ARISTA01T3",
                "local_addr": "10.0.0.32",
                "nhopself": "0",
                "admin_status": "up",
                "holdtime": "10",
                "asn": "64001",
                "keepalive": "3",
            },
            "10.0.0.35": {
                "rrclient": "0",
                "name": "ARISTA02T3",
                "local_addr": "10.0.0.34",
                "nhopself": "0",
                "admin_status": "up",
                "holdtime": "10",
                "asn": "64002",
                "keepalive": "3",
            },
        }

    elif table_name == "DEVICE_NEIGHBOR_METADATA":
        return {
            "ARISTA01T1": {
                "type": "LeafRouter",
                "mgmt_addr": "172.16.131.32",
                "hwsku": "Arista-VM",
                "lo_addr": "None",
            },
            "ARISTA03T1": {
                "type": "LeafRouter",
                "mgmt_addr": "172.16.131.33",
                "hwsku": "Arista-VM",
                "lo_addr": "None",
            },
            "ARISTA01T3": {
                "type": "RegionalHub",
                "mgmt_addr": "172.16.131.40",
                "hwsku": "Arista-VM",
                "lo_addr": "None",
            },
            "ARISTA02T3": {
                "type": "RegionalHub",
                "mgmt_addr": "172.16.131.41",
                "hwsku": "Arista-VM",
                "lo_addr": "None",
            },
        }


def mock_config_db_get_table_tor(table_name):
    if table_name == "BGP_NEIGHBOR":
        return {
            "10.0.0.3": {
                "rrclient": "0",
                "name": "ARISTA01T2",
                "local_addr": "10.0.0.0",
                "nhopself": "0",
                "admin_status": "up",
                "holdtime": "10",
                "asn": "65200",
                "keepalive": "3",
            },
            "10.0.0.7": {
                "rrclient": "0",
                "name": "ARISTA03T2",
                "local_addr": "10.0.0.4",
                "nhopself": "0",
                "admin_status": "up",
                "holdtime": "10",
                "asn": "65200",
                "keepalive": "3",
            },
            "10.0.0.37": {
                "rrclient": "0",
                "name": "ARISTA01T0",
                "local_addr": "10.0.0.32",
                "nhopself": "0",
                "admin_status": "up",
                "holdtime": "10",
                "asn": "64001",
                "keepalive": "3",
            },
            "10.0.0.39": {
                "rrclient": "0",
                "name": "ARISTA02T0",
                "local_addr": "10.0.0.34",
                "nhopself": "0",
                "admin_status": "up",
                "holdtime": "10",
                "asn": "64002",
                "keepalive": "3",
            },
        }

    elif table_name == "DEVICE_NEIGHBOR_METADATA":
        return {
            "ARISTA01T1": {
                "type": "LeafRouter",
                "mgmt_addr": "172.16.131.32",
                "hwsku": "Arista-VM",
                "lo_addr": "None",
            },
            "ARISTA02T1": {
                "type": "LeafRouter",
                "mgmt_addr": "172.16.131.33",
                "hwsku": "Arista-VM",
                "lo_addr": "None",
            },
            "ARISTA03T1": {
                "type": "LeafRouter",
                "mgmt_addr": "172.16.131.40",
                "hwsku": "Arista-VM",
                "lo_addr": "None",
            },
            "ARISTA04T1": {
                "type": "LeafRouter",
                "mgmt_addr": "172.16.131.41",
                "hwsku": "Arista-VM",
                "lo_addr": "None",
            },
        }


def mock_config_db_get_table_mgmt_tor(table_name):
    if table_name == "BGP_NEIGHBOR":
        return {
            "10.0.0.11": {
                "rrclient": "0",
                "name": "ARISTA01T2",
                "local_addr": "10.0.0.0",
                "nhopself": "0",
                "admin_status": "up",
                "holdtime": "10",
                "asn": "65200",
                "keepalive": "3",
            },
            "10.0.0.15": {
                "rrclient": "0",
                "name": "ARISTA03T2",
                "local_addr": "10.0.0.4",
                "nhopself": "0",
                "admin_status": "up",
                "holdtime": "10",
                "asn": "65200",
                "keepalive": "3",
            },
            "10.0.0.133": {
                "rrclient": "0",
                "name": "ARISTA01T0",
                "local_addr": "10.0.0.32",
                "nhopself": "0",
                "admin_status": "up",
                "holdtime": "10",
                "asn": "64001",
                "keepalive": "3",
            },
            "10.0.0.135": {
                "rrclient": "0",
                "name": "ARISTA02T0",
                "local_addr": "10.0.0.34",
                "nhopself": "0",
                "admin_status": "up",
                "holdtime": "10",
                "asn": "64002",
                "keepalive": "3",
            },
        }

    elif table_name == "DEVICE_NEIGHBOR_METADATA":
        return {
            "ARISTA01T1": {
                "type": "LeafRouter",
                "mgmt_addr": "172.16.131.32",
                "hwsku": "Arista-VM",
                "lo_addr": "None",
            },
            "ARISTA02T1": {
                "type": "LeafRouter",
                "mgmt_addr": "172.16.131.33",
                "hwsku": "Arista-VM",
                "lo_addr": "None",
            },
            "ARISTA03T1": {
                "type": "LeafRouter",
                "mgmt_addr": "172.16.131.40",
                "hwsku": "Arista-VM",
                "lo_addr": "None",
            },
            "ARISTA04T1": {
                "type": "LeafRouter",
                "mgmt_addr": "172.16.131.41",
                "hwsku": "Arista-VM",
                "lo_addr": "None",
            },
        }


def mock_get_admin_status(table_name, dryrun, logcmd=True, timeout_sec=30):
    if table_name == "show ip bgp sum | grep Admin":
        return 0, BGP_SHOW_STATUS, ""

    elif table_name == "show ipv6 bgp sum | grep Admin":
        return 0, "", ""


class TestBase(unittest.TestCase):
    def checkCmd(self, success, testargs, sysExit=True, uid=0):
        with patch("sys.stdout", new=BytesIO()) as stdOutput:
            testargs = ["./bgp_neighbor"] + testargs
            with patch.object(sys, "argv", testargs):
                with patch.object(os, "geteuid", return_value=uid):
                    if sysExit:
                        with self.assertRaises(SystemExit) as cm:
                            bgp_neighbor.main()
                        if success:
                            self.assertTrue(cm.exception.code == 0)
                        else:
                            self.assertTrue(cm.exception.code != 0)
                    else:
                        bgp_neighbor.main()

        return stdOutput.getvalue().strip()

    def checkPass(self, testargs):
        return self.checkCmd(True, testargs, sysExit=True)

    def checkFail(self, testargs):
        return self.checkCmd(False, testargs, sysExit=True)

    def checkReturn(self, testargs, userID=0):
        return self.checkCmd(True, testargs, sysExit=False, uid=userID)


class DBConnectorTest(TestCase):
    def setUp(self):
        bgp_neighbor.ConfigDBConnector().get_entry = mock_config_db_get_entry
        bgp_neighbor.ConfigDBConnector().get_table = mock_config_db_get_table
        bgp_neighbor.multi_asic.connect_config_db_for_ns().get_entry = mock_config_db_get_entry
        bgp_neighbor.multi_asic.connect_config_db_for_ns().get_table = mock_config_db_get_table

    @patch.object(bgp_neighbor.multi_asic, "is_multi_asic")
    def test_get_topo_type(self, mock_is_multi_asic):
        mock_is_multi_asic.return_value = False
        ver = ["20191130", "70"]
        dbc = DBConnector(ver)
        self.assertTrue(dbc.get_topo_type() == "leafrouter")

    @patch.object(bgp_neighbor.multi_asic, "is_multi_asic", return_value=True)
    @patch.object(
        bgp_neighbor.multi_asic,
        "get_all_namespaces",
        return_value={"front_ns": ["asic0", "asic1"], "back_ns": "asic2"},
    )
    def test_get_topo_type_masic(self, mock_is_multi_asic, mock_get_all_namespaces):
        ver = ["20191130", "70"]
        dbc = DBConnector(ver)
        self.assertTrue(dbc.get_topo_type() == "leafrouter")

    @patch.object(bgp_neighbor.multi_asic, "is_multi_asic", return_value=True)
    @patch.object(
        bgp_neighbor.multi_asic,
        "get_all_namespaces",
        return_value={"front_ns": ["asic0", "asic1"], "back_ns": "asic2"},
    )
    def test_get_dbc_masic(self, mock_is_multi_asic, mock_get_all_namespaces):
        ver = ["20191130", "70"]
        dbc = DBConnector(ver)
        self.assertTrue(len(dbc.get_connector()) == 2)

    @patch.object(bgp_neighbor.multi_asic, "is_multi_asic", return_value=False)
    def test_get_dbc(self, mock_is_multi_asic):
        ver = ["20191130", "70"]
        dbc = DBConnector(ver)
        self.assertTrue(len(dbc.get_connector()) == 1)


class CaclTest(TestCase):
    @patch.object(
        bgp_neighbor, "exec_cmd", return_value=[bgp_neighbor.RET_SUCCESS, "", ""]
    )
    def test_cacl_install(self, mock_exec_cmd):
        gr_cacl = cacl(cacl_rules=bgp_gr_cacls)
        gr_cacl.install()
        self.assertTrue(gr_cacl.installed_rules == bgp_gr_cacls)

    @patch.object(
        bgp_neighbor, "exec_cmd", return_value=[bgp_neighbor.RET_FAILED, "", ""]
    )
    def test_cacl_install_exception(self, mock_exec_cmd):
        gr_cacl = cacl(cacl_rules=bgp_gr_cacls)
        with self.assertRaises(Exception):
            gr_cacl.install()

    @patch.object(
        bgp_neighbor, "exec_cmd", return_value=[bgp_neighbor.RET_SUCCESS, "", ""]
    )
    def test_cacl_uninstall(self, mock_exec_cmd):
        gr_cacl = cacl(cacl_rules=bgp_gr_cacls)
        gr_cacl.install()
        gr_cacl.uninstall()

    @patch.object(
        bgp_neighbor, "exec_cmd", return_value=[bgp_neighbor.RET_SUCCESS, "", ""]
    )
    def test_cacl_uninstall_exception(self, mock_exec_cmd):
        gr_cacl = cacl(cacl_rules=bgp_gr_cacls)
        gr_cacl.install()
        bgp_neighbor.exec_cmd = bgp_neighbor.RET_FAILED
        with self.assertRaises(Exception):
            gr_cacl.uninstall()


class TrafficMgrTest(TestCase):
    def setUp(self):
        bgp_neighbor.ConfigDBConnector().get_entry = mock_config_db_get_entry
        bgp_neighbor.ConfigDBConnector().get_table = mock_config_db_get_table

    @patch.object(bgp_neighbor.multi_asic, "is_multi_asic", return_value=True)
    @patch.object(
        bgp_neighbor.multi_asic,
        "get_all_namespaces",
        return_value={"front_ns": ["asic0", "asic1"], "back_ns": "asic2"},
    )
    def test_tsm(self, mock_is_multi_asic, mock_get_all_namespaces):
        ver = ["20191130", "70"]
        dbc = DBConnector(ver)
        traffic_mgr = TrafficMgr(
            bgp_neighbor.BGP_SHUT,
            bgp_neighbor.TS_RM,
            bgp_neighbor.BGP_DOWNUP_NEIGHBORS_STARTUP_DELAY,
            bgp_neighbor.ALL_NEIGHBORS,
            ver,
            dbc.get_connector(),
        )

    @patch.object(bgp_neighbor.multi_asic, "is_multi_asic", return_value=True)
    @patch.object(
        bgp_neighbor.multi_asic,
        "get_all_namespaces",
        return_value={"front_ns": ["asic0", "asic1"], "back_ns": "asic2"},
    )
    def test_get_topo(self, mock_is_multi_asic, mock_get_all_namespaces):
        ver = ["20191130", "70"]
        dbc = DBConnector(ver)
        traffic_mgr = TrafficMgr(
            bgp_neighbor.BGP_SHUT,
            bgp_neighbor.TS_RM,
            bgp_neighbor.BGP_DOWNUP_NEIGHBORS_STARTUP_DELAY,
            bgp_neighbor.ALL_NEIGHBORS,
            ver,
            dbc.get_connector(),
        )
        self.assertTrue(traffic_mgr.get_topo_type() == "leafrouter")

    @patch.object(bgp_neighbor.multi_asic, "is_multi_asic", return_value=True)
    @patch.object(
        bgp_neighbor.multi_asic,
        "get_all_namespaces",
        return_value={"front_ns": ["asic0", "asic1"], "back_ns": "asic2"},
    )
    @patch.object(bgp_neighbor, "wait_until", return_value=False)
    @patch.object(
        bgp_neighbor, "exec_cmd", return_value=[bgp_neighbor.RET_SUCCESS, "", ""]
    )
    def test_traffic_shift_rm_by_cmd(
        self,
        mock_is_multi_asic,
        mock_get_all_namespaces,
        mock_wait_until,
        mock_exec_cmd,
    ):
        ver = ["20191130", "70"]
        dbc = DBConnector(ver)
        traffic_mgr = TrafficMgr(
            bgp_neighbor.BGP_SHUT,
            bgp_neighbor.TS_RM,
            bgp_neighbor.BGP_DOWNUP_NEIGHBORS_STARTUP_DELAY,
            bgp_neighbor.ALL_NEIGHBORS,
            ver,
            dbc.get_connector(),
        )
        with self.assertRaises(Exception):
            traffic_mgr.traffic_shift_rm_by_cmd("TSA")

    @patch.object(bgp_neighbor.multi_asic, "is_multi_asic", return_value=False)
    def test_wait_for_traffic_state_update(
        self,
        mock_is_multi_asic,
    ):
        ver = ["20191130", "70"]
        dbc = DBConnector(ver)
        traffic_mgr = TrafficMgr(
            bgp_neighbor.BGP_SHUT,
            bgp_neighbor.TS_RM,
            bgp_neighbor.BGP_DOWNUP_NEIGHBORS_STARTUP_DELAY,
            bgp_neighbor.ALL_NEIGHBORS,
            ver,
            dbc.get_connector(),
        )
        with patch(
            "bgp_neighbor.exec_cmd",
            return_value=[bgp_neighbor.RET_SUCCESS, "Maintenance", ""],
        ):
            self.assertTrue(traffic_mgr.wait_for_traffic_state_update("TSA"))

        with patch(
            "bgp_neighbor.exec_cmd",
            return_value=[bgp_neighbor.RET_SUCCESS, "Normal", ""],
        ):
            self.assertTrue(traffic_mgr.wait_for_traffic_state_update("TSB"))

        with patch(
            "bgp_neighbor.exec_cmd",
            return_value=[bgp_neighbor.RET_FAILED, "Normal", ""],
        ):
            self.assertFalse(traffic_mgr.wait_for_traffic_state_update("TSA"))

    @patch.object(bgp_neighbor.multi_asic, "is_multi_asic", return_value=False)
    @patch.object(
        bgp_neighbor, "exec_cmd", return_value=[bgp_neighbor.RET_SUCCESS, "", ""]
    )
    def test_bgp_oper(
        self,
        mock_exec_cmd,
        mock_is_multi_asic,
    ):
        ver = ["20191130", "70"]
        dbc = DBConnector(ver)
        traffic_mgr = TrafficMgr(
            bgp_neighbor.BGP_SHUT,
            bgp_neighbor.TS_RM,
            bgp_neighbor.BGP_DOWNUP_NEIGHBORS_STARTUP_DELAY,
            bgp_neighbor.ALL_NEIGHBORS,
            ver,
            dbc.get_connector(),
        )
        traffic_mgr.bgp_oper()

    @patch.object(bgp_neighbor.multi_asic, "is_multi_asic", return_value=False)
    @patch.object(
        bgp_neighbor, "exec_cmd", return_value=[bgp_neighbor.RET_SUCCESS, "", ""]
    )
    def test_bgp_oper_one_nei(
        self,
        mock_exec_cmd,
        mock_is_multi_asic,
    ):
        ver = ["20191130", "70"]
        dbc = DBConnector(ver)
        traffic_mgr = TrafficMgr(
            bgp_neighbor.BGP_SHUT,
            bgp_neighbor.TS_RM,
            bgp_neighbor.BGP_DOWNUP_NEIGHBORS_STARTUP_DELAY,
            "10.0.0.1",
            ver,
            dbc.get_connector(),
        )
        traffic_mgr.bgp_oper()

    @patch.object(bgp_neighbor.multi_asic, "is_multi_asic", return_value=False)
    @patch.object(TrafficMgr, "traffic_shift_rm", return_value=bgp_neighbor.RET_SUCCESS)
    @patch.object(TrafficMgr, "bgp_oper", return_value=bgp_neighbor.RET_SUCCESS)
    def test_traffic_shift_away(
        self, mock_traffic_shift_rm, mock_is_multi_asic, mock_bgp_oper
    ):
        ver = ["20191130", "70"]
        dbc = DBConnector(ver)
        traffic_mgr = TrafficMgr(
            bgp_neighbor.BGP_SHUT,
            bgp_neighbor.TS_RM,
            bgp_neighbor.BGP_DOWNUP_NEIGHBORS_STARTUP_DELAY,
            bgp_neighbor.ALL_NEIGHBORS,
            ver,
            dbc.get_connector(),
        )
        ret = traffic_mgr.traffic_shift_away()
        self.assertTrue(ret == bgp_neighbor.RET_SUCCESS)

    @patch.object(bgp_neighbor.multi_asic, "is_multi_asic", return_value=False)
    @patch.object(
        bgp_neighbor, "exec_cmd", return_value=[bgp_neighbor.RET_FAILED, "", ""]
    )
    def test_traffic_shift_away_failure(
        self, mock_traffic_shift_rm, mock_is_multi_asic
    ):
        ver = ["20191130", "70"]
        dbc = DBConnector(ver)
        traffic_mgr = TrafficMgr(
            bgp_neighbor.BGP_SHUT,
            bgp_neighbor.TS_RM,
            bgp_neighbor.BGP_DOWNUP_NEIGHBORS_STARTUP_DELAY,
            bgp_neighbor.ALL_NEIGHBORS,
            ver,
            dbc.get_connector(),
        )
        ret = traffic_mgr.traffic_shift_away()
        self.assertTrue(ret != bgp_neighbor.RET_SUCCESS)

    @patch.object(bgp_neighbor.multi_asic, "is_multi_asic", return_value=False)
    @patch.object(TrafficMgr, "traffic_shift_rm", return_value=bgp_neighbor.RET_SUCCESS)
    @patch.object(TrafficMgr, "bgp_oper", return_value=bgp_neighbor.RET_SUCCESS)
    def test_traffic_shift_away_by_bgpshut(
        self, mock_traffic_shift_rm, mock_is_multi_asic, mock_bgp_oper
    ):
        ver = ["20191130", "70"]
        dbc = DBConnector(ver)
        traffic_mgr = TrafficMgr(
            bgp_neighbor.BGP_SHUT,
            bgp_neighbor.TS_BGPSHUT,
            bgp_neighbor.BGP_DOWNUP_NEIGHBORS_STARTUP_DELAY,
            bgp_neighbor.ALL_NEIGHBORS,
            ver,
            dbc.get_connector(),
        )
        ret = traffic_mgr.traffic_shift_away()
        self.assertTrue(ret == bgp_neighbor.RET_SUCCESS)
        
    @patch.object(bgp_neighbor.multi_asic, "is_multi_asic", return_value=False)
    @patch.object(TrafficMgr, "traffic_shift_rm", return_value=bgp_neighbor.RET_SUCCESS)
    @patch.object(TrafficMgr, "bgp_oper", return_value=bgp_neighbor.RET_SUCCESS)
    def test_traffic_shift_away_hard(
        self, mock_traffic_shift_rm, mock_is_multi_asic, mock_bgp_oper
    ):
        ver = ["20191130", "70"]
        dbc = DBConnector(ver)
        traffic_mgr = TrafficMgr(
            bgp_neighbor.BGP_SHUT,
            bgp_neighbor.TS_BGPSHUT,
            bgp_neighbor.BGP_DOWNUP_NEIGHBORS_STARTUP_DELAY,
            bgp_neighbor.ALL_NEIGHBORS,
            ver,
            dbc.get_connector(),
            True,
        )
        ret = traffic_mgr.traffic_shift_away()
        self.assertTrue(ret == bgp_neighbor.RET_SUCCESS)

    @patch.object(bgp_neighbor.multi_asic, "is_multi_asic", return_value=False)
    @patch.object(TrafficMgr, "traffic_shift_rm", return_value=bgp_neighbor.RET_SUCCESS)
    @patch.object(TrafficMgr, "bgp_oper", return_value=bgp_neighbor.RET_SUCCESS)
    def test_traffic_shift_restore(
        self, mock_traffic_shift_rm, mock_is_multi_asic, mock_bgp_oper
    ):
        ver = ["20191130", "70"]
        dbc = DBConnector(ver)
        traffic_mgr = TrafficMgr(
            bgp_neighbor.BGP_SHUT,
            bgp_neighbor.TS_RM,
            bgp_neighbor.BGP_DOWNUP_NEIGHBORS_STARTUP_DELAY,
            bgp_neighbor.ALL_NEIGHBORS,
            ver,
            dbc.get_connector(),
        )
        ret = traffic_mgr.traffic_shift_restore()
        self.assertTrue(ret == bgp_neighbor.RET_SUCCESS)

    @patch.object(bgp_neighbor.multi_asic, "is_multi_asic", return_value=False)
    @patch.object(TrafficMgr, "traffic_shift_rm", return_value=bgp_neighbor.RET_SUCCESS)
    def test_traffic_shift_restore_failure(
        self, mock_traffic_shift_rm, mock_is_multi_asic
    ):
        ver = ["20191130", "70"]
        dbc = DBConnector(ver)
        traffic_mgr = TrafficMgr(
            bgp_neighbor.BGP_SHUT,
            bgp_neighbor.TS_RM,
            bgp_neighbor.BGP_DOWNUP_NEIGHBORS_STARTUP_DELAY,
            bgp_neighbor.ALL_NEIGHBORS,
            ver,
            dbc.get_connector(),
        )
        with patch(
            "bgp_neighbor.exec_cmd", return_value=[bgp_neighbor.RET_FAILED, "", ""]
        ):
            ret = traffic_mgr.traffic_shift_restore()
            self.assertTrue(ret != bgp_neighbor.RET_SUCCESS)

    @patch.object(bgp_neighbor.multi_asic, "is_multi_asic", return_value=False)
    @patch.object(TrafficMgr, "traffic_shift_rm", return_value=bgp_neighbor.RET_SUCCESS)
    @patch.object(TrafficMgr, "bgp_oper", return_value=bgp_neighbor.RET_SUCCESS)
    def test_traffic_shift_restore_hard(
        self, mock_traffic_shift_rm, mock_is_multi_asic, mock_bgp_oper
    ):
        ver = ["20191130", "70"]
        dbc = DBConnector(ver)
        traffic_mgr = TrafficMgr(
            bgp_neighbor.BGP_SHUT,
            bgp_neighbor.TS_BGPSHUT,
            bgp_neighbor.BGP_DOWNUP_NEIGHBORS_STARTUP_DELAY,
            bgp_neighbor.ALL_NEIGHBORS,
            ver,
            dbc.get_connector(),
            True,
        )
        ret = traffic_mgr.traffic_shift_restore()
        self.assertTrue(ret == bgp_neighbor.RET_SUCCESS)


class TorTrafficMgrTest(TestCase):
    def setUp(self):
        bgp_neighbor.ConfigDBConnector().get_entry = mock_config_db_get_entry_tor
        bgp_neighbor.ConfigDBConnector().get_table = mock_config_db_get_table_tor

    @patch.object(bgp_neighbor.multi_asic, "is_multi_asic", return_value=False)
    @patch.object(TrafficMgr, "bgp_oper", return_value=bgp_neighbor.RET_SUCCESS)
    @patch.object(
        bgp_neighbor, "exec_cmd", return_value=[bgp_neighbor.RET_SUCCESS, "", ""]
    )
    def test_traffic_shift_away(self, mock_is_multi_asic, mock_bgp_oper, mock_exec_cmd):
        ver = ["20191130", "70"]
        dbc = DBConnector(ver)
        traffic_mgr = TorTrafficMgr(
            bgp_neighbor.BGP_SHUT,
            bgp_neighbor.TS_RM,
            bgp_neighbor.BGP_DOWNUP_NEIGHBORS_STARTUP_DELAY,
            bgp_neighbor.ALL_NEIGHBORS,
            ver,
            dbc.get_connector(),
        )
        ret = traffic_mgr.traffic_shift_away()
        self.assertTrue(ret == bgp_neighbor.RET_SUCCESS)

    @patch.object(bgp_neighbor.multi_asic, "is_multi_asic", return_value=False)
    @patch.object(
        bgp_neighbor, "exec_cmd", return_value=[bgp_neighbor.RET_FAILED, "", ""]
    )
    def test_traffic_shift_away_failure(self, mock_exec_cmd, mock_is_multi_asic):
        ver = ["20191130", "70"]
        dbc = DBConnector(ver)
        traffic_mgr = TorTrafficMgr(
            bgp_neighbor.BGP_SHUT,
            bgp_neighbor.TS_BGPSHUT,
            bgp_neighbor.BGP_DOWNUP_NEIGHBORS_STARTUP_DELAY,
            bgp_neighbor.ALL_NEIGHBORS,
            ver,
            dbc.get_connector(),
        )
        ret = traffic_mgr.traffic_shift_away()
        self.assertTrue(ret != bgp_neighbor.RET_SUCCESS)

    @patch.object(bgp_neighbor.multi_asic, "is_multi_asic", return_value=False)
    @patch.object(TrafficMgr, "bgp_oper", return_value=bgp_neighbor.RET_SUCCESS)
    def test_traffic_shift_restore(self, mock_is_multi_asic, mock_bgp_oper):
        ver = ["20191130", "70"]
        dbc = DBConnector(ver)
        traffic_mgr = TorTrafficMgr(
            bgp_neighbor.BGP_SHUT,
            bgp_neighbor.TS_RM,
            bgp_neighbor.BGP_DOWNUP_NEIGHBORS_STARTUP_DELAY,
            bgp_neighbor.ALL_NEIGHBORS,
            ver,
            dbc.get_connector(),
        )
        ret = traffic_mgr.traffic_shift_restore()
        self.assertTrue(ret == bgp_neighbor.RET_SUCCESS)

    @patch.object(bgp_neighbor.multi_asic, "is_multi_asic", return_value=False)
    @patch.object(
        bgp_neighbor, "exec_cmd", return_value=[bgp_neighbor.RET_FAILED, "", ""]
    )
    def test_traffic_shift_restore_failure(self, mock_exec_cmd, mock_is_multi_asic):
        ver = ["20191130", "70"]
        dbc = DBConnector(ver)
        traffic_mgr = TorTrafficMgr(
            bgp_neighbor.BGP_SHUT,
            bgp_neighbor.TS_RM,
            bgp_neighbor.BGP_DOWNUP_NEIGHBORS_STARTUP_DELAY,
            bgp_neighbor.ALL_NEIGHBORS,
            ver,
            dbc.get_connector(),
        )
        ret = traffic_mgr.traffic_shift_restore()
        self.assertTrue(ret != bgp_neighbor.RET_SUCCESS)

class DualTorTrafficMgrTest(TestCase):
    def setUp(self):
        bgp_neighbor.ConfigDBConnector().get_entry = mock_config_db_get_entry_tor
        bgp_neighbor.ConfigDBConnector().get_table = mock_config_db_get_table_tor

    @patch.object(bgp_neighbor.multi_asic, "is_multi_asic", return_value=False)
    @patch.object(TrafficMgr, "traffic_shift_rm", return_value=bgp_neighbor.RET_SUCCESS)
    @patch.object(TrafficMgr, "bgp_oper", return_value=bgp_neighbor.RET_SUCCESS)
    def test_traffic_shift_away(
        self, mock_traffic_shift_rm, mock_is_multi_asic, mock_bgp_oper
    ):
        ver = ["20191130", "70"]
        dbc = DBConnector(ver)
        traffic_mgr = DualTorTrafficMgr(
            bgp_neighbor.BGP_SHUT,
            bgp_neighbor.TS_RM,
            bgp_neighbor.BGP_DOWNUP_NEIGHBORS_STARTUP_DELAY,
            bgp_neighbor.ALL_NEIGHBORS,
            ver,
            dbc.get_connector(),
        )
        ret = traffic_mgr.traffic_shift_away()
        self.assertTrue(ret == bgp_neighbor.RET_SUCCESS)

    @patch.object(bgp_neighbor.multi_asic, "is_multi_asic", return_value=False)
    @patch.object(
        bgp_neighbor, "exec_cmd", return_value=[bgp_neighbor.RET_FAILED, "", ""]
    )
    def test_traffic_shift_away_failure(
        self, mock_traffic_shift_rm, mock_is_multi_asic
    ):
        ver = ["20191130", "70"]
        dbc = DBConnector(ver)
        traffic_mgr = DualTorTrafficMgr(
            bgp_neighbor.BGP_SHUT,
            bgp_neighbor.TS_RM,
            bgp_neighbor.BGP_DOWNUP_NEIGHBORS_STARTUP_DELAY,
            bgp_neighbor.ALL_NEIGHBORS,
            ver,
            dbc.get_connector(),
        )
        ret = traffic_mgr.traffic_shift_away()
        self.assertTrue(ret != bgp_neighbor.RET_SUCCESS)

    @patch.object(bgp_neighbor.multi_asic, "is_multi_asic", return_value=False)
    @patch.object(TrafficMgr, "traffic_shift_rm", return_value=bgp_neighbor.RET_SUCCESS)
    @patch.object(TrafficMgr, "bgp_oper", return_value=bgp_neighbor.RET_SUCCESS)
    def test_traffic_shift_away_by_bgpshut(
        self, mock_traffic_shift_rm, mock_is_multi_asic, mock_bgp_oper
    ):
        ver = ["20191130", "70"]
        dbc = DBConnector(ver)
        traffic_mgr = DualTorTrafficMgr(
            bgp_neighbor.BGP_SHUT,
            bgp_neighbor.TS_BGPSHUT,
            bgp_neighbor.BGP_DOWNUP_NEIGHBORS_STARTUP_DELAY,
            bgp_neighbor.ALL_NEIGHBORS,
            ver,
            dbc.get_connector(),
        )
        ret = traffic_mgr.traffic_shift_away()
        self.assertTrue(ret == bgp_neighbor.RET_SUCCESS)

    @patch.object(bgp_neighbor.multi_asic, "is_multi_asic", return_value=False)
    @patch.object(TrafficMgr, "traffic_shift_rm", return_value=bgp_neighbor.RET_SUCCESS)
    @patch.object(TrafficMgr, "bgp_oper", return_value=bgp_neighbor.RET_SUCCESS)
    def test_traffic_shift_restore(
        self, mock_traffic_shift_rm, mock_is_multi_asic, mock_bgp_oper
    ):
        ver = ["20191130", "70"]
        dbc = DBConnector(ver)
        traffic_mgr = DualTorTrafficMgr(
            bgp_neighbor.BGP_SHUT,
            bgp_neighbor.TS_RM,
            bgp_neighbor.BGP_DOWNUP_NEIGHBORS_STARTUP_DELAY,
            bgp_neighbor.ALL_NEIGHBORS,
            ver,
            dbc.get_connector(),
        )
        ret = traffic_mgr.traffic_shift_restore()
        self.assertTrue(ret == bgp_neighbor.RET_SUCCESS)

    @patch.object(bgp_neighbor.multi_asic, "is_multi_asic", return_value=False)
    @patch.object(TrafficMgr, "traffic_shift_rm", return_value=bgp_neighbor.RET_SUCCESS)
    def test_traffic_shift_restore_failure(
        self, mock_traffic_shift_rm, mock_is_multi_asic
    ):
        ver = ["20191130", "70"]
        dbc = DBConnector(ver)
        traffic_mgr = DualTorTrafficMgr(
            bgp_neighbor.BGP_SHUT,
            bgp_neighbor.TS_BGPSHUT,
            bgp_neighbor.BGP_DOWNUP_NEIGHBORS_STARTUP_DELAY,
            bgp_neighbor.ALL_NEIGHBORS,
            ver,
            dbc.get_connector(),
        )
        with patch(
            "bgp_neighbor.exec_cmd", return_value=[bgp_neighbor.RET_FAILED, "", ""]
        ):
            ret = traffic_mgr.traffic_shift_restore()
            self.assertTrue(ret != bgp_neighbor.RET_SUCCESS)

    @patch.object(bgp_neighbor.multi_asic, "is_multi_asic", return_value=False)
    @patch.object(TrafficMgr, "traffic_shift_rm", return_value=bgp_neighbor.RET_SUCCESS)
    @patch.object(TrafficMgr, "bgp_oper", return_value=bgp_neighbor.RET_SUCCESS)
    def test_traffic_shift_restore_by_bgpshut(
        self, mock_traffic_shift_rm, mock_is_multi_asic, mock_bgp_oper
    ):
        ver = ["20191130", "70"]
        dbc = DBConnector(ver)
        traffic_mgr = DualTorTrafficMgr(
            bgp_neighbor.BGP_SHUT,
            bgp_neighbor.TS_BGPSHUT,
            bgp_neighbor.BGP_DOWNUP_NEIGHBORS_STARTUP_DELAY,
            bgp_neighbor.ALL_NEIGHBORS,
            ver,
            dbc.get_connector(),
        )
        ret = traffic_mgr.traffic_shift_restore()
        self.assertTrue(ret == bgp_neighbor.RET_SUCCESS)

class TorAboveTrafficMgrTest(TestCase):
    def setUp(self):
        bgp_neighbor.ConfigDBConnector().get_entry = mock_config_db_get_entry
        bgp_neighbor.ConfigDBConnector().get_table = mock_config_db_get_table

    @patch.object(bgp_neighbor.multi_asic, "is_multi_asic", return_value=False)
    def test_get_bgp_neighbors(self, mock_is_multi_asic):
        ver = ["20191130", "70"]
        dbc = DBConnector(ver)
        traffic_mgr = TorAboveTrafficMgr(
            bgp_neighbor.BGP_SHUT,
            bgp_neighbor.TS_RM,
            bgp_neighbor.BGP_DOWNUP_NEIGHBORS_STARTUP_DELAY,
            bgp_neighbor.ALL_NEIGHBORS,
            ver,
            dbc.get_connector(),
            "leafrouter"
        )
        self.assertTrue(traffic_mgr.neighbor_num == 4)

    @patch.object(bgp_neighbor.multi_asic, "is_multi_asic", return_value=True)
    @patch.object(
        bgp_neighbor.multi_asic,
        "get_all_namespaces",
        return_value={"front_ns": ["asic0", "asic1"], "back_ns": "asic2"},
    )
    @patch.object(bgp_neighbor, "wait_until", return_value=False)
    @patch.object(
        bgp_neighbor, "exec_cmd", return_value=[bgp_neighbor.RET_SUCCESS, "", ""]
    )
    def test_traffic_shift_rm(
        self,
        mock_is_multi_asic,
        mock_get_all_namespaces,
        mock_wait_until,
        mock_exec_cmd,
    ):
        ver = ["20171130", "70"]
        dbc = DBConnector(ver)
        traffic_mgr = TorAboveTrafficMgr(
            bgp_neighbor.BGP_SHUT,
            bgp_neighbor.TS_RM,
            bgp_neighbor.BGP_DOWNUP_NEIGHBORS_STARTUP_DELAY,
            bgp_neighbor.ALL_NEIGHBORS,
            ver,
            dbc.get_connector(),
            "leafrouter"
        )
        with self.assertRaises(Exception):
            traffic_mgr.traffic_shift_rm("TSA")

    @patch.object(bgp_neighbor.multi_asic, "is_multi_asic", return_value=True)
    @patch.object(
        bgp_neighbor.multi_asic,
        "get_all_namespaces",
        return_value={"front_ns": ["asic0", "asic1"], "back_ns": "asic2"},
    )
    @patch.object(
        bgp_neighbor,
        "exec_cmd",
        return_value=[bgp_neighbor.RET_SUCCESS, SONIC_GET_LOOPBACK_IP, ""],
    )
    @patch.object(bgp_neighbor, "run_cmds", return_value=bgp_neighbor.RET_SUCCESS)
    def test_traffic_shift_rm_by_quagga(
        self, mock_is_multi_asic, mock_get_all_namespaces, mock_exec_cmd, mock_run_cm
    ):
        ver = ["20181130", "70"]
        dbc = DBConnector(ver)
        traffic_mgr = TorAboveTrafficMgr(
            bgp_neighbor.BGP_SHUT,
            bgp_neighbor.TS_RM,
            bgp_neighbor.BGP_DOWNUP_NEIGHBORS_STARTUP_DELAY,
            bgp_neighbor.ALL_NEIGHBORS,
            ver,
            dbc.get_connector(),
            "leafrouter"
        )
        traffic_mgr.traffic_shift_rm_by_quagga("TSA")

    @patch.object(bgp_neighbor.multi_asic, "is_multi_asic", return_value=False)
    @patch.object(
        bgp_neighbor, "exec_cmd", return_value=[bgp_neighbor.RET_SUCCESS, "", ""]
    )
    def test_check_for_admin_down(self, mock_is_multi_asic, mock_exec_cmd):
        ver = ["20191130", "70"]
        dbc = DBConnector(ver)
        traffic_mgr = TorAboveTrafficMgr(
            bgp_neighbor.BGP_SHUT,
            bgp_neighbor.TS_RM,
            bgp_neighbor.BGP_DOWNUP_NEIGHBORS_STARTUP_DELAY,
            bgp_neighbor.ALL_NEIGHBORS,
            ver,
            dbc.get_connector(),
            "leafrouter"
        )
        bgp_neighbor.exec_cmd = mock_get_admin_status
        self.assertTrue(traffic_mgr.check_for_admin())

        traffic_mgr.dryrun = True
        self.assertTrue(traffic_mgr.check_for_admin())

    def check_exception(self):
        assert False

    @patch.object(bgp_neighbor.multi_asic, "is_multi_asic", return_value=False)
    @patch.object(
        bgp_neighbor, "exec_cmd", return_value=[bgp_neighbor.RET_SUCCESS, "", ""]
    )
    @patch.object(bgp_neighbor, "wait_until", return_value=False)
    @patch.object(
        TorAboveTrafficMgr, "bgp_oper_ordered", return_value=bgp_neighbor.RET_SUCCESS
    )
    def test_bgp_oper(
        self, mock_exec_cmd, mock_is_multi_asic, mock_wait_until, mock_bgp_oper_ordered
    ):
        ver = ["20191130", "70"]
        dbc = DBConnector(ver)
        traffic_mgr = TorAboveTrafficMgr(
            bgp_neighbor.BGP_SHUT,
            bgp_neighbor.TS_RM,
            bgp_neighbor.BGP_DOWNUP_NEIGHBORS_STARTUP_DELAY,
            bgp_neighbor.ALL_NEIGHBORS,
            ver,
            dbc.get_connector(),
            "leafrouter"
        )
        traffic_mgr.bgp_oper()

        TorAboveTrafficMgr.bgp_oper_ordered = self.check_exception
        with self.assertRaises(Exception):
            traffic_mgr.bgp_oper()

    @patch.object(bgp_neighbor.multi_asic, "is_multi_asic", return_value=False)
    @patch.object(
        bgp_neighbor, "exec_cmd", return_value=[bgp_neighbor.RET_SUCCESS, "", ""]
    )
    def test_check_for_admin_up(self, mock_is_multi_asic, mock_exec_cmd):
        ver = ["20191130", "70"]
        dbc = DBConnector(ver)
        traffic_mgr = TorAboveTrafficMgr(
            bgp_neighbor.BGP_UNSHUT,
            bgp_neighbor.TS_RM,
            bgp_neighbor.BGP_DOWNUP_NEIGHBORS_STARTUP_DELAY,
            bgp_neighbor.ALL_NEIGHBORS,
            ver,
            dbc.get_connector(),
            "leafrouter"
        )
        self.assertTrue(traffic_mgr.check_for_admin())

    @patch.object(bgp_neighbor.multi_asic, "is_multi_asic", return_value=False)
    @patch.object(
        bgp_neighbor, "exec_cmd", return_value=[bgp_neighbor.RET_SUCCESS, "", ""]
    )
    @patch.object(bgp_neighbor, "wait_until", return_value=True)
    def test_traffic_shift_away(
        self, mock_is_multi_asic, mock_exec_cmd, mock_wait_until
    ):
        ver = ["20191130", "70"]
        dbc = DBConnector(ver)
        traffic_mgr = TorAboveTrafficMgr(
            bgp_neighbor.BGP_SHUT,
            bgp_neighbor.TS_RM,
            bgp_neighbor.BGP_DOWNUP_NEIGHBORS_STARTUP_DELAY,
            bgp_neighbor.ALL_NEIGHBORS,
            ver,
            dbc.get_connector(),
            "leafrouter"
        )
        ret = traffic_mgr.traffic_shift_away()
        self.assertTrue(ret == bgp_neighbor.RET_SUCCESS)

    @patch.object(bgp_neighbor.multi_asic, "is_multi_asic", return_value=False)
    @patch.object(
        bgp_neighbor, "exec_cmd", return_value=[bgp_neighbor.RET_SUCCESS, "", ""]
    )
    def test_traffic_shift_away_exception(self, mock_is_multi_asic, mock_exec_cmd):
        ver = ["20171130", "70"]
        dbc = DBConnector(ver)
        traffic_mgr = TorAboveTrafficMgr(
            bgp_neighbor.BGP_SHUT,
            bgp_neighbor.TS_RM,
            bgp_neighbor.BGP_DOWNUP_NEIGHBORS_STARTUP_DELAY,
            bgp_neighbor.ALL_NEIGHBORS,
            ver,
            dbc.get_connector(),
            "leafrouter"
        )
        self.assertTrue(traffic_mgr.traffic_shift_away() == bgp_neighbor.RET_FAILED)

    @patch.object(bgp_neighbor.multi_asic, "is_multi_asic", return_value=False)
    @patch.object(
        bgp_neighbor, "exec_cmd", return_value=[bgp_neighbor.RET_SUCCESS, "", ""]
    )
    @patch.object(bgp_neighbor, "wait_until", return_value=True)
    def test_traffic_shift_away_by_shut(
        self, mock_is_multi_asic, mock_exec_cmd, mock_wait_until
    ):
        ver = ["20191130", "70"]
        dbc = DBConnector(ver)
        traffic_mgr = TorAboveTrafficMgr(
            bgp_neighbor.BGP_SHUT,
            bgp_neighbor.TS_BGPSHUT,
            bgp_neighbor.BGP_DOWNUP_NEIGHBORS_STARTUP_DELAY,
            bgp_neighbor.ALL_NEIGHBORS,
            ver,
            dbc.get_connector(),
            "leafrouter"
        )
        ret = traffic_mgr.traffic_shift_away()
        self.assertTrue(ret == bgp_neighbor.RET_SUCCESS)

    @patch.object(bgp_neighbor.multi_asic, "is_multi_asic", return_value=False)
    @patch.object(
        bgp_neighbor, "exec_cmd", return_value=[bgp_neighbor.RET_SUCCESS, "", ""]
    )
    @patch.object(bgp_neighbor, "wait_until", return_value=True)
    @patch.object(bgp_neighbor, "run_cmds", return_value=bgp_neighbor.RET_SUCCESS)
    def test_traffic_shift_away_201811(
        self, mock_is_multi_asic, mock_exec_cmd, mock_wait_until, mock_run_cmds
    ):
        ver = ["20181130", "70"]
        dbc = DBConnector(ver)
        traffic_mgr = TorAboveTrafficMgr(
            bgp_neighbor.BGP_SHUT,
            bgp_neighbor.TS_RM,
            bgp_neighbor.BGP_DOWNUP_NEIGHBORS_STARTUP_DELAY,
            bgp_neighbor.ALL_NEIGHBORS,
            ver,
            dbc.get_connector(),
            "leafrouter"
        )
        ret = traffic_mgr.traffic_shift_away()
        self.assertTrue(ret == bgp_neighbor.RET_SUCCESS)

    @patch.object(bgp_neighbor.multi_asic, "is_multi_asic", return_value=False)
    @patch.object(
        bgp_neighbor, "exec_cmd", return_value=[bgp_neighbor.RET_SUCCESS, "", ""]
    )
    @patch.object(bgp_neighbor, "wait_until", return_value=True)
    @patch.object(bgp_neighbor, "run_cmds", return_value=bgp_neighbor.RET_SUCCESS)
    def test_traffic_shift_away_201811_by_shut(
        self, mock_is_multi_asic, mock_exec_cmd, mock_wait_until, mock_run_cmds
    ):
        ver = ["20181130", "70"]
        dbc = DBConnector(ver)
        traffic_mgr = TorAboveTrafficMgr(
            bgp_neighbor.BGP_SHUT,
            bgp_neighbor.TS_BGPSHUT,
            bgp_neighbor.BGP_DOWNUP_NEIGHBORS_STARTUP_DELAY,
            bgp_neighbor.ALL_NEIGHBORS,
            ver,
            dbc.get_connector(),
            "leafrouter"
        )
        ret = traffic_mgr.traffic_shift_away()
        self.assertTrue(ret == bgp_neighbor.RET_SUCCESS)

    @patch.object(bgp_neighbor.multi_asic, "is_multi_asic", return_value=False)
    @patch.object(
        bgp_neighbor, "exec_cmd", return_value=[bgp_neighbor.RET_SUCCESS, "", ""]
    )
    @patch.object(bgp_neighbor, "wait_until", return_value=True)
    @patch.object(bgp_neighbor, "run_cmds", return_value=bgp_neighbor.RET_SUCCESS)
    def test_traffic_shift_away_hard(
        self, mock_is_multi_asic, mock_exec_cmd, mock_wait_until, mock_run_cmds
    ):
        ver = ["20181130", "70"]
        dbc = DBConnector(ver)
        traffic_mgr = TorAboveTrafficMgr(
            bgp_neighbor.BGP_SHUT,
            bgp_neighbor.TS_BGPSHUT,
            bgp_neighbor.BGP_DOWNUP_NEIGHBORS_STARTUP_DELAY,
            bgp_neighbor.ALL_NEIGHBORS,
            ver,
            dbc.get_connector(),
            "leafrouter",
            True,
        )
        ret = traffic_mgr.traffic_shift_away()
        self.assertTrue(ret == bgp_neighbor.RET_SUCCESS)

    @patch.object(bgp_neighbor.multi_asic, "is_multi_asic", return_value=False)
    @patch.object(
        bgp_neighbor, "exec_cmd", return_value=[bgp_neighbor.RET_SUCCESS, "", ""]
    )
    @patch.object(bgp_neighbor, "wait_until", return_value=True)
    def test_traffic_shift_restore(
        self, mock_is_multi_asic, mock_exec_cmd, mock_wait_until
    ):
        ver = ["20191130", "70"]
        dbc = DBConnector(ver)
        traffic_mgr = TorAboveTrafficMgr(
            bgp_neighbor.BGP_UNSHUT,
            bgp_neighbor.TS_RM,
            bgp_neighbor.BGP_DOWNUP_NEIGHBORS_STARTUP_DELAY,
            bgp_neighbor.ALL_NEIGHBORS,
            ver,
            dbc.get_connector(),
            "leafrouter"
        )
        ret = traffic_mgr.traffic_shift_restore()
        self.assertTrue(ret == bgp_neighbor.RET_SUCCESS)

    @patch.object(bgp_neighbor.multi_asic, "is_multi_asic", return_value=False)
    @patch.object(
        bgp_neighbor, "exec_cmd", return_value=[bgp_neighbor.RET_SUCCESS, "", ""]
    )
    @patch.object(bgp_neighbor, "wait_until", return_value=True)
    def test_traffic_shift_restore_exception(
        self, mock_is_multi_asic, mock_exec_cmd, mock_wait_until
    ):
        ver = ["20171130", "70"]
        dbc = DBConnector(ver)
        traffic_mgr = TorAboveTrafficMgr(
            bgp_neighbor.BGP_UNSHUT,
            bgp_neighbor.TS_RM,
            bgp_neighbor.BGP_DOWNUP_NEIGHBORS_STARTUP_DELAY,
            bgp_neighbor.ALL_NEIGHBORS,
            ver,
            dbc.get_connector(),
            "leafrouter"
        )
        ret = traffic_mgr.traffic_shift_restore()
        self.assertTrue(ret == bgp_neighbor.RET_FAILED)

    @patch.object(bgp_neighbor.multi_asic, "is_multi_asic", return_value=False)
    @patch.object(
        bgp_neighbor, "exec_cmd", return_value=[bgp_neighbor.RET_SUCCESS, "", ""]
    )
    @patch.object(bgp_neighbor, "wait_until", return_value=True)
    def test_traffic_shift_restore_by_shut(
        self, mock_is_multi_asic, mock_exec_cmd, mock_wait_until
    ):
        ver = ["20191130", "70"]
        dbc = DBConnector(ver)
        traffic_mgr = TorAboveTrafficMgr(
            bgp_neighbor.BGP_UNSHUT,
            bgp_neighbor.TS_BGPSHUT,
            bgp_neighbor.BGP_DOWNUP_NEIGHBORS_STARTUP_DELAY,
            bgp_neighbor.ALL_NEIGHBORS,
            ver,
            dbc.get_connector(),
            "leafrouter"
        )
        ret = traffic_mgr.traffic_shift_restore()
        self.assertTrue(ret == bgp_neighbor.RET_SUCCESS)

    @patch.object(bgp_neighbor.multi_asic, "is_multi_asic", return_value=False)
    @patch.object(
        bgp_neighbor, "exec_cmd", return_value=[bgp_neighbor.RET_SUCCESS, "", ""]
    )
    @patch.object(bgp_neighbor, "wait_until", return_value=True)
    @patch.object(bgp_neighbor, "run_cmds", return_value=bgp_neighbor.RET_SUCCESS)
    def test_traffic_shift_restore_201811(
        self, mock_is_multi_asic, mock_exec_cmd, mock_wait_until, mock_run_cmds
    ):
        ver = ["20181130", "70"]
        dbc = DBConnector(ver)
        traffic_mgr = TorAboveTrafficMgr(
            bgp_neighbor.BGP_UNSHUT,
            bgp_neighbor.TS_RM,
            bgp_neighbor.BGP_DOWNUP_NEIGHBORS_STARTUP_DELAY,
            bgp_neighbor.ALL_NEIGHBORS,
            ver,
            dbc.get_connector(),
            "leafrouter"
        )
        ret = traffic_mgr.traffic_shift_restore()
        self.assertTrue(ret == bgp_neighbor.RET_SUCCESS)

    @patch.object(bgp_neighbor.multi_asic, "is_multi_asic", return_value=False)
    @patch.object(
        bgp_neighbor, "exec_cmd", return_value=[bgp_neighbor.RET_SUCCESS, "", ""]
    )
    @patch.object(bgp_neighbor, "wait_until", return_value=True)
    @patch.object(bgp_neighbor, "run_cmds", return_value=bgp_neighbor.RET_SUCCESS)
    def test_traffic_shift_restore_201811_by_shut(
        self, mock_is_multi_asic, mock_exec_cmd, mock_wait_until, mock_run_cmds
    ):
        ver = ["20181130", "70"]
        dbc = DBConnector(ver)
        traffic_mgr = TorAboveTrafficMgr(
            bgp_neighbor.BGP_UNSHUT,
            bgp_neighbor.TS_BGPSHUT,
            bgp_neighbor.BGP_DOWNUP_NEIGHBORS_STARTUP_DELAY,
            bgp_neighbor.ALL_NEIGHBORS,
            ver,
            dbc.get_connector(),
            "leafrouter"
        )
        ret = traffic_mgr.traffic_shift_restore()
        self.assertTrue(ret == bgp_neighbor.RET_SUCCESS)

    @patch.object(bgp_neighbor.multi_asic, "is_multi_asic", return_value=False)
    @patch.object(
        bgp_neighbor, "exec_cmd", return_value=[bgp_neighbor.RET_SUCCESS, "", ""]
    )
    @patch.object(bgp_neighbor, "wait_until", return_value=True)
    @patch.object(bgp_neighbor, "run_cmds", return_value=bgp_neighbor.RET_SUCCESS)
    def test_traffic_shift_restore_hard(
        self, mock_is_multi_asic, mock_exec_cmd, mock_wait_until, mock_run_cmds
    ):
        ver = ["20191130", "70"]
        dbc = DBConnector(ver)
        traffic_mgr = TorAboveTrafficMgr(
            bgp_neighbor.BGP_UNSHUT,
            bgp_neighbor.TS_BGPSHUT,
            bgp_neighbor.BGP_DOWNUP_NEIGHBORS_STARTUP_DELAY,
            bgp_neighbor.ALL_NEIGHBORS,
            ver,
            dbc.get_connector(),
            "leafrouter",
            True,
        )
        ret = traffic_mgr.traffic_shift_restore()
        self.assertTrue(ret == bgp_neighbor.RET_SUCCESS)


class ParamsTest(TestBase):
    def setUp(self):
        bgp_neighbor.ConfigDBConnector().get_entry = mock_config_db_get_entry
        bgp_neighbor.ConfigDBConnector().get_table = mock_config_db_get_table

    def test_parse_list(self):
        sonic_os = bgp_neighbor.parse_list(SAMPLE_SONIC_INSTALLER_LIST)
        self.assertIn("20191130", sonic_os)

        sonic_os = bgp_neighbor.parse_list(SAMPLE_SONIC_INSTALLER_LIST_WITH_EMPTY_LINE)
        self.assertIn("20191130", sonic_os)

    @patch.object(os, "geteuid", return_value=0)
    def test_parse_params(self, mock_geteuid):
        bad_clis = [
            ["./bgp_neighbor", "-m", "bgpshut", "shut", "0.0.0.0"],
            ["./bgp_neighbor", "-m", "bgp", "shutdown", "0.0.0.0"],
            ["./bgp_neighbor", "-m", "forbidroutemap", "shutdown", "10.0.0.0"],
        ]
        for test_cli in bad_clis:
            sys.argv = test_cli
            if py_verrsion == 2:
                with patch("sys.stdout", new=BytesIO()) as stdOutput:
                    with self.assertRaises(SystemExit) as cm:
                        bgp_neighbor.main()
                    self.assertIn("Usage", stdOutput.getvalue().strip())
            else:
                with patch("sys.stdout", new=StringIO()) as stdOutput:
                    with self.assertRaises(SystemExit) as cm:
                        bgp_neighbor.main()
                    self.assertIn("Usage", stdOutput.getvalue().strip())

    @patch.object(os, "geteuid", return_value=1)
    def test_parse_params_non_root(self, mock_geteuid):
        sys.argv = ["./bgp_neighbor", "-m", "bgpshut", "shutdown", "0.0.0.0"]
        if py_verrsion == 2:
            with patch("sys.stdout", new=BytesIO()) as stdOutput:
                bgp_neighbor.main()
                self.assertIn("Root privileges", stdOutput.getvalue().strip())
        else:
            with patch("sys.stdout", new=StringIO()) as stdOutput:
                bgp_neighbor.main()
                self.assertIn("Root privileges", stdOutput.getvalue().strip())

    @patch.object(subprocess.Popen, "communicate", return_value=["out", b"error"])
    @patch.object(subprocess.Popen, "wait", return_value=bgp_neighbor.RET_SUCCESS)
    def test_run_cmds(self, mock_wait, mock_communicate):
        ret = bgp_neighbor.run_cmds(["ls", "-l"], False)
        self.assertTrue(ret == bgp_neighbor.RET_SUCCESS)

        ret = bgp_neighbor.run_cmds(["ls", "-l"], True)
        self.assertTrue(ret == bgp_neighbor.RET_SUCCESS)

        with patch.object(
            subprocess.Popen, "wait", return_value=bgp_neighbor.RET_FAILED
        ):
            ret = bgp_neighbor.run_cmds(["ls", "-l"], False)
            self.assertTrue(ret == bgp_neighbor.RET_FAILED)

    def check_status_true(self):
        return True

    def check_status_false(self):
        return False

    def check_status_exception(self):
        assert False

    def test_wait_until(self):
        self.assertTrue(bgp_neighbor.wait_until(2, 1, 0, self.check_status_true))
        self.assertTrue(bgp_neighbor.wait_until(2, 1, 1, self.check_status_true))
        self.assertFalse(bgp_neighbor.wait_until(2, 1, 1, self.check_status_exception))
        self.assertFalse(bgp_neighbor.wait_until(2, 1, 0, self.check_status_false))

    def test_parser_error(self):
        parser = MyParser()
        with self.assertRaises(SystemExit) as cm:
            parser.error("test error")

    def test_exec_cmd(self):
        ret, _, _ = bgp_neighbor.exec_cmd("ls -l", True)
        self.assertTrue(ret == bgp_neighbor.RET_SUCCESS)

    @patch.object(subprocess.Popen, "communicate", return_value=[b"out", b"error"])
    def test_exec_cmd_err(self, mock_communicate):
        ret = bgp_neighbor.exec_cmd(["ls", "-l"], False)
        self.assertTrue(ret != bgp_neighbor.RET_SUCCESS)

    def test_fun_time_out(self):
        p = subprocess.Popen(
            'ls -l', shell=True, executable="/bin/bash", stdout=subprocess.PIPE
        )
        if py_verrsion == 2:
            with patch("sys.stdout", new=BytesIO()) as stdOutput:
                bgp_neighbor.fun_time_out(p, 'ls -l', 5)
                self.assertIn("ls -l cmd timeout after 5 seconds", stdOutput.getvalue().strip())
                self.assertTrue(p.returncode == bgp_neighbor.RET_TIMEOUT)
        else:
            with patch("sys.stdout", new=StringIO()) as stdOutput:
                bgp_neighbor.fun_time_out(p, 'ls -l', 5)
                self.assertIn("ls -l cmd timeout after 5 seconds", stdOutput.getvalue().strip())
                self.assertTrue(p.returncode == bgp_neighbor.RET_TIMEOUT)

    def test_get_eplased_time(self):
        start_time = time.time() - 5
        elapsed_time = bgp_neighbor.get_eplased_time(start_time, 1, 2)
        self.assertTrue(elapsed_time == 2)

        elapsed_time = bgp_neighbor.get_eplased_time(start_time, 5, 2)
        self.assertTrue(elapsed_time >= 5 and elapsed_time<=6)
    
    def test_find_child_processes(self):
        bgp_neighbor.find_child_processes(1, 3)
        with patch(
            "subprocess.check_output", return_value="1\n1\n"
        ):
            bgp_neighbor.find_child_processes(0, 0)

    @patch.object(bgp_neighbor.multi_asic, "is_multi_asic", return_value=False)
    @patch.object(os, "geteuid", return_value=0)
    @patch.object(
        bgp_neighbor, "exec_cmd", return_value=[bgp_neighbor.RET_SUCCESS, "", ""]
    )
    @patch.object(bgp_neighbor, "wait_until", return_value=True)
    @patch.object(bgp_neighbor, "run_cmds", return_value=bgp_neighbor.RET_SUCCESS)
    def test_parse_params_capa_query(
        self, 
        mock_is_multi_asic,
        mock_geteuid,
        mock_exec_cmd,
        mock_wait_until,
        mock_run_cmds
    ):
        sys.argv = ["./bgp_neighbor", "--capa_query", "tsa"]
        bgp_neighbor.ConfigDBConnector().get_entry = mock_config_db_get_entry_tor
        bgp_neighbor.ConfigDBConnector().get_table = mock_config_db_get_table_tor
        with patch("bgp_neighbor.get_sonic_ver", return_value=['20191130', '70']):
            self.assertTrue(bgp_neighbor.main() == bgp_neighbor.RET_NOT_SUPPORTED)

        bgp_neighbor.ConfigDBConnector().get_entry = mock_config_db_get_entry
        bgp_neighbor.ConfigDBConnector().get_table = mock_config_db_get_table
        with patch("bgp_neighbor.get_sonic_ver", return_value=['20191130', '70']):
            self.assertTrue(bgp_neighbor.main() == bgp_neighbor.RET_SUCCESS)

        bgp_neighbor.ConfigDBConnector().get_entry = mock_config_db_get_entry_dual_tor
        bgp_neighbor.ConfigDBConnector().get_table = mock_config_db_get_table
        with patch("bgp_neighbor.get_sonic_ver", return_value=['20191130', '70']):
            self.assertTrue(bgp_neighbor.main() == bgp_neighbor.RET_SUCCESS)

        bgp_neighbor.ConfigDBConnector().get_entry = mock_config_db_get_entry_mgmt_tor
        bgp_neighbor.ConfigDBConnector().get_table = mock_config_db_get_table
        with patch("bgp_neighbor.get_sonic_ver", return_value=['20191130', '70']):
            self.assertTrue(bgp_neighbor.main() == bgp_neighbor.RET_NOT_SUPPORTED)

        sys.argv = ["./bgp_neighbor", "--capa_query", "tsab"]
        if py_verrsion == 2:
            with patch("sys.stdout", new=BytesIO()) as stdOutput:
                with self.assertRaises(SystemExit) as cm:
                    bgp_neighbor.main()
                self.assertIn("--capa_query", stdOutput.getvalue().strip())
        else:
            with patch("sys.stdout", new=StringIO()) as stdOutput:
                with self.assertRaises(SystemExit) as cm:
                    bgp_neighbor.main()
                self.assertIn("--capa_query", stdOutput.getvalue().strip())


class MainTest(TestCase):
    @patch.object(bgp_neighbor.multi_asic, "is_multi_asic", return_value=False)
    @patch.object(os, "geteuid", return_value=0)
    @patch.object(
        bgp_neighbor, "exec_cmd", return_value=[bgp_neighbor.RET_SUCCESS, "", ""]
    )
    @patch.object(bgp_neighbor, "wait_until", return_value=True)
    @patch.object(bgp_neighbor, "run_cmds", return_value=bgp_neighbor.RET_SUCCESS)
    def test_shutdown(
        self,
        mock_is_multi_asic,
        mock_geteuid,
        mock_exec_cmd,
        mock_wait_until,
        mock_run_cmds,
    ):
        sys.argv = ["./bgp_neighbor", "-m", "bgpshut", "shutdown", "0.0.0.0"]
        bgp_neighbor.ConfigDBConnector().get_entry = mock_config_db_get_entry
        bgp_neighbor.ConfigDBConnector().get_table = mock_config_db_get_table
        get_sonic_ver_param = (
            ["20191130", "70"],
            ["20181130", "70"],
            ["20201231", "70"],
            ["20220531", "24"],
        )
        for ver in get_sonic_ver_param:
            with patch("bgp_neighbor.get_sonic_ver", return_value=ver):
                self.assertTrue(bgp_neighbor.main() == bgp_neighbor.RET_SUCCESS)

        bgp_neighbor.ConfigDBConnector().get_entry = mock_config_db_get_entry_tor
        bgp_neighbor.ConfigDBConnector().get_table = mock_config_db_get_table_tor
        for ver in get_sonic_ver_param:
            with patch("bgp_neighbor.get_sonic_ver", return_value=ver):
                self.assertTrue(bgp_neighbor.main() == bgp_neighbor.RET_SUCCESS)

        bgp_neighbor.ConfigDBConnector().get_entry = mock_config_db_get_entry_mgmt_tor
        bgp_neighbor.ConfigDBConnector().get_table = mock_config_db_get_table_mgmt_tor
        for ver in get_sonic_ver_param:
            with patch("bgp_neighbor.get_sonic_ver", return_value=ver):
                self.assertTrue(bgp_neighbor.main() == bgp_neighbor.RET_SUCCESS)

        bgp_neighbor.ConfigDBConnector().get_entry = mock_config_db_get_entry_spine_router
        bgp_neighbor.ConfigDBConnector().get_table = mock_config_db_get_table_spine_router
        for ver in get_sonic_ver_param:
            with patch("bgp_neighbor.get_sonic_ver", return_value=ver):
                with patch("bgp_neighbor.is_chassis_supervisor", return_value=True):
                    self.assertTrue(bgp_neighbor.main() == bgp_neighbor.RET_SUCCESS)
                with patch("bgp_neighbor.is_chassis_supervisor", return_value=False):
                    self.assertTrue(bgp_neighbor.main() == bgp_neighbor.RET_SUCCESS)

    @patch.object(bgp_neighbor.multi_asic, "is_multi_asic", return_value=False)
    @patch.object(os, "geteuid", return_value=0)
    @patch.object(
        bgp_neighbor, "exec_cmd", return_value=[bgp_neighbor.RET_SUCCESS, "", ""]
    )
    @patch.object(bgp_neighbor, "wait_until", return_value=True)
    @patch.object(bgp_neighbor, "run_cmds", return_value=bgp_neighbor.RET_SUCCESS)
    def test_shutdown_single(
        self,
        mock_is_multi_asic,
        mock_geteuid,
        mock_exec_cmd,
        mock_wait_until,
        mock_run_cmds,
    ):
        sys.argv = ["./bgp_neighbor", "-m", "bgpshut", "shutdown", "10.0.0.0"]
        bgp_neighbor.ConfigDBConnector().get_entry = mock_config_db_get_entry
        bgp_neighbor.ConfigDBConnector().get_table = mock_config_db_get_table
        get_sonic_ver_param = (
            ["20191130", "70"],
            ["20181130", "70"],
            ["20201231", "70"],
            ["20220531", "24"],
        )
        for ver in get_sonic_ver_param:
            with patch("bgp_neighbor.get_sonic_ver", return_value=ver):
                self.assertTrue(bgp_neighbor.main() == bgp_neighbor.RET_SUCCESS)

        bgp_neighbor.ConfigDBConnector().get_entry = mock_config_db_get_entry_tor
        bgp_neighbor.ConfigDBConnector().get_table = mock_config_db_get_table_tor
        for ver in get_sonic_ver_param:
            with patch("bgp_neighbor.get_sonic_ver", return_value=ver):
                self.assertTrue(bgp_neighbor.main() == bgp_neighbor.RET_SUCCESS)

        bgp_neighbor.ConfigDBConnector().get_entry = mock_config_db_get_entry_mgmt_tor
        bgp_neighbor.ConfigDBConnector().get_table = mock_config_db_get_table_mgmt_tor
        for ver in get_sonic_ver_param:
            with patch("bgp_neighbor.get_sonic_ver", return_value=ver):
                self.assertTrue(bgp_neighbor.main() == bgp_neighbor.RET_SUCCESS)

    @patch.object(bgp_neighbor.multi_asic, "is_multi_asic", return_value=False)
    @patch.object(os, "geteuid", return_value=0)
    @patch.object(
        bgp_neighbor, "exec_cmd", return_value=[bgp_neighbor.RET_FAILED, "", ""]
    )
    @patch.object(bgp_neighbor, "wait_until", return_value=True)
    @patch.object(bgp_neighbor, "run_cmds", return_value=bgp_neighbor.RET_SUCCESS)
    def test_shutdown_exception(
        self,
        mock_is_multi_asic,
        mock_geteuid,
        mock_exec_cmd,
        mock_wait_until,
        mock_run_cmds,
    ):
        sys.argv = ["./bgp_neighbor", "-m", "bgpshut", "shutdown", "0.0.0.0"]
        bgp_neighbor.ConfigDBConnector().get_entry = mock_config_db_get_entry
        bgp_neighbor.ConfigDBConnector().get_table = mock_config_db_get_table
        self.assertTrue(bgp_neighbor.main() == bgp_neighbor.RET_FAILED)

    @patch.object(bgp_neighbor.multi_asic, "is_multi_asic", return_value=False)
    @patch.object(os, "geteuid", return_value=0)
    @patch.object(
        bgp_neighbor, "exec_cmd", return_value=[bgp_neighbor.RET_SUCCESS, "", ""]
    )
    @patch.object(bgp_neighbor, "wait_until", return_value=True)
    @patch.object(bgp_neighbor, "run_cmds", return_value=bgp_neighbor.RET_SUCCESS)
    @patch.object(bgp_neighbor, "get_sonic_ver", return_value=["20191130", "70"])
    def test_shutdown_dryrun(
        self,
        mock_is_multi_asic,
        mock_geteuid,
        mock_exec_cmd,
        mock_wait_until,
        mock_run_cmds,
        mock_get_sonic_ver,
    ):
        sys.argv = [
            "./bgp_neighbor",
            "-m",
            "bgpshut",
            "shutdown",
            "0.0.0.0",
            "--dryrun",
        ]
        bgp_neighbor.ConfigDBConnector().get_entry = mock_config_db_get_entry
        bgp_neighbor.ConfigDBConnector().get_table = mock_config_db_get_table
        self.assertTrue(bgp_neighbor.main() == bgp_neighbor.RET_SUCCESS)

    @patch.object(bgp_neighbor.multi_asic, "is_multi_asic", return_value=False)
    @patch.object(os, "geteuid", return_value=0)
    @patch.object(
        bgp_neighbor, "exec_cmd", return_value=[bgp_neighbor.RET_SUCCESS, "", ""]
    )
    @patch.object(bgp_neighbor, "wait_until", return_value=True)
    @patch.object(bgp_neighbor, "run_cmds", return_value=bgp_neighbor.RET_SUCCESS)
    def test_startup(
        self,
        mock_is_multi_asic,
        mock_geteuid,
        mock_exec_cmd,
        mock_wait_until,
        mock_run_cmds,
    ):
        sys.argv = ["./bgp_neighbor", "-m", "bgpshut", "startup", "0.0.0.0"]
        bgp_neighbor.ConfigDBConnector().get_entry = mock_config_db_get_entry
        bgp_neighbor.ConfigDBConnector().get_table = mock_config_db_get_table
        get_sonic_ver_param = (
            ["20191130", "70"],
            ["20181130", "70"],
            ["20201231", "70"],
            ["20220531", "24"],
        )
        for ver in get_sonic_ver_param:
            with patch("bgp_neighbor.get_sonic_ver", return_value=ver):
                self.assertTrue(bgp_neighbor.main() == bgp_neighbor.RET_SUCCESS)

        bgp_neighbor.ConfigDBConnector().get_entry = mock_config_db_get_entry_tor
        bgp_neighbor.ConfigDBConnector().get_table = mock_config_db_get_table_tor
        for ver in get_sonic_ver_param:
            with patch("bgp_neighbor.get_sonic_ver", return_value=ver):
                self.assertTrue(bgp_neighbor.main() == bgp_neighbor.RET_SUCCESS)

        bgp_neighbor.ConfigDBConnector().get_entry = mock_config_db_get_entry_mgmt_tor
        bgp_neighbor.ConfigDBConnector().get_table = mock_config_db_get_table_mgmt_tor
        for ver in get_sonic_ver_param:
            with patch("bgp_neighbor.get_sonic_ver", return_value=ver):
                self.assertTrue(bgp_neighbor.main() == bgp_neighbor.RET_SUCCESS)

        bgp_neighbor.ConfigDBConnector().get_entry = mock_config_db_get_entry_dual_tor
        bgp_neighbor.ConfigDBConnector().get_table = mock_config_db_get_table_tor
        for ver in get_sonic_ver_param:
            with patch("bgp_neighbor.get_sonic_ver", return_value=ver):
                self.assertTrue(bgp_neighbor.main() == bgp_neighbor.RET_SUCCESS)

    @patch.object(bgp_neighbor.multi_asic, "is_multi_asic", return_value=False)
    @patch.object(os, "geteuid", return_value=0)
    @patch.object(
        bgp_neighbor, "exec_cmd", return_value=[bgp_neighbor.RET_SUCCESS, "", ""]
    )
    @patch.object(bgp_neighbor, "wait_until", return_value=True)
    @patch.object(bgp_neighbor, "run_cmds", return_value=bgp_neighbor.RET_SUCCESS)
    def test_startup_dryrun(
        self,
        mock_is_multi_asic,
        mock_geteuid,
        mock_exec_cmd,
        mock_wait_until,
        mock_run_cmds,
    ):
        sys.argv = ["./bgp_neighbor", "-m", "bgpshut", "startup", "0.0.0.0", "--dryrun"]
        bgp_neighbor.ConfigDBConnector().get_entry = mock_config_db_get_entry
        bgp_neighbor.ConfigDBConnector().get_table = mock_config_db_get_table
        self.assertTrue(bgp_neighbor.main() == bgp_neighbor.RET_SUCCESS)

    @patch.object(bgp_neighbor.multi_asic, "is_multi_asic", return_value=False)
    @patch.object(os, "geteuid", return_value=0)
    @patch.object(
        bgp_neighbor, "exec_cmd", return_value=[bgp_neighbor.RET_SUCCESS, "", ""]
    )
    @patch.object(bgp_neighbor, "wait_until", return_value=True)
    @patch.object(bgp_neighbor, "run_cmds", return_value=bgp_neighbor.RET_SUCCESS)
    def test_shutdown_timeout(
        self,
        mock_is_multi_asic,
        mock_geteuid,
        mock_exec_cmd,
        mock_wait_until,
        mock_run_cmds,
    ):
        sys.argv = ["./bgp_neighbor", "-m", "bgpshut", "shutdown", "0.0.0.0"]
        bgp_neighbor.ConfigDBConnector().get_entry = mock_config_db_get_entry
        bgp_neighbor.ConfigDBConnector().get_table = mock_config_db_get_table
        get_sonic_ver_param = (
            ["20191130", "70"],
            ["20181130", "70"],
            ["20201231", "70"],
            ["20220531", "24"],
        )
        for ver in get_sonic_ver_param:
            with patch("bgp_neighbor.get_sonic_ver", return_value=ver):
                self.assertTrue(bgp_neighbor.main() == bgp_neighbor.RET_SUCCESS)

        bgp_neighbor.ConfigDBConnector().get_entry = mock_config_db_get_entry_tor
        bgp_neighbor.ConfigDBConnector().get_table = mock_config_db_get_table_tor
        for ver in get_sonic_ver_param:
            with patch("bgp_neighbor.get_sonic_ver", return_value=ver):
                self.assertTrue(bgp_neighbor.main() == bgp_neighbor.RET_SUCCESS)

        bgp_neighbor.ConfigDBConnector().get_entry = mock_config_db_get_entry_mgmt_tor
        bgp_neighbor.ConfigDBConnector().get_table = mock_config_db_get_table_mgmt_tor
        for ver in get_sonic_ver_param:
            with patch("bgp_neighbor.get_sonic_ver", return_value=ver):
                self.assertTrue(bgp_neighbor.main() == bgp_neighbor.RET_SUCCESS)

if __name__ == "__main__":
    unittest.main(verbosity=2)
