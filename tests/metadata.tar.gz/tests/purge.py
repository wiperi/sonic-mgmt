from manifest import Manifest
import os
import duthost
import sys

BASE_DIR = os.path.join(os.path.dirname(__file__), '../')
MANIFEST_FILE_NAME = os.path.join(BASE_DIR, 'manifest/manifest.json')

def collect_info():
    info = {}
    info["SwitchType"] = duthost.get_switch_type()
    info["BuildVersion"] = duthost.get_build_version()
    info["HwSku"] = duthost.get_hwsku()
    info["Platform"] = duthost.get_platform()
    info["AsicType"] = duthost.get_asic_type()
    return info

def enforce_manifest(mock):
    if not os.path.isfile(MANIFEST_FILE_NAME):
        return
    info = collect_info()
    for k, v in info.items():
        if v == None or len(v) == 0:
            raise ValueError(k + " cannot be obtained.")
    manifest = Manifest.load(MANIFEST_FILE_NAME)
    for path, file_obj in manifest.files.items():
        if not file_obj.is_match(info):
            if mock:
                print(os.path.join(BASE_DIR, path))
            else:
                os.remove(os.path.join(BASE_DIR, path))

if __name__ == "__main__":
    if len(sys.argv) == 2 and sys.argv[0].endswith("purge.py") and sys.argv[1] == "--list":
        enforce_manifest(True)
    elif len(sys.argv) == 1 and sys.argv[0].endswith("purge.py"):
        enforce_manifest(False)

