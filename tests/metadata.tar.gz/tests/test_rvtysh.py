import sys
import pytest
from unittest.mock import call, patch, MagicMock

sys.modules['sonic_platform'] = MagicMock()
sys.modules['sonic_py_common'] = MagicMock()
from postupgrade_actions import fix_sudoers_rvtysh, fix_rvtysh_patch

CHECK_RVTYSH = "cat /etc/sudoers | grep \'/usr/bin/rvtysh -c show \\*, /usr/bin/rvtysh -n \\[0-9\\] -c show \\*, \\\\\'"
POSTUPGRADE_ACTIONS_DATA_DIR = '/postupgrade_actions_data_dir'
REPLACE_COMMAND = r"s|/usr/bin/rvtysh \*, \\|/usr/bin/rvtysh -c show \*, /usr/bin/rvtysh -n [0-9] -c show \*, \\|g"
RVTYSH = "rvtysh"
INSTALL_DIR = "/usr/bin/"
RVTYSH_INSTALL_DIR = "{}{}".format(INSTALL_DIR, RVTYSH)

class TestRvtysh(object):
    def setup_method(self):
        print('SETUP')

    @patch('postupgrade_actions.log_info')
    @patch('postupgrade_actions.exec_cmd')
    @patch('postupgrade_actions.POSTUPGRADE_ACTIONS_DATA_DIR', POSTUPGRADE_ACTIONS_DATA_DIR)
    @patch('sonic_py_common.get_sonic_version_info', MagicMock(return_value={'build_version': '20201231.85'}))
    def test_fix_sudoers_rvtysh_success_update(self, mock_exec_cmd, mock_log_info):
        mock_exec_cmd.side_effect = [
            (1, 'pre-check rvtysh in sudoers: not updated for rvtysh issue, updating now'),
            (0, 'rvtysh sudoers script is updated succesfully'),
            (0, 'post-check rvtysh in sudoers: successfully updated')
        ]

        fix_sudoers_rvtysh()
        print(mock_exec_cmd.call_args_list)
        print(mock_log_info.call_args_list)

        assert mock_exec_cmd.call_args_list == [
            call(CHECK_RVTYSH),
            call("sudo bash {}/fix_sudo.sh '{}'".format(POSTUPGRADE_ACTIONS_DATA_DIR, REPLACE_COMMAND)),
            call(CHECK_RVTYSH)
        ]

        assert mock_log_info.call_args_list == [
            call('fix_sudoers_rvtysh() successfully updated sudoers script for rvtysh.')
        ]

    @patch('postupgrade_actions.log_error')
    @patch('postupgrade_actions.exec_cmd')
    @patch('postupgrade_actions.POSTUPGRADE_ACTIONS_DATA_DIR', POSTUPGRADE_ACTIONS_DATA_DIR)
    @patch('sonic_py_common.get_sonic_version_info', MagicMock(return_value={'build_version': '20201231.85'}))
    def test_fix_sudoers_rvtysh_failed_update(self, mock_exec_cmd, mock_log_error):
        mock_exec_cmd.side_effect = [
            (1, 'pre-check rvtysh in sudoers: not updated for rvtysh issue, updating now'),
            (0, 'rvtysh sudoers script is updated succesfully'),
            (1, 'post-check rvtysh in sudoers: unsuccessfully updated')
        ]

        fix_sudoers_rvtysh()
        print(mock_exec_cmd.call_args_list)
        print(mock_log_error.call_args_list)

        assert mock_exec_cmd.call_args_list == [
            call(CHECK_RVTYSH),
            call("sudo bash {}/fix_sudo.sh '{}'".format(POSTUPGRADE_ACTIONS_DATA_DIR, REPLACE_COMMAND)),
            call(CHECK_RVTYSH)
        ]

        assert mock_log_error.call_args_list == [
            call('fix_sudoers_rvtysh() failed to update sudoers for rvtysh. post-check rvtysh in sudoers: unsuccessfully updated')
        ]

    @patch('postupgrade_actions.log_info')
    @patch('postupgrade_actions.exec_cmd')
    @patch('postupgrade_actions.POSTUPGRADE_ACTIONS_DATA_DIR', POSTUPGRADE_ACTIONS_DATA_DIR)
    @patch('sonic_py_common.get_sonic_version_info', MagicMock(return_value={'build_version': '20201231.85'}))
    def test_fix_sudoers_rvtysh_already_update(self, mock_exec_cmd, mock_log_info):
        mock_exec_cmd.side_effect = [
            (0, 'pre-check rvtysh in sudoers: already updated'),
        ]

        fix_sudoers_rvtysh()
        print(mock_exec_cmd.call_args_list)
        print(mock_log_info.call_args_list)

        assert mock_exec_cmd.call_args_list == [
            call(CHECK_RVTYSH),
        ]

        assert mock_log_info.call_args_list == [
            call('fix_sudoers_rvtysh() sudoers script is already updated for rvtysh issue, skipping.')
        ]

    @patch('postupgrade_actions.log_info')
    @patch('postupgrade_actions.exec_cmd')
    @patch('postupgrade_actions.POSTUPGRADE_ACTIONS_DATA_DIR', POSTUPGRADE_ACTIONS_DATA_DIR)
    @patch('sonic_py_common.get_sonic_version_info', MagicMock(return_value={'build_version': '20201231.85'}))
    def test_fix_rvtysh_patch_already_update(self, mock_exec_cmd, mock_log_info):
        mock_exec_cmd.side_effect = [
            (0, 'f567b6e2019m3l3c2ed971a73f918b0f  rvtysh'),
            (0, 'f567b6e2019m3l3c2ed971a73f918b0f  {}'.format(RVTYSH_INSTALL_DIR)),
        ]

        fix_rvtysh_patch()
        print(mock_exec_cmd.call_args_list)
        print(mock_log_info.call_args_list)

        assert mock_exec_cmd.call_args_list == [
            call("md5sum {}/{}".format(POSTUPGRADE_ACTIONS_DATA_DIR, RVTYSH)),
            call("md5sum {}".format(RVTYSH_INSTALL_DIR))
        ]

        assert mock_log_info.call_args_list == [
            call("fix_rvtysh_patch() rvtysh script is already updated, skipping.")
        ]

    @patch('postupgrade_actions.log_info')
    @patch('postupgrade_actions.exec_cmd')
    @patch('postupgrade_actions.POSTUPGRADE_ACTIONS_DATA_DIR', POSTUPGRADE_ACTIONS_DATA_DIR)
    @patch('sonic_py_common.get_sonic_version_info', MagicMock(return_value={'build_version': '20201231.85'}))
    def test_fix_rvtysh_patch_success_update(self, mock_exec_cmd, mock_log_info):
        mock_exec_cmd.side_effect = [
            (0, 'f567b6e2019m3l3c2ed971a11f9698f0  rvtysh'),
            (0, 'f567b6e2019m3l3c2ed971a06f9698f0  {}'.format(RVTYSH_INSTALL_DIR)),
            (0, "executed: chmod a+x rvtysh"),
            (0, "executed: cp -f rvtysh"),
            (0, "executed: rvtysh show version")
        ]

        fix_rvtysh_patch()
        print(mock_exec_cmd.call_args_list)
        print(mock_log_info.call_args_list)

        assert mock_exec_cmd.call_args_list == [
            call("md5sum {}/{}".format(POSTUPGRADE_ACTIONS_DATA_DIR, RVTYSH)),
            call("md5sum {}".format(RVTYSH_INSTALL_DIR)),
            call("sudo chmod a+x {}/{}".format(POSTUPGRADE_ACTIONS_DATA_DIR, RVTYSH)),
            call("sudo cp -f {}/{} {}".format(POSTUPGRADE_ACTIONS_DATA_DIR, RVTYSH, INSTALL_DIR)),
            call("sudo rvtysh -n 0 -c 'show version'")
        ]

        assert mock_log_info.call_args_list == [
            call("fix_rvtysh_patch() updating rvtysh script."),
            call("fix_rvtysh_patch() rvtysh script is updated successfully.")
        ]

    @patch('postupgrade_actions.log_error')
    @patch('postupgrade_actions.log_info')
    @patch('postupgrade_actions.exec_cmd')
    @patch('postupgrade_actions.POSTUPGRADE_ACTIONS_DATA_DIR', POSTUPGRADE_ACTIONS_DATA_DIR)
    @patch('sonic_py_common.get_sonic_version_info', MagicMock(return_value={'build_version': '20201231.85'}))
    def test_fix_rvtysh_patch_failed_update(self, mock_exec_cmd, mock_log_info, mock_log_error):
        mock_exec_cmd.side_effect = [
            (0, 'f567b6e2019m3l3c2ed971a11f9698f0  rvtysh'),
            (0, 'f567b6e2019m3l3c2ed971a06f9698f0  {}'.format(RVTYSH_INSTALL_DIR)),
            (0, "executed: chmod a+x rvtysh"),
            (0, "executed: cp -f rvtysh"),
            (1, "executed: rvtysh show version")
        ]

        fix_rvtysh_patch()
        print(mock_exec_cmd.call_args_list)
        print(mock_log_info.call_args_list)

        assert mock_exec_cmd.call_args_list == [
            call("md5sum {}/{}".format(POSTUPGRADE_ACTIONS_DATA_DIR, RVTYSH)),
            call("md5sum {}".format(RVTYSH_INSTALL_DIR)),
            call("sudo chmod a+x {}/{}".format(POSTUPGRADE_ACTIONS_DATA_DIR, RVTYSH)),
            call("sudo cp -f {}/{} {}".format(POSTUPGRADE_ACTIONS_DATA_DIR, RVTYSH, INSTALL_DIR)),
            call("sudo rvtysh -n 0 -c 'show version'")
        ]

        assert mock_log_info.call_args_list == [
            call("fix_rvtysh_patch() updating rvtysh script.")
        ]

        assert mock_log_error.call_args_list == [
            call("fix_rvtysh_patch() rvtysh script is not updated successfully.")
        ]

    def teardown_method(self):
        print('TEAR DOWN')
