#!/usr/bin/env bash
intfs=$(show int status | grep Ethernet | awk '{print $1;}')
for intf in $intfs
do
    echo "Shutting down $intf"
    sudo config interface shutdown "$intf"
    sleep 5
done