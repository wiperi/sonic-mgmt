import json
import syslog
import sys

import argparse

# swsssdk will be deprecate after 202205
using_swsssdk = False
try:
    from swsssdk import ConfigDBConnector
    using_swsssdk = True
except ImportError:
    from swsscommon.swsscommon import ConfigDBConnector

# load_db_config added on 202205
using_load_db_config = False
try:
    from utilities_common.general import load_db_config
    using_load_db_config = True
except ImportError:
    pass

try:
    from sonic_py_common import device_info
except ImportError:
    import sonic_device_util as device_info


def get_config_db_list():
    namespaces = None
    try:
        # import SonicDBConfig inside try-catch block because SonicDBConfig not exist on 201811 version
        # SonicDBConfig must come from same package as ConfigDBConnector
        if using_swsssdk:
            from swsssdk import SonicDBConfig
        else:
            from swsscommon.swsscommon import SonicDBConfig

        if using_load_db_config:
            load_db_config()
        else:
            SonicDBConfig.load_sonic_global_db_config()

        namespaces = device_info.get_all_namespaces()
    except:
        syslog.syslog(syslog.LOG_INFO, "Not able to get all namespaces. Default fallback is host namespace only")
        pass

    config_db_list = []
    if namespaces and 'front_ns' in namespaces and namespaces['front_ns']:
        # Get front asic namespace config db connection. Applicable in Multi-npu platforms
        for front_asic_namespaces in namespaces['front_ns']:
            config_db_list.append(ConfigDBConnector(use_unix_socket_path=True, namespace=front_asic_namespaces))
    else:
        # Get global/host namespace config db connection
        config_db_list.append(ConfigDBConnector())
    return config_db_list


def create(session_name):
    """
    Create mirror session.
    """
    json_file = open(session_name + '.json')
    session_info = json.loads(json_file.read())
    config_db_list = get_config_db_list()
    for config_db in config_db_list:
        config_db.connect()
        config_db.set_entry("MIRROR_SESSION", session_name, session_info)


def delete(session_name):
    """
    Delete mirror session.
    """
    config_db_list = get_config_db_list()
    for config_db in config_db_list:
        config_db.connect()
        config_db.set_entry("MIRROR_SESSION", session_name, None)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Install mirror session using the Config DB format")
    parser.add_argument("operation", metavar="operation", type=str, help="create/delete a mirror sesion")
    parser.add_argument("session_name", metavar="session_name", type=str, help="name of mirror session to create/delete")

    args = parser.parse_args()
    if args.operation == "create":
        create(args.session_name)
    elif args.operation == "delete":
        delete(args.session_name)
    else:
        print("Invalid operation '{}' provided".format(args.operation))
        sys.exit(1)
