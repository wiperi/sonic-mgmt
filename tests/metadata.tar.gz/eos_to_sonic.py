#!/usr/bin/env python
# Copyright (c) 2018 Arista Networks, Inc.  All rights reserved.
# Arista Networks, Inc. Confidential and Proprietary.

# Version 0.22

from __future__ import print_function, with_statement

from collections import namedtuple
from pprint import pformat

import argparse
import contextlib
import fileinput
import json
import logging
import os
import re
import shutil
import socket
import subprocess
import sys
import time
import warnings
import zipfile

import requests

import PyClient
import Tac

class CONST( object ):
   ANY = 'ANY'
   FORMAT = '%(asctime)-15s %(area)-8s %(levelname)-8s %(message)s'

   # Two sources are possible for extracting SONIC image version
   # 0: version in swi; 1: .imagehash in swi
   SONIC_VER_EXTRACT = 0
   # TODO: change to the exact version before release
   SONIC_DEFAULT_VER = [ '42.0.0', 'arsonic' ]
   # TODO: set TESTING to false before release
   TESTING = True

   MIN_SPACE_VFAT = 1024 * 1000
   MIN_SPACE_EXT4 = 1024 * 2000

   FILE_VERSION = 'version'
   FILE_IMAGEHASH = '.imagehash'
   FILE_TINY_SWI = '.sonic-boot.swi'

   PLATFORM_NAMES = {
      'crow': 'Clearlake',
      'raven': 'Cloverdale',
   }

   ARP_TEST_IP = ''
   ARP_HELPER_HTTP_PORT = '85'
   ARP_HELPER_HTTPS_PORT = '448'
   ARP_UDP_PORT = '4789'
   ARP_SESSION_NAME = 'fast-reboot-from-eos'

   FERRET_NEIGHBOR_ADVERTISER_API_PREFIX = '/Ferret/NeighborAdvertiser/Slices/'
   DEFAULT_DURATION = 300
   HTTP_REQUEST_TIMEOUT = 2

   FILES_TO_KEEP_SONIC = [
      "minigraph.xml",
      "snmp.yml",
      "acl.json",
   ]

   FILES_TO_KEEP_EOS = [
      "zerotouch-config",
      "startup-config",
      "boot-config-EOS.bak",
   ]

   BOOT0_KEXEC_HOOK_FOLDER = 'platform/hooks/pre-kexec'
   BOOT0_KEXEC_HOOK_NAME = '00-eos-to-sonic-fast-reboot-hook'
   BOOT0_TMP_SUFFIX = 'fast-reboot'

   BOOT_CONFIG = '/mnt/flash/boot-config'
   BOOT_CONFIG_EOS_BAK = '/mnt/flash/boot-config-EOS.bak'

logging.basicConfig( format=CONST.FORMAT )
logger = logging.getLogger( 'eos_to_sonic' )

class IntEnum( object ):
   __EnumItem__ = namedtuple( "EnumItem", [ "name", "value" ] )
   class __metaclass__( type ):
      def __init__( cls, name, bases, dct ):
         cls.__enum_members__ = { attr: IntEnum.__EnumItem__( attr, value ) \
               for attr, value in cls.__dict__.iteritems() \
               if not attr.startswith( "__" ) }
         type.__init__( cls, name, bases, dct )

      def __iter__( cls ):
         return ( cls.__getattribute__( attr ) for attr in cls.__dict__ \
               if not attr.startswith( "__" ) )

      def __getattribute__( cls, attr ):
         if attr.startswith( "__" ):
            return object.__getattribute__( cls, attr )
         else:
            return cls.__enum_members__[ attr ]

      def __len__( cls ):
         return len( cls.__enum_members__ )

class OPERATION( IntEnum ):
   INSTALL = 0x01
   DUMP = 0x02
   ARP_HELPER = 0x03
   SHUTDOWN = 0x04
   REBOOT = 0x05
   KEXEC = 0x06

class AREA( IntEnum ):
   MAIN = 0xf01
   LIB = 0xf02
   CMD = 0xf03
   UTILS = 0xf04
   ARP = 0xf05

class ERROR( IntEnum ):
   SUCCESS = 0
   FAIL = 1
   NOT_ROOT = 2
   NOT_NTP_SYNCED = 3
   ARP_HELPER_NO_HWSKU_ARG = 4
   SONIC_MNT_PT_DNE = 5
   SONIC_SWI_DNE = 6
   FLASH_NOT_EXT4 = 7
   INSUFFICIENT_SPACE = 8
   ARP_HELPER_LB0_NO_IPV4_ADDR = 9
   ARP_HELPER_REMOTE_CONN_FAIL = 10
   PLAT_PROC_TIMEOUT = 11
   DMA_OP_CANCEL_TIMEOUT = 12
   DMA_OP_CANCEL_FAIL = 13
   EOS_VER_PARSE_FAIL = 14
   PLAT_PARSE_FAIL = 15
   SONIC_VER_PARSE_FAIL = 16
   PLAT_UNSUPPORTED = 17
   FIND_REBOOT_OPS_FAIL = 18
   FIND_INSTALLED_SONIC_IMG_FAIL = 19
   EOS_BOOT_CONFIG_CHECK_FAIL = 20
   RECOVER_TO_EOS_FAIL = 21

class Log( object ):
   def __init__( self, area ):
      self.area = area

   def debug( self, *args ):
      logger.debug( *args, extra={ 'area': self.area.name } )

   def info( self, *args ):
      logger.info( *args, extra={ 'area': self.area.name } )

   def error( self, *args ):
      logger.error( *args, extra={ 'area': self.area.name } )

   def errorAndExit( self, error, *args ):
      logger.error( *args, extra={ 'area': self.area.name } )
      sys.exit( error.value )

   def warning( self, *args ):
      logger.warning( *args, extra={ 'area': self.area.name } )

class Utils( object ):
   log = Log( AREA.UTILS )
   ansiEscape = re.compile( r'\x1B\[[0-?]*[ -/]*[@-~]' )

   @staticmethod
   def run( cmd=None, output=False, dryRun=False, ignoreRet=False, **kwargs ):
      cmd = cmd or []
      Utils.log.debug( ' '.join( cmd ) )
      if dryRun:
         Utils.log.debug( 'DRYRUN: %s', ' '.join( cmd ) )
         return ''
      try:
         if output:
            return subprocess.check_output( cmd, **kwargs ).decode( \
                                                                 'utf-8' ).rstrip()
         else:
            return subprocess.check_call( cmd, **kwargs )
      except subprocess.CalledProcessError as e:
         Utils.log.warning( "%d is returned by: %s", e.returncode, ' '.join( cmd ) )
         if ignoreRet:
            return ''
         else:
            raise e

   @staticmethod
   def runCliCmd( cmd, dryRun, output=False ):
      return Utils.run( [ 'FastCli', '-p', '15', '-c', cmd ], dryRun=dryRun,
                        output=output )

   @staticmethod
   def runShowCmd( cmd, toJson=True, grep=None ):
      assert not ( toJson and grep ), 'Wrong format for show cmd'
      cmd = ' '.join( [ 'show', cmd ] )
      if toJson:
         cmd = ' '.join( [ cmd, '|', 'json' ] )
      elif grep:
         grep = "'" + grep + "'"
         cmd = ' '.join( [ cmd, '|', 'grep', grep ] )

      output = Utils.runCliCmd( cmd, False, output=True )
      output = Utils.ansiEscape.sub( '', output )
      return json.loads( output ) if toJson else output

   @staticmethod
   def reviseParams( filename, paramsToCopy=r'.+', paramsToReplace=None,
                     paramsToAppend=None ):
      paramsToReplace = paramsToReplace or {}
      paramsToAppend = paramsToAppend or []
      for line in fileinput.input( filename, inplace=True ):
         for segment in line.split():
            split = segment.split( '=' )
            if len( split ) == 2 and split[ 0 ] in paramsToReplace:
               print( split[ 0 ] + '=' + paramsToReplace[ split[ 0 ] ] )
            elif re.search( paramsToCopy, segment ):
               print( segment )
      with open( filename, 'a' ) as fp:
         for param in paramsToAppend:
            fp.write( '%s\n' % param )

   @staticmethod
   def eosPortToSonic( port, portOffset ):
      if port == 'Management1':
         return 'eth0'
      indexes = re.findall( r'\d+', port )
      assert indexes, 'Failed to convert EOS port to SONiC'
      num = ( int( indexes[ 0 ] ) - 1 - portOffset ) * 4
      if len( indexes ) > 1:
         num += int( indexes[ 1 ] ) - 1
      return "Ethernet%d" % num

   @staticmethod
   def getInstalledSonic( dest, single=True ):
      dirs = Utils.run( [ 'find', dest, '-maxdepth', '1',
                          '-name', 'image-*' ], output=True ).splitlines()
      if single:
         if len( dirs ) != 1:
            Utils.log.errorAndExit( ERROR.FIND_INSTALLED_SONIC_IMG_FAIL,
                                    'Error to find SONiC image installed' )
         return dirs[ 0 ]
      else:
         return dirs

   @staticmethod
   def getEosSwiPathFromBootConfig( config=CONST.BOOT_CONFIG ):
      with open( config ) as f:
         for line in f.read().splitlines():
            line = line.strip()
            if line.startswith( 'SWI=flash:/' ) and 'EOS' in line:
               return '/mnt/flash/' + line[ len( 'SWI=flash:/' ) : ]
            if line.startswith( 'SWI=flash:' ) and 'EOS' in line:
               return '/mnt/flash/' + line[ len( 'SWI=flash:' ) : ]
      return None

   @staticmethod
   def readSwiFile( swi, path ):
      content = None
      with zipfile.ZipFile( swi, 'r' ) as fp:
         content = fp.read( path )
      return content

   @staticmethod
   def parseProcCmdline():
      with open( '/proc/cmdline', 'r' ) as f:
         cmdlineStr = f.read()
      cmdlineDict = {}
      for entry in cmdlineStr.split():
         pos = entry.find( '=' )
         if pos == -1:
            cmdlineDict[ entry ] = None
         else:
            cmdlineDict[ entry[ : pos ] ] = entry[ pos + 1 : ]
      return cmdlineDict

   @staticmethod
   def getFsInfo( mount ):
      lines = Utils.run( [ 'df', mount, '-kT', '--sync' ], output=True ).splitlines()
      assert len( lines ) == 2, 'Error in parsing output of df'
      items = lines[ 1 ].split()
      return { 'type': items[ 1 ], 'available': items[ 4 ] }

class MethodLib( object ):
   '''
   Library that provides operations and version control in fast-reboot

   '''
   def __init__( self ):
      self.enabledMatrix = {}
      self.opersMatrix = {}
      self.log = Log( AREA.LIB )
   def checkPlatform( self, platform, eosVersion, sonicVersion ):
      return self._getRecursive( self.enabledMatrix, platform,
                                 eosVersion, sonicVersion )

   def checkOpers( self, platform, eosVersion, sonicVersion ):
      ret = {}
      for oper in OPERATION:
         func = self._getRecursive( self.opersMatrix, oper, platform,
                                    eosVersion, sonicVersion )
         self.log.info( 'Checking %s', oper )
         if func is None:
            return None
         else:
            ret[ oper ] = func
      return ret

   def registerMethod( self, operation, platform, eosVersion, sonicVersion ):
      if not isinstance( platform, ( list, tuple ) ):
         platform = ( platform, )
      if not isinstance( eosVersion, ( list, tuple ) ):
         eosVersion = ( eosVersion, )
      def decorator( func ):
         for p in platform:
            for e in eosVersion:
               self._setRecursive( self.opersMatrix, func, operation, p,
                                   e, sonicVersion )
         return func
      return decorator

   def enableSupport( self, platform, eosVersion, sonicVersion ):
      if not isinstance( platform, ( list, tuple ) ):
         platform = ( platform, )
      if not isinstance( eosVersion, ( list, tuple ) ):
         eosVersion = ( eosVersion, )
      for p in platform:
         for e in eosVersion:
            self._setRecursive( self.enabledMatrix, True, p, e, sonicVersion )

   def _setRecursive( self, _dict, value, *keys ):
      assert keys, 'No key is given'
      for i in range( len( keys ) - 1 ):
         _dict = _dict.setdefault( keys[ i ], {} )
      assert keys[ -1 ] not in _dict, \
            'The value for key %s is already set' % keys[ -1 ]
      _dict[ keys[ -1 ] ] = value

   def _getRecursive( self, _dict, *keys ):
      assert keys, 'No key is given'
      result = _dict
      for key in keys:
         if result is None:
            return None
         if CONST.ANY in result:
            result = result[ CONST.ANY ]
         elif key in result:
            result = result[ key ]
         else:
            return None
      return result


EOS_4_18_3 = [
   '4.18.3.1F',
]

EOS_4_19_5 = [
   '4.19.5M',
]

EOS_4_20_3 = [
   '4.20.3F',
]

EOS_4_21_2 = [
   '4.21.2.3F',
   '4.21.2.6F',
]

EOS_4_21_6 = [
   '4.21.6.2F',
   '4.21.6.3F',
]

lib = MethodLib()
lib.enableSupport( [ 'Gardena', 'UpperlakeES', 'Upperlake' ],
                   EOS_4_20_3 + EOS_4_21_2 + EOS_4_21_6,
                   CONST.SONIC_DEFAULT_VER[ CONST.SONIC_VER_EXTRACT ] )
lib.enableSupport( [ 'Cloverdale', 'Clearlake', 'ClearlakeSsd' ],
                   EOS_4_18_3 + EOS_4_19_5 + EOS_4_20_3 + EOS_4_21_2,
                   CONST.SONIC_DEFAULT_VER[ CONST.SONIC_VER_EXTRACT ] )

@lib.registerMethod( OPERATION.INSTALL,
                     [ 'Cloverdale', 'Clearlake', 'ClearlakeSsd' ],
                     EOS_4_18_3 + EOS_4_19_5 + EOS_4_20_3 + EOS_4_21_2,
                     CONST.ANY )
def installVfat( swi, dest, dryRun ):
   boot0Env = dict( os.environ, swipath=swi, target_path=dest,
                    install='true' )
   extraParams = [ "pcie_ports", "tsc", "log_buf_len" ]
   _installCommon( swi, dest, boot0Env, extraParams, fsType='vfat',
                   cleanAll=True, dryRun=dryRun )

@lib.registerMethod( OPERATION.INSTALL, [ 'UpperlakeES', 'Upperlake' ],
                     EOS_4_20_3 + EOS_4_21_2 + EOS_4_21_6,
                     CONST.ANY )
def installUpperlake( swi, dest, dryRun ):
   log = Log( OPERATION.INSTALL )
   # Check ext4
   log.info( 'Checking the flash is ext4' )
   if not dryRun:
      if Utils.getFsInfo( dest )[ 'type' ] != 'ext4':
         log.errorAndExit( ERROR.FLASH_NOT_EXT4,
                           '%s is not formatted as ext4', dest )
   # Install files
   boot0Env = dict( os.environ, swipath=swi, target_path=dest,
                    sonic_upgrade='true', install='true' )
   extraParams = [ "dmamem", "amd", "reassign_prefmem", "scd", "sid" ]
   _installCommon( swi, dest, boot0Env, extraParams, dryRun=dryRun )

@lib.registerMethod( OPERATION.INSTALL, [ 'Gardena' ],
                     EOS_4_20_3 + EOS_4_21_2 + EOS_4_21_6,
                     CONST.ANY )
def installGardena( swi, dest, dryRun ):
   log = Log( OPERATION.INSTALL )
   # Check ext4
   log.info( 'Checking the flash is ext4' )
   if not dryRun:
      if Utils.getFsInfo( dest )[ 'type' ] != 'ext4':
         log.errorAndExit( ERROR.FLASH_NOT_EXT4,
                           '%s is not formatted as ext4', dest )
   # Install files
   boot0Env = dict( os.environ, swipath=swi, target_path=dest,
                    sonic_upgrade='true', install='true' )
   extraParams = [ "dmamem", "amd", "reassign_prefmem", "scd", "sid", "iommu",
                   "intel_iommu", "tsc", "pcie_ports", "rhash_entries",
                   "usb-storage" ]
   _installCommon( swi, dest, boot0Env, extraParams, dryRun=dryRun )

def _installCommon( swi, dest, boot0Env, extraParams='', fsType='ext4',
                    cleanAll=False, dryRun=False ):
   log = Log( OPERATION.INSTALL )
   # Cleanup installed sonic files
   dirs = Utils.getInstalledSonic( dest, single=False )
   for item in dirs:
      log.info( "Removing old sonic file %s", item )
      Utils.run( [ 'rm', '-rf', item ] )

   # Backup boot-config and check EOS swi existing
   eosSwiPath = Utils.getEosSwiPathFromBootConfig()
   if not eosSwiPath or not os.path.isfile( eosSwiPath ):
      log.errorAndExit( ERROR.EOS_BOOT_CONFIG_CHECK_FAIL,
                        'Failed on the boot-config check: %s' % eosSwiPath )
   Utils.run( [ 'cp', CONST.BOOT_CONFIG, CONST.BOOT_CONFIG_EOS_BAK ] )

   # Cleanup all files
   if cleanAll:
      filesToKeep = CONST.FILES_TO_KEEP_SONIC + CONST.FILES_TO_KEEP_EOS + \
                    [ os.path.basename( eosSwiPath ) ]
      files = Utils.run( [ 'find', dest, '-maxdepth', '1', '!',
                           '-path', dest ], output=True )
      for item in files.splitlines():
         if os.path.basename( item ) not in filesToKeep:
            log.info( "Removing file %s", item )
            Utils.run( [ 'rm', '-rf', item ] )

   # Check space left
   minSpace = CONST.MIN_SPACE_EXT4 if fsType == 'ext4' else CONST.MIN_SPACE_VFAT
   if Utils.getFsInfo( dest )[ 'available' ] < minSpace:
      log.errorAndExit( ERROR.INSUFFICIENT_SPACE, 'Not enough space on %s', dest )

   # Run boo0
   log.info( 'Running boot0' )
   Utils.run( [ 'unzip', '-o', swi, 'boot0', '-d', '/tmp' ] )
   Utils.run( [ 'chmod', '+x', '/tmp/boot0' ] )
   Utils.run( [ '/tmp/boot0' ], env=boot0Env )

   # Obtain current MAC address
   files = Utils.run( [ 'find', '/sys/class/net', '-maxdepth', '1',
                        '-name', 'et1*' ], output=True )
   item = files.splitlines()[ 0 ]
   macAddr = Utils.run( [ 'cat', '%s/address' % item ], output=True )

   # Prepare kernel params
   params = [ "hwaddr", "reboot", "console", "acpi", "Aboot", "platform", "block",
              "net", "varlog", "rw", "loop", "loopfstype", "apparmor", "security",
              "quiet", "root", "modprobe", "docker_inram",
              "systemd.unified_cgroup_hierarchy" ]
   kernelParamsToCopy = '|'.join( params + extraParams )
   kernelParamsToModify = { 'hwaddr_ma1': macAddr }

   # Revise kernel-params-base, kernel-cmdline and /tmp/append
   log.info( 'Updating kernel params' )

   ## Prepare paths for revised files
   installPath = Utils.getInstalledSonic( dest )
   cmdlineBase = os.path.join( dest, 'kernel-params-base' )
   cmdlineImage = os.path.join( installPath, 'kernel-cmdline' )
   cmdlineAppend = '/tmp/append'
   cmdlineBaseCopy = '/tmp/kernel-params-base-%s' % CONST.BOOT0_TMP_SUFFIX
   cmdlineImageCopy = '/tmp/kernel-cmdline-%s' % CONST.BOOT0_TMP_SUFFIX
   cmdlineAppendCopy = '/tmp/append-%s' % CONST.BOOT0_TMP_SUFFIX
   revisedFiles = [
      ( cmdlineBase, cmdlineBaseCopy ),
      ( cmdlineImage, cmdlineImageCopy ),
      ( cmdlineAppend, cmdlineAppendCopy ),
   ]

   ## Modify the files and make copy
   for srcFile, copyFile in revisedFiles:
      if os.path.isfile( srcFile ):
         Utils.reviseParams( srcFile, r"^(%s)" % kernelParamsToCopy,
                             kernelParamsToModify, [] )
         shutil.copy( srcFile, copyFile )

   ## Create hook file
   hookPath = os.path.join( installPath, CONST.BOOT0_KEXEC_HOOK_FOLDER )
   hookFile = os.path.join( hookPath, CONST.BOOT0_KEXEC_HOOK_NAME )
   Utils.run( [ 'mkdir', '-p', hookPath ] )
   with open( hookFile, 'w' ) as f:
      for srcFile, copyFile in revisedFiles:
         if os.path.isfile( srcFile ):
            f.write( 'cp -f %s %s || :\n' % ( copyFile, srcFile ) )
      f.write( 'rm -f %s || :\n' % hookFile )

   Utils.run( [ 'sync' ] )

@lib.registerMethod( OPERATION.KEXEC, CONST.ANY, CONST.ANY, CONST.ANY )
def kexecCommon( dest, dryRun ):
   log = Log( OPERATION.KEXEC )
   log.info( 'Fast-rebooting to SONiC' )
   Utils.run( [ 'sync' ] )
   time.sleep( 2 )
   env = dict( os.environ, kexec='true', target_path=dest,
               ENV_EXTRA_CMDLINE='SONIC_BOOT_TYPE=fast-reboot prev_os=eos' )
   Utils.run( [ '/tmp/boot0' ], env=env, dryRun=dryRun )

@lib.registerMethod( OPERATION.REBOOT, CONST.ANY, CONST.ANY, CONST.ANY )
def rebootCommon( dryRun ):
   log = Log( OPERATION.REBOOT )
   log.info( 'Rebooting to SONiC' )
   Utils.run( [ 'sync' ] )
   time.sleep( 2 )
   Utils.run( [ 'reboot' ], dryRun=dryRun )

class ArpHelper( object ):
   def __init__( self, serviceIps, httpPort, httpsPort, hwSku, tcamRules, dryRun ):
      self.log = Log( AREA.ARP )

      # From arguments or default const
      self.vxlanUdp = CONST.ARP_UDP_PORT
      self.session = CONST.ARP_SESSION_NAME
      self.dryRun = dryRun
      self.hwSku = hwSku
      self.tcamRules = tcamRules
      self.serviceIps = serviceIps
      self.httpPort = httpPort
      self.httpsPort = httpsPort

      # From running state
      self.hostName = None
      self.loIpV4 = None
      self.loIpV6 = None
      self.ports = set()
      self.vlans = {}
      self.unusedIntf = None
      self.recircIntfId = None
      self.vxlanIntfId = None

      # From response of remote service
      self.remoteIp = None

   def prepare( self ):
      # Get hostname
      self.hostName = Utils.runShowCmd( 'hostname' )[ 'hostname' ]

      # Get IP of Loopback0
      intfs = Utils.runShowCmd( 'ip interface Lo0' )[ 'interfaces' ]
      lo0 = intfs.get( 'Loopback0' )
      if lo0 is not None:
         self.loIpV4 = lo0[ 'interfaceAddress' ][ 'primaryIp' ][ 'address' ]
      if not self.loIpV4:
         self.log.errorAndExit( ERROR.ARP_HELPER_LB0_NO_IPV4_ADDR,
                                'ARP helper: IPv4 address for Loopback0 not found' )

      intfs = Utils.runShowCmd( 'ipv6 interface Lo0' )[ 'interfaces' ]
      lo0 = intfs.get( 'Loopback0' )
      if lo0 is not None:
         self.loIpV6 = lo0[ 'addresses' ][ 0 ][ 'address' ]
      if not self.loIpV6:
         self.log.warning( 'IPv6 address for Loopback0 is not found' )

      # Get vlan intfs and their ip
      intfs = Utils.runShowCmd( 'ip interface vlan 1-$' )[ 'interfaces' ]
      for intf in intfs:
         if not intf.startswith( 'Vlan' ):
            continue
         vlanId = intf[ 4: ]
         vlan = self.vlans.setdefault( vlanId, { 'ipv4': [],
                                                 'ipv6': [],
                                                 'vxlanId': vlanId,
                                                 'mac': None,
                                               } )
         vlan[ 'ipv4' ].append( intfs[ intf ][ 'interfaceAddress' ][ 'primaryIp' ]\
               [ 'address' ] )

      intfs = Utils.runShowCmd( 'ipv6 interface vlan 1-$' )[ 'interfaces' ]
      for intf in intfs:
         if not intf.startswith( 'Vlan' ):
            continue
         vlanId = intf[ 4: ]
         vlan = self.vlans.setdefault( vlanId, { 'ipv4': [],
                                                 'ipv6': [],
                                                 'vxlanId': vlanId,
                                                 'mac': None,
                                               } )
         for addr in intfs[ intf ][ 'addresses' ]:
            vlan[ 'ipv6' ].append( addr[ 'address' ] )

      # Get all ports under vlans obtained above
      for vlanId, vlan in self.vlans.iteritems():
         vlan[ 'mac' ] = Utils.run( [ 'cat', "/sys/class/net/vlan%s/address" % \
               vlanId ], output=True )
         output = Utils.runShowCmd( 'vlan %s configured-ports' % vlanId  )
         for port in output[ 'vlans' ][ vlanId ][ 'interfaces' ]:
            if port.startswith( 'Ethernet' ):
               self.ports.add( port )

      # Get unused intf
      intfs = Utils.runShowCmd( 'interface description' )[ 'interfaceDescriptions' ]
      self.unusedIntf = next( key for key, value in intfs.iteritems() if \
            key.startswith( 'Ethernet' ) and value[ 'interfaceStatus' ] == 'down' \
            and key not in self.ports )

      # Get recird id
      recircIntfIds = [ int( filter( unicode.isdigit, key ) ) \
            for key in intfs if key.startswith( 'Recirc-Channel' ) ]
      self.recircIntfId = max( recircIntfIds or [ 0 ] ) + 1

      # Get vxlan id
      vxlanIntfIds = [ int( filter( unicode.isdigit, key ) ) \
            for key in intfs if key.startswith( 'Vxlan' ) ]
      self.vxlanIntfId = max( vxlanIntfIds or [ 0 ] ) + 1

   def setupLocal( self ):
      # GreEnSpan
      configAccess = [
         'mac access-list arp-filter',
         '10 permit any any arp payload offset 1 pattern 0x00000001 mask 0xffff0000',
         '20 permit any any ipv6 payload offset 10 pattern 0x87000000 '
               'mask 0x00ffffff',
      ]
      header = 'monitor session %s' % self.session
      configGre = [
         '%s source %s rx mac access-group arp-filter' % ( header, intf ) \
               for intf in self.ports
      ] + [
         '%s destination tunnel mode gre source %s destination %s' \
               % ( header, self.loIpV4, self.remoteIp )
      ]

      # vxlan
      configRecirc = [
         'int Recirc-Channel%d' % self.recircIntfId,
         'no switchport',
         'switchport recirculation features vxlan'
      ]
      configEt = [
         'default int %s' % self.unusedIntf,
         'int %s' % self.unusedIntf,
         'traffic-loopback source system device mac',
         'channel-group recirculation %d' % self.recircIntfId
      ]
      configVxlan = [
         'int Vxlan%d' % self.vxlanIntfId,
         'vxlan source-interface Loopback0',
         'vxlan udp-port %s' % self.vxlanUdp,
      ]
      for vlanId, vlan in self.vlans.iteritems():
         configVxlan.append( 'vxlan vlan %s vni %s' % ( vlanId,
                                                        vlan[ 'vxlanId' ] ) )
         configVxlan.append( 'vxlan vlan %s flood vtep %s' % ( vlan[ 'vxlanId' ],
                                                               self.remoteIp ) )

      # Apply the configs
      for config in [ configAccess, configGre, configRecirc, configEt, configVxlan ]:
         cmd = '\n'.join( [ 'config' ] + config + [ 'end' ] )
         Utils.runCliCmd( cmd, self.dryRun )


      # Disable vxlan tcam
      def disableVxlanTcam():
         output = Utils.runShowCmd( 'platform trident tcam detail', toJson=False,
                                    grep='hits - Vxlan tunneled ARP pkt - Trap CPU' )
         disabled = 0
         for line in output.splitlines():
            match = re.search( r'\d+', line )
            assert match, 'Failed to parse the tcam line: ' + line
            cmd = ' '.join( [ 'pl tri diag fp entry disable', match.group() ] )
            Utils.runCliCmd( cmd, self.dryRun )
            disabled += 1
         return disabled == self.tcamRules

      try:
         Tac.waitFor( disableVxlanTcam,
                      description="vxlan arp tcam rules",
                      maxDelay=0.1, sleep=True, timeout=30 )
      except Tac.Timeout:
         Utils.log.warning( 'Not found vxlan tcam to disable' )

   def populateRequest( self ):
      switchInfo = {
         'name': self.hostName,
         'ipv4Addr': self.loIpV4,
         'ipv6Addr': self.loIpV6,
         'hwSku': self.hwSku
      }

      respondingSchemes = {
         'durationInSec': CONST.DEFAULT_DURATION
      }

      vlanInfo = []
      for vlanId, vlan in self.vlans.iteritems():
         ipv4Mappings = [ { 'ipAddr': addr,
                            'macAddr': vlan[ 'mac' ],
                          } for addr in vlan[ 'ipv4' ] ]
         ipv6Mappings = [ { 'ipAddr': addr,
                            'macAddr': vlan[ 'mac' ],
                          } for addr in vlan[ 'ipv6' ] ]
         vlanIntf = {
            'vlanId': vlanId,
            'vxlanId': vlan[ 'vxlanId' ],
            'ipv4AddrMappings': ipv4Mappings,
            "ipv6AddrMappings": ipv6Mappings
         }
         vlanInfo.append( vlanIntf )

      data = {
         'switchInfo': switchInfo,
         'vlanInterfaces': vlanInfo,
         'respondingSchemes': respondingSchemes
      }

      if logger.getEffectiveLevel() <= logging.DEBUG:
         self.log.debug( pformat( data ) )
      return data

   def requestService( self, httpEnd, httpsEnd, contents ):
      resp = None
      headers = { 'content-type': 'application/json' }

      original_socket = socket.socket
      def bound_socket( *a, **k ):
         sock = original_socket( *a, **k )
         sock.bind( ( self.loIpV4, 0 ) )
         return sock

      socket.socket = bound_socket

      try:
         with warnings.catch_warnings():
            warnings.simplefilter( 'ignore' )
            resp = requests.post( httpsEnd, data=json.dumps( contents ),
                                  headers=headers,
                                  verify=False, # nosec B501
                                  timeout=CONST.HTTP_REQUEST_TIMEOUT )
            if not resp:
               raise RuntimeError( "No response obtained from HTTPS endpoint" )
            resp.raise_for_status()
      except Exception as e: # pylint: disable=broad-except
         self.log.info( "Connecting HTTPS endpoint failed, error: %s, " \
                        "trying HTTP...", str( e ) )
         resp = requests.post( httpEnd, data=json.dumps( contents ),
                               headers=headers,
                               timeout=CONST.HTTP_REQUEST_TIMEOUT )
         if not resp:
            raise RuntimeError( "No response obtained from HTTP endpoint" )
         resp.raise_for_status()
      finally:
         socket.socket = original_socket
      return resp

   def setupRemote( self ):
      data = self.populateRequest()

      if CONST.TESTING and CONST.ARP_TEST_IP:
         self.remoteIp = CONST.ARP_TEST_IP
         return

      for ip in self.serviceIps.split( ',' ):
         httpEnd = 'http://' + ip.strip() + ':' + self.httpPort  + \
                   CONST.FERRET_NEIGHBOR_ADVERTISER_API_PREFIX + self.hostName
         httpsEnd = 'https://' + ip.strip() + ':' + self.httpsPort  + \
                    CONST.FERRET_NEIGHBOR_ADVERTISER_API_PREFIX + self.hostName
         try:
            resp = self.requestService( httpEnd, httpsEnd, data )
         except Exception as e: # pylint: disable=broad-except
            self.log.warning( "The request failed, ip: %s, error: %s",
                              ip, str( e ) )
            continue

         reply = json.loads( resp.content )
         self.remoteIp = reply[ 'ipv4Addr' ]
         return

      self.log.errorAndExit( ERROR.ARP_HELPER_REMOTE_CONN_FAIL,
                             'ARP helper: Could not establish remote connection' )

   def run( self ):
      self.prepare()
      self.setupRemote()
      self.setupLocal()

@lib.registerMethod( OPERATION.DUMP,
                     [ 'Clearlake', 'ClearlakeSsd' ],
                     EOS_4_18_3 + EOS_4_19_5 + EOS_4_20_3 + EOS_4_21_2,
                     CONST.ANY )
def dump_4_20_3F_Clearlake( dest, dryRun ):
   _dump_4_20_3F( dest, dryRun, portOffset=4 )

@lib.registerMethod( OPERATION.DUMP,
                     [ 'Cloverdale' ],
                     EOS_4_18_3 + EOS_4_19_5 + EOS_4_20_3 + EOS_4_21_2,
                     CONST.ANY )
@lib.registerMethod( OPERATION.DUMP,
                     [ 'Gardena', 'UpperlakeES', 'Upperlake' ],
                     EOS_4_20_3 + EOS_4_21_2 + EOS_4_21_6,
                     CONST.ANY )
def dump_4_20_3F_Common( dest, dryRun ):
   _dump_4_20_3F( dest, dryRun )

def _dump_4_20_3F( dest, dryRun, portOffset=0 ):
   log = Log( OPERATION.DUMP )

   # 001c.735f.0000 to 00:1c:73:5f:00:00
   def convertMac( mac ):
      tmp = mac.replace( '.', '' )
      output = ':'.join( tmp[ i: i+2 ] for i in range( 0, len( tmp ), 2 ) )
      return output

   def generateArpEntries( filename, allAvailableMacs ):
      arpOutput = []
      cmds = [
         ( 'arp', '4' ),
         ( 'ipv6 neighbors', '6' ),
      ]
      for cmd, version in cmds:
         jsonObj = Utils.runShowCmd( cmd )
         for entry in jsonObj[ 'ipV%sNeighbors' % version ]:
            vlanName = entry[ 'interface' ].split( ',' )[ 0 ]
            ipAddr = entry[ 'address' ]
            mac = convertMac( entry[ 'hwAddress' ].lower() )
            if ( vlanName, mac ) not in allAvailableMacs:
               continue
            obj = {
               'NEIGH_TABLE:%s:%s' % ( vlanName, ipAddr ): {
                  'neigh': '%s' % mac,
                  'family': 'IPv%s' % version,
               },
               'OP': 'SET'
            }
            arpOutput.append( obj )

      with open( filename, 'w' ) as fp:
         json.dump( arpOutput, fp, indent=2, separators=( ',', ': ' ) )

   # TODO: unicast only now (multicast?)
   def generateFdbEntries( filename ):
      fdbEntries = []
      allAvailableMacs = set()
      jsonObj = Utils.runShowCmd( 'mac address-table' )
      for entry in jsonObj[ 'unicastTable' ][ 'tableEntries' ]:
         vlanId = entry[ 'vlanId' ]
         mac = entry[ 'macAddress' ].lower()
         fdbMac = entry[ 'macAddress' ].upper().replace( ':', '-' )
         fdbType = entry[ 'entryType' ]
         #eosPort = entry[ 'interface' ]
         fdbPort = Utils.eosPortToSonic( entry[ 'interface' ], portOffset )
         vlan = 'Vlan%d' % vlanId
         obj = {
            'FDB_TABLE:%s:%s' % ( vlan, fdbMac ): {
               'type': fdbType,
               'port': fdbPort,
            },
            'OP': 'SET'
         }
         allAvailableMacs.add( ( vlan, mac ) )
         fdbEntries.append( obj )

      with open( filename, 'w' ) as fp:
         json.dump( fdbEntries, fp, indent=2, separators=( ',', ': ' ) )
      return allAvailableMacs

   def getDefaultEntries( route ):
      jsonObj = Utils.runShowCmd( 'ip route' )
      routes = jsonObj[ 'vrfs' ][ 'default' ][ 'routes' ]
      if route not in routes:
         return None

      # TODO: only the first route in vias (multiple supported?)
      vias = routes[route][ 'vias' ][ 0 ]
      obj = {
         "ROUTE_TABLE:%s" % route: {
            #TODO: return NULL if field not provided (handled in sonic?)
            'ifname': Utils.eosPortToSonic( vias.get( 'interface', 'NULL' ),
                                            portOffset ),
            'nexthop': vias.get( 'nexthopAddr', 'NULL' )
         },
         'OP': 'SET'
      }
      return obj

   def generateDefaultRouteEntries( filename ):
      defaultRoutesOutput = []

      ipv4Default = getDefaultEntries( '0.0.0.0/0' )
      if ipv4Default is not None:
         defaultRoutesOutput.append( ipv4Default )

      ipv6Default = getDefaultEntries( '::/0' )
      if ipv6Default is not None:
         defaultRoutesOutput.append( ipv6Default )

      with open( filename, 'w' ) as fp:
         json.dump( defaultRoutesOutput, fp, indent=2, separators=( ',', ': ' ) )

   log.info( 'Dumping state of EOS' )
   folder = os.path.join( dest, 'fast-reboot' )
   Utils.run( [ 'rm', '-rf', folder ] )
   Utils.run( [ 'mkdir', folder ] )
   allAvailableMacs = generateFdbEntries( os.path.join( folder, 'fdb.json' ) )
   generateArpEntries( os.path.join( folder, 'arp.json' ), allAvailableMacs )
   generateDefaultRouteEntries( os.path.join( folder, 'default_routes.json' ) )

   if logger.getEffectiveLevel() <= logging.DEBUG:
      for filename in [ "fdb.json", "arp.json", "default_routes.json" ]:
         with open( os.path.join( folder, filename ), 'r' ) as fp:
            log.debug( '%s: %s', filename, fp.read() )

@lib.registerMethod( OPERATION.ARP_HELPER,
                     [ 'Gardena', 'UpperlakeES', 'Upperlake' ],
                     EOS_4_20_3 + EOS_4_21_2 + EOS_4_21_6,
                     CONST.ANY )
def arpHelperTcam4( dest, arpHelperIPs, httpPort, httpsPort, hwSku, dryRun ):
   _arpHelper( dest, arpHelperIPs, httpPort, httpsPort, hwSku, dryRun, tcamRules=4 )

@lib.registerMethod( OPERATION.ARP_HELPER,
                     [ 'Cloverdale', 'Clearlake', 'ClearlakeSsd' ],
                     EOS_4_18_3 + EOS_4_19_5 + EOS_4_20_3 + EOS_4_21_2,
                     CONST.ANY )
def arpHelperTcam1( dest, arpHelperIPs, httpPort, httpsPort, hwSku, dryRun ):
   _arpHelper( dest, arpHelperIPs, httpPort, httpsPort, hwSku, dryRun, tcamRules=1 )

def _arpHelper( dest, arpHelperIPs, httpPort, httpsPort, hwSku,
                dryRun, tcamRules=1 ):
   log = Log( OPERATION.ARP_HELPER )
   if logger.getEffectiveLevel() <= logging.DEBUG:
      log.debug( 'Saving eos config before arp helper' )
      output = Utils.runShowCmd( 'running-config', toJson=False )
      with open( os.path.join( dest, 'eos_config.before.bak' ), 'w' ) as fp:
         fp.write( output )
         fp.write( '\n' )

   ArpHelper( arpHelperIPs, httpPort, httpsPort, hwSku, tcamRules, dryRun ).run()

   if logger.getEffectiveLevel() <= logging.DEBUG:
      log.debug( 'Saving eos config after arp helper' )
      output = Utils.runShowCmd( 'running-config', toJson=False )
      with open( os.path.join( dest, 'eos_config.after.bak' ), 'w' ) as fp:
         fp.write( output )
         fp.write( '\n' )

@lib.registerMethod( OPERATION.SHUTDOWN,
                     [ 'Cloverdale', 'Clearlake', 'ClearlakeSsd' ],
                     EOS_4_18_3 + EOS_4_19_5,
                     CONST.ANY )
def shutdown_4_19_5M( dryRun ):
   shutdown_common( 'cell/1/stage/shutdown/config/config', dryRun )


@lib.registerMethod( OPERATION.SHUTDOWN,
                     [ 'Gardena', 'UpperlakeES', 'Upperlake',
                       'Cloverdale', 'Clearlake', 'ClearlakeSsd' ],
                     EOS_4_20_3 + EOS_4_21_2 + EOS_4_21_6,
                     CONST.ANY )
def shutdown_4_20_3F( dryRun ):
   shutdown_common( 'cell/1/stageEnable/shutdown', dryRun )

def shutdown_common( shutdownEnabledPath, dryRun  ):
   log = Log( OPERATION.SHUTDOWN )
   # Stop service manager and watchdog
   log.info( "Stopping proc manager" )
   Utils.run( [ 'service', 'ProcMgr', 'stoppm' ], dryRun=dryRun )
   log.info( "Stopping watchdog" )
   Utils.run( [ 'watchdog', '-s' ], dryRun=dryRun )

   # Enable shutdown
   pc = PyClient.PyClient( "ar", "Sysdb" )
   sysdb = pc.agentRoot()

   log.info( "Pre steps of shutdown" )
   shutdownEnabledConfig = reduce( ( lambda x, y: x[ y ] ),
                                   [ sysdb ] + shutdownEnabledPath.split( '/' ) )

   shutdownStatus = sysdb[ "cell" ][ "1" ][ "stage" ][ "shutdown" ][ "status" ]
   defaultStageInstance = Tac.Type( "Stage::StageInstance" ).defaultName
   if dryRun:
      log.debug( 'DRYRUN: Enable shutdown' )
   else:
      shutdownEnabledConfig.enabled[ defaultStageInstance ] = True
      try:
         instStatus = shutdownStatus.instStatus
         Tac.waitFor( lambda: defaultStageInstance in instStatus and \
                              instStatus[ defaultStageInstance ].complete,
                      description="platform processing",
                      maxDelay=0.1, sleep=True, timeout=150 )
      except Tac.Timeout:
         log.errorAndExit( ERROR.PLAT_PROC_TIMEOUT,
                           'Timeout in platform processing' )

   # Kill forwarding agents
   log.info( "Killing forwarding agents" )
   asuHwStatus = sysdb[ "asu" ][ "hardware" ][ "status" ]
   agentsToKill = []
   for agent, valid in asuHwStatus.forwardingAgent.iteritems():
      if valid and ( agent != "" ):
         agentsToKill.append( agent )
   if agentsToKill:
      Utils.run( [ 'killall' ] + agentsToKill, dryRun=dryRun )

   # Cancel DMA operations
   log.info( "Cancelling dma operations" )
   asuCliConfig = sysdb[ "asu" ][ "cli" ][ "config" ]
   asuStatusDmaCancel = sysdb[ "asu" ][ "status" ][ "dmaCancel" ]
   if dryRun:
      log.debug( 'DRYRUN: Cancel DMA' )
   else:
      asuCliConfig.dmaCancelInitiated = True
      try:
         Tac.waitFor( lambda: asuStatusDmaCancel.asuDmaCancelComplete,
                      description="dma quiesce",
                      maxDelay=0.1, sleep=True, timeout=60 )
      except Tac.Timeout:
         log.errorAndExit( ERROR.DMA_OP_CANCEL_TIMEOUT,
                           'Timeout to cancel DMA operations' )
      if not asuStatusDmaCancel.asuDmaCancelSuccess:
         log.errorAndExit( ERROR.DMA_OP_CANCEL_FAIL,
                           'Failed to cancel DMA operations' )

   # Sync system time to hwclock
   Utils.run( [ 'hwclock', '-w' ], ignoreRet=True )

   # Obtain front port MAC address
   files = Utils.run( [ 'find', '/sys/class/net', '-maxdepth', '1',
                        '-name', 'et1*' ], output=True )
   item = files.splitlines()[ 0 ]
   macAddr = Utils.run( [ 'cat', '%s/address' % item ], output=True )

   output = Utils.run( [ 'find', '/sys/class/net', '-maxdepth', '1',
                         '-name', 'ma*' ], output=True )
   for line in output.splitlines():
      intf = os.path.basename( line )
      # Change management port MAC address and advertise it to neighbors
      # This is to keep the MAC of front ports unchanged between EOS and SONiC
      if intf == 'ma1':
         try:
            ipV4Addr = None
            ipInfo = Utils.run( [ 'ip', 'addr', 'show', 'dev', intf ], output=True )
            for l in ipInfo.splitlines():
               match = re.match( r'.*inet ([\d.]+)', l )
               if match:
                  ipV4Addr = match.group( 1 )
                  break
            Utils.run( [ 'ip', 'link', 'set', intf, 'address', macAddr ],
                       dryRun=dryRun )
            if ipV4Addr:
               Utils.run( [ 'arping', '-I', intf, '-c', '3', '-A', ipV4Addr ] )
         except Exception as e: # pylint: disable=broad-except
            # Because the shutdown has been done, it is preferred to continue the
            # update process rather than being blocked by any exception here
            log.warning( 'Exception in change mac of %s: %s', intf, str( e ) )

      # Shutdown management port
      if intf.startswith( 'ma' ):
         Utils.run( [ 'ip', 'link', 'set', intf, 'down' ], dryRun=dryRun )

class App( object ):
   '''
   Provide interfaces to the main function
   '''
   def __init__( self, swi, dest, eosVer, sonicVer, platform ):
      self.swi = swi
      self.dest = dest
      self.log = Log( AREA.MAIN )
      self._checkEos( eosVer, platform )
      self._checkSonic( sonicVer )
      self._initOpers()
      self.arpHelperIPs = None
      self.arpHelperHttpPort = None
      self.arpHelperHttpsPort = None
      self.hwSku = None

   def setArpHelper( self, arpHelperIPs, hwSku,
                     arpHelperHttpPort, arpHelperHttpsPort ):
      self.arpHelperIPs = arpHelperIPs
      self.arpHelperHttpPort = arpHelperHttpPort
      self.arpHelperHttpsPort = arpHelperHttpsPort
      self.hwSku = hwSku

   def _checkEos( self, forcedEosVer, forcedPlatform ):
      self.log.info( 'Checking EOS version ...' )
      if forcedEosVer:
         self.eosVer = forcedEosVer
         self.log.info( 'Checking EOS version ... forced %s', self.eosVer )
      else:
         output = Utils.run( [ 'grep', 'SWI_VERSION', '/etc/swi-version' ],
                             output=True )
         items = output.split( '=' )
         if len( items ) < 2:
            self.log.errorAndExit( ERROR.EOS_VER_PARSE_FAIL,
                                   'Failed to parse EOS version' )
         self.eosVer = items[ 1 ]
         self.log.info( 'Checking EOS version ... %s', self.eosVer )

      self.log.info( 'Checking device platform ...' )
      if forcedPlatform:
         self.platform = forcedPlatform
         self.log.info( 'Checking device platform ... forced %s', self.platform )
      else:
         cmdlineDict = Utils.parseProcCmdline()
         self.platform = cmdlineDict.get( 'sid', None )
         if self.platform is None:
            platform = cmdlineDict.get( 'platform', None )
            if platform and platform in CONST.PLATFORM_NAMES:
               self.platform = CONST.PLATFORM_NAMES[ platform ]
            else:
               self.log.errorAndExit( ERROR.PLAT_PARSE_FAIL,
                                      'Failed to determine platform for the switch' )
         self.log.info( 'Checking device platform ... %s', self.platform )

   def _checkSonic( self, forcedSonicVer ):
      self.log.info( 'Checking SONiC version ...' )
      if forcedSonicVer:
         self.sonicVer = forcedSonicVer
         self.log.info( 'Checking SONiC version ... forced %s', self.sonicVer )
         return

      self.sonicVer = None
      if CONST.SONIC_VER_EXTRACT == 0:  # file version in the swi
         content = Utils.readSwiFile( self.swi, CONST.FILE_VERSION )
         for line in content.splitlines():
            items = line.split( '=' )
            if len( items ) == 2 and items[ 0 ] == 'SWI_VERSION':
               self.sonicVer = items[ 1 ]
               break
      elif CONST.SONIC_VER_EXTRACT == 1: # file .imagehash in the swi
         content = Utils.readSwiFile( self.swi, CONST.FILE_IMAGEHASH )
         self.sonicVer = content.strip()
         if CONST.TESTING:
            self.sonicVer = re.findall( r'\w+', self.sonicVer )[ 0 ]

      if self.sonicVer is None:
         self.log.errorAndExit( ERROR.SONIC_VER_PARSE_FAIL,
                                'Failed to parse SONiC image version' )
      self.log.info( 'Checking SONiC version ... %s', self.sonicVer )

   def _initOpers( self ):
      self.log.info( 'Checking platform support' )
      support = lib.checkPlatform( self.platform, self.eosVer, self.sonicVer )
      if not support:
         self.log.errorAndExit( ERROR.PLAT_UNSUPPORTED,
                                'The system version is not supported' )

      self.log.info( 'Checking operations' )
      self.opers = lib.checkOpers( self.platform, self.eosVer, self.sonicVer )
      if not self.opers or len( self.opers ) != len( OPERATION ):
         self.log.errorAndExit( ERROR.FIND_REBOOT_OPS_FAIL,
                                'Error in finding all operations' )

   def _recoverToEos( self ):
      # Check startup-config existing
      if not os.path.isfile( "/mnt/flash/startup-config" ):
         self.log.errorAndExit( ERROR.RECOVER_TO_EOS_FAIL,
                                "Unable to recover startup-config" )

      # Check boot-config backup existing
      if not os.path.isfile( CONST.BOOT_CONFIG_EOS_BAK ):
         self.log.errorAndExit( ERROR.RECOVER_TO_EOS_FAIL,
                                "Unable to find backup for recovering boot-config" )

      # Check EOS.swi existing
      eosPath = Utils.getEosSwiPathFromBootConfig( config=CONST.BOOT_CONFIG_EOS_BAK )
      if not eosPath:
         self.log.errorAndExit( ERROR.RECOVER_TO_EOS_FAIL,
                                "Unable to determine the EOS path to recover" )
      if not os.path.isfile( eosPath ):
         self.log.errorAndExit( ERROR.RECOVER_TO_EOS_FAIL,
                                "Unable to recover %s" % eosPath )

      # Remove sonic images installed
      dirs = Utils.getInstalledSonic( "/mnt/flash", single=False )
      for item in dirs:
         self.log.info( "Removing old sonic file %s", item )
         Utils.run( [ 'rm', '-rf', item ] )

      # Recover boot-config
      Utils.run( [ 'cp', CONST.BOOT_CONFIG_EOS_BAK, CONST.BOOT_CONFIG ] )

   @contextlib.contextmanager
   def recoverToEosOnFail( self ):
      try:
         yield
      except SystemExit as e:
         self.log.warning( 'Recovering to EOS for error %s' % e )
         self._recoverToEos()
         raise e
      except Exception as e:
         self.log.warning( 'Recovering to EOS for exception %s' % e )
         self._recoverToEos()
         raise e

   def install( self, dryRun ):
      self.log.info( 'Installing SONiC operating system' )
      with self.recoverToEosOnFail():
         self.opers[ OPERATION.INSTALL ]( self.swi, self.dest, dryRun )

   def reboot( self, dryRun ):
      self.log.info( 'Rebooting the platform' )
      self.opers[ OPERATION.REBOOT ]( dryRun )

   def kexec( self, dryRun ):
      with self.recoverToEosOnFail():
         self.log.info( 'Dumping EOS state for SONiC' )
         self.opers[ OPERATION.DUMP ]( self.dest, dryRun )

         if self.arpHelperIPs and self.hwSku:
            self.log.info( 'Running arp helper' )
            self.opers[ OPERATION.ARP_HELPER ]( self.dest, self.arpHelperIPs,
                                                self.arpHelperHttpPort,
                                                self.arpHelperHttpsPort,
                                                self.hwSku, dryRun )

      self.log.info( 'Stopping the running system' )
      eosPath = Utils.getEosSwiPathFromBootConfig( config=CONST.BOOT_CONFIG_EOS_BAK )
      if eosPath and os.path.isfile( eosPath ):
         Utils.run( [ 'rm', '-rf', eosPath ] )
         Utils.run( [ 'rm', '-rf', CONST.BOOT_CONFIG_EOS_BAK ] )

      self.opers[ OPERATION.SHUTDOWN ]( dryRun )
      self.log.info( 'Rebooting to SONiC by kexec' )
      self.opers[ OPERATION.KEXEC ]( self.dest, dryRun )

def parseArgs():
   parser = argparse.ArgumentParser( description="Tool to install and boot SONiC "
                                                 "from EOS." )
   group = parser.add_mutually_exclusive_group()
   group.add_argument( '-k', '--kexec', action='store_true',
                       help='kexec to SONiC' )
   group.add_argument( '-r', '--reboot', action='store_true',
                       help='reboot to SONiC' )
   parser.add_argument( '-i', '--install', action='store_true',
                        help='install SONiC' )
   parser.add_argument( '-a', '--arpHelperIPs',
                        help='enable arp helper with the specfied service '
                             'IPs (split by ,)' )
   parser.add_argument( '-p', '--arpHelperHttpPort',
                        default=CONST.ARP_HELPER_HTTP_PORT,
                        help='arp helper http port (optional, default 85)' )
   parser.add_argument( '-e', '--arpHelperHttpsPort',
                        default=CONST.ARP_HELPER_HTTPS_PORT,
                        help='arp helper https port (optional, default 448)' )
   # Provide default hwsku in case hwproxy not passing down the parameter
   parser.add_argument( '-w', '--hwSku',
                        default='Arista-unknown',
                        help='set hwSku used by arpHelper' )
   parser.add_argument( '--dryRun', action='store_true', help='dry run' )
   parser.add_argument( '-v', '--verbose', action='store_true', help='verbose' )
   parser.add_argument( '--eosVer', help='override the current EOS version' )
   parser.add_argument( '--sonicVer', help='override the SONiC swi version' )
   parser.add_argument( '--platform', help='override the platform' )
   parser.add_argument( '-s', '--swi',
                        help='path to SONiC image' )
   parser.add_argument( '-d', '--dest', default='/mnt/flash',
                        help='mount point for install destination' )
   parser.add_argument( '--skipNtp', action='store_true',
                        help='disable NTP clock sync check' )
   return parser.parse_args()

def main():
   args = parseArgs()

   # Verbose mode
   logger.setLevel( logging.DEBUG if args.verbose else logging.INFO )

   # Get log helpers
   log = Log( AREA.MAIN )

   # Check user
   if os.getuid() != 0:
      log.errorAndExit( ERROR.NOT_ROOT, 'The user must be root' )

   if CONST.TESTING:
      log.warning( 'This tool should be used only for the testing purpose' )

   # Check the existence of install destination from argument
   if not args.dest or not os.path.ismount( args.dest ):
      log.errorAndExit( ERROR.SONIC_MNT_PT_DNE,
                        'SONiC mount point from argument does not exist: %s',
                        args.dest )
   # Check both service ip and hwsku are provided for arp helper mode
   if args.arpHelperIPs and not args.hwSku:
      log.errorAndExit( ERROR.ARP_HELPER_NO_HWSKU_ARG,
                        'In ARP helper mode, hwSku must be provided by argument -w' )

   # Check NTP status
   if not args.skipNtp:
      status = Utils.runShowCmd( 'ntp status', toJson=False )
      if 'unsynchronised' in status or 'disabled' in status:
         log.errorAndExit( ERROR.NOT_NTP_SYNCED, 'Clock is not synced with NTP' )

   # Update the install destination for dry run
   if args.dryRun:
      fsType = Utils.getFsInfo( args.dest )[ 'type' ]
      destFile = os.path.join( args.dest, 'fast-reboot-dryrun' )
      destMount = '/mnt/fast-reboot-dryrun'
      log.info( 'For dry run, install destination is changed to: %s', destMount )
      if not os.path.isfile( destFile ) :
         log.info( 'Preparing file %s for dry run', destFile )
         minSpace = CONST.MIN_SPACE_EXT4 if fsType == 'ext4' else \
                    CONST.MIN_SPACE_VFAT
         Utils.run( [ 'dd', 'if=/dev/zero', 'of=%s' % destFile,
                      'bs=1k','count=%d' % minSpace ] )
         if fsType == 'ext4':
            Utils.run( [ 'mkfs.ext4', '-F', destFile ] )
         else:
            Utils.run( [ 'mkfs.%s' % fsType, destFile ] )
      log.info( 'For dry run, mounting destination file system %s', destMount )
      Utils.run( [ 'mkdir', '-p', destMount ] )
      Utils.run( [ 'mount', '-t', fsType, destFile, destMount ] )
      dest = destMount
   else:
      dest = args.dest

   try:
      # Check the existence of install destination from argument
      if not dest or not os.path.ismount( dest ):
         log.errorAndExit( ERROR.SONIC_MNT_PT_DNE,
                           'Failed in checking SONiC mount point: %s', dest )
      log.info( 'SONiC mount point is: %s', dest )

      # Check SONiC swi
      if args.install:
         swi = args.swi
      else:
         # Force to use the tiny swi, if SONiC has been installed
         swiPath = Utils.getInstalledSonic( dest )
         swi = os.path.join( swiPath, CONST.FILE_TINY_SWI )
      log.info( 'SONiC SWI used by the script is: %s', swi )
      if not swi or not os.path.isfile( swi ):
         log.errorAndExit( ERROR.SONIC_SWI_DNE,
                           'SWI for SONiC not existing: %s', swi )

      # Check versions and determine the implementation
      app = App( swi, dest, args.eosVer, args.sonicVer, args.platform )
      if args.arpHelperIPs:
         app.setArpHelper( args.arpHelperIPs, args.hwSku,
                           args.arpHelperHttpPort, args.arpHelperHttpsPort )

      # Execute the operations based on cmdline arguments
      if args.install:
         app.install( args.dryRun )
      if args.kexec:
         app.kexec( args.dryRun )
      if args.reboot:
         app.reboot( args.dryRun )
   finally:
      if args.dryRun:
         Utils.run( [ 'umount', destMount ] )
         log.info( 'WARNING: Mount point for dry run is unmounted, but the file '\
                   '%s needs to be deleted manually by design', destFile )

if __name__ == "__main__":
   main()
