#!/usr/bin/env python

import os
from os.path import realpath, dirname
import subprocess
import sys
import syslog
import json

def exec_cmd(cmd):
    p = subprocess.Popen(cmd, shell=True, executable='/bin/bash', stdout=subprocess.PIPE)
    output, errs = p.communicate()
    outs = output.decode("utf-8")
    if outs: print('exec_cmd stdout = '+outs)
    if errs: print('exec_cmd stderr = '+errs)

    return (p.returncode, outs)

def get_switch_subtype():
    command = "sonic-cfggen -d -v DEVICE_METADATA.localhost.subtype"
    err, outs = exec_cmd(command)

    if err != 0:
        return None

    switch_type = out.rstrip('\n')
    return switch_type

def migrate_port_state():
    port_config_path = '/etc/sonic/port_config.json'
    if not os.path.isfile(port_config_path):
        return

    switch_subtype = get_switch_subtype()

    # Skip apply port state when switch subtype is DualToR until NCM support generate port configuration for DualToR
    # ADO: 14100562
    if switch_subtype in ['DualToR']:
        os.remove(port_config_path)
        return

    try:
        # Load port_config.json
        with open(port_config_path) as f:
            port_config_input = json.load(f)
    except Exception:
        print("Bad format, failed to load as json: {}".format(port_config_path))
        return

    # Validate if the input is an array
    if not isinstance(port_config_input, list):
        print("Bad format, port_config is not an array: {}".format(port_config_path))
        return

    if len(port_config_input) == 0 or 'PORT' not in port_config_input[0]:
        print("Bad format, PORT table not exists: {}".format(port_config_path))
        return

    port_config = port_config_input[0]['PORT']

    # Ensure all ports are exist
    _, out = exec_cmd("show interfaces status | grep -oP 'Ethernet([0-9]+)'", )
    port_table = set(out.splitlines())
    for port_name in port_config.keys():
        if port_name not in port_table:
            print("Port {} is not defined in current device".format(port_name))
            return

    # Update port state
    for port_name in port_config.keys():
        if 'admin_status' not in port_config[port_name]:
            continue
        exec_cmd('config interface {} {}'.format(
            'startup' if port_config[port_name]['admin_status'] == 'up' else 'shutdown',
            port_name))
    return

def config_save():
    exec_cmd("sudo config save -y &>/dev/null")

def main():
    migrate_port_state()
    config_save()

if __name__ == "__main__":
    main()
