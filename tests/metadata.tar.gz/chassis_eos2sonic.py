#!/usr/bin/env python
# Copyright (c) 2023 Arista Networks, Inc.  All rights reserved.
# Arista Networks, Inc. Confidential and Proprietary.


"""
Helper script to convert a chassis running EOS to SONiC

This scripts uses artifacts such as SWI, minigraph.xml and firmwares.
It populates the filesystem for the conversion from EOS to SONiC to happen
after a reboot.

Using the `install-remote` command, this script can download artifacts from various
urls and then populate an intermediate `provision-artifacts` folder.
The urls can either be remote (http/https) or local paths.

The `install-local` command of this script consumes the content of the
`provision-artifacts` folder to populate the flash correctly for a SONiC
provisioning.

The `install-local` command expects the following filesystem layout in EOS:
 - /mnt/flash/provision-artifacts
   - sonic.swi
   - minigraph-sup.xml
   - minigraph-lcX.xml
   - arista-fwpkg-$flavor-good-$product.tar.gz
One minigraph per linecard is necessary, replacing the X by the linecard slotid.
One arista-fwpkg per linecard model is necessary, replacing flavor and product
accordingly.
"""

import argparse
import getpass
import io
import json
import logging
import os
import re
import shutil
import subprocess
import sys
import tarfile

import requests

__version__ = "1.0.0"

ERR_NOT_ROOT_USER = 1
ERR_FAILED_OS_DETECTION = 2
ERR_SUPERVISOR_NOT_SUPPORTED = 3
ERR_SUPERVISOR_INVALID_SLOT = 4
ERR_PEER_SUPERVISOR_INSERTED = 5
ERR_ACTION_NOT_SUPPORTED = 6
ERR_PROVISION_FIRMWARE_NOT_FOUND = 7
ERR_SWI_MISSING = 8
ERR_SUPERVISOR_MINIGRAPH_MISSING = 9
ERR_LINECARD_MINIGRAPH_MISSING = 10
ERR_FAILED_BOOTING_LINECARD = 11
ERR_DOWNLOAD_ARTIFACT_FAILED = 12
ERR_DUPLICATE_ARTIFACT = 13

log = logging.getLogger(__name__)


class ProvisioningError(Exception):
    def __init__(self, err):
        self.err = err

    @property
    def msg(self):
        return {
            ERR_NOT_ROOT_USER: 'User needs to be root',
            ERR_FAILED_OS_DETECTION: 'Failed to detect running operating system',
            ERR_SUPERVISOR_NOT_SUPPORTED: 'The supervisor model is not supported',
            ERR_SUPERVISOR_INVALID_SLOT: 'The supervisor is not inserted in slot 1',
            ERR_PEER_SUPERVISOR_INSERTED: 'Peer supervisor is inserted, not supported',
            ERR_ACTION_NOT_SUPPORTED: 'Unknown action to perform',
            ERR_PROVISION_FIRMWARE_NOT_FOUND: 'Firmware package artifact not found',
            ERR_SWI_MISSING: 'SONiC SWI artifact not found',
            ERR_SUPERVISOR_MINIGRAPH_MISSING: 'Supervisor minigraph not found',
            ERR_LINECARD_MINIGRAPH_MISSING: 'Linecard minigraph not found',
            ERR_FAILED_BOOTING_LINECARD: 'Failed to boot linecard',
            ERR_DOWNLOAD_ARTIFACT_FAILED: 'Failed to download artifact',
            ERR_DUPLICATE_ARTIFACT: 'Duplicated artifact found',
        }.get(self.err, 'Unknown')


def parseKvLines(lines, separator=': '):
    data = {}
    for line in lines:
        line = line.rstrip()
        if not line:
            continue
        items = line.split(separator, 1)
        if len(items) != 2:
            log.warning('unparseable line: %s', line)
            continue
        key, value = items
        data[key] = value
    return data


def parseKvFile(path, separator=': '):
    with io.open(path, 'r', encoding='utf8') as f:
        return parseKvLines(f.readlines(), separator=separator)


def readFileContents(path, conv=lambda x: x):
    with io.open(path, 'r', encoding='utf8') as f:
        return conv(f.read())


def downloadHttpFile(url, dest, chunkSize=1024 * 1024):
    with requests.get(url, stream=True) as r:
        r.raise_for_status()
        with open(dest, 'wb') as f:
            for chunk in r.iter_content(chunk_size=chunkSize):
                f.write(chunk)
    return dest


def maybeMakeDirs(path):
    # In python2 exist_ok= is not available for os.makedirs
    if not os.path.isdir(path):
        os.makedirs(path)


def isRootUser():
    return getpass.getuser() == 'root'


class OperatingSystem(object):

    FLASH_PATH = None
    ACTIONS = []

    def __str__(self):
        return self.__class__.__name__

    def getEeprom(self):
        raise NotImplementedError

    def getSlotId(self):
        raise NotImplementedError

    def isPeerInserted(self):
        raise NotImplementedError

    def getInsertedLinecards(self):
        raise NotImplementedError

    def getLinecardEeprom(self, slotId):
        raise NotImplementedError

    def provision(self, sup):
        raise NotImplementedError

    def bootLinecard(self, slotId, powercycle=False):
        raise NotImplementedError

    def isActionSupported(self, action):
        return action in self.ACTIONS

    def filterLinecards(self, sup, linecards=None, powercycle=False):
        pass

    @staticmethod
    def detect():
        try:
            if 'EOS' in readFileContents('/etc/system-release'):
                return Eos()
        except Exception:  # pylint: disable=broad-except
            pass

        try:
            if os.path.exists('/etc/sonic/sonic_version.yml'):
                return Sonic()
        except Exception:  # pylint: disable=broad-except
            pass

        return None


class Eos(OperatingSystem):

    FLASH_PATH = '/mnt/flash'
    ACTIONS = [
        'install-remote',
        'install-local',
    ]

    def getEeprom(self):
        return parseKvFile('/etc/prefdl')

    def getSlotId(self):
        # slotIdPath = '/etc/cellid'
        slotIdPath = '/sys/arista/election_manager/local_slot_id'
        return readFileContents(slotIdPath, conv=int)

    def isPeerInserted(self):
        peerStatusPath = '/sys/arista/election_manager/peer_state_status'
        peerStatus = readFileContents(peerStatusPath)
        return peerStatus not in ['notInserted']

    def getInsertedLinecards(self):
        cmd = ['modulargenprefdl']
        res = subprocess.check_output(cmd, universal_newlines=True)
        for line in res.splitlines():
            if line.startswith('Linecard'):
                yield int(line[8: line.index(':')])

    def getLinecardEeprom(self, slotId):
        cmd = ['modulargenprefdl', '--linecard', str(slotId)]
        res = subprocess.check_output(cmd, universal_newlines=True)
        return parseKvLines(res.splitlines())

    def provision(self, sup):
        """In EOS we provision the supervisor and the linecards all at once"""
        sup.loadArtifacts()
        sup.provision()
        sup.installSonic()

    def bootLinecard(self, slotId, powercycle=False):
        raise NotImplementedError


class Sonic(OperatingSystem):

    FLASH_PATH = '/host'
    ACTIONS = [
        'install-remote',
        'install-local',
    ]

    def __init__(self):
        import arista.platforms  # pylint: disable=import-error

        self.sup = arista.core.platform.getPlatform()
        self.chassis = self.sup.getChassis()
        self.chassis.loadAll()

    def getEeprom(self):
        return self.sup.getEeprom()

    def getSlotId(self):
        return self.sup.getSlotId()

    def isPeerInserted(self):
        return False  # TODO: internal API missing

    def getInsertedLinecards(self):
        for lc in self.chassis.iterLinecards():
            if lc.getPresence():
                yield lc.getSlotId()

    def filterLinecards(self, sup, linecards=None, powercycle=False):
        selected = []
        for lc in sup.linecards:
            if linecards and lc.slotId not in linecards:
                log.info('ignoring linecard %s because it is not selected', lc)
                continue
            if not powercycle and self._getLinecardSlot(lc.slotId).card.poweredOn():
                log.info('ignoring linecard %s because it is running', lc)
                continue
            selected.append(lc)
        sup.linecards = selected

    def _getLinecardSlot(self, slotId):
        return self.sup.linecardSlots[slotId - 3]

    def getLinecardEeprom(self, slotId):
        return self._getLinecardSlot(slotId).getEeprom()

    def provision(self, sup):
        """In SONiC we provision only the linecards that are offline"""
        sup.loadLinecardArtifacts()
        sup.provisionLinecards()
        for linecard in sup.linecards:
            self._getLinecardSlot(linecard.slotId).card.eeprom.clean()
        sup.bootLinecardsInProvisionMode()

    def bootLinecard(self, slotId, powercycle=False):
        cmd = [
            'arista', 'linecard', '-i', str(slotId), 'setup',
            '--on', '--lcpu', '--provision', 'static',
            # '-v', '.*/IO'
        ]
        if powercycle:
            cmd.append('--powerCycleIfOn')
        try:
            subprocess.check_call(cmd)
        except subprocess.CalledProcessError:
            log.exception(
                'something went wrong while booting linecard %s', slotId)
            raise ProvisioningError(ERR_FAILED_BOOTING_LINECARD)


class Sku(object):
    def __init__(self, sku, dpe=False):
        self.sku = sku
        self.dpe = dpe


class LinecardProvisioning(object):

    SUPPORTED_SKUS = {s.sku: s for s in [
        Sku('7800R3-48CQ2-LC'),
        Sku('7800R3-48CQM2-LC', dpe=True),
        Sku('7800R3A-36DM2-LC', dpe=True),
        Sku('7800R3AK-36DM2-LC', dpe=True),
    ]}

    def __init__(self, sup, lcid, powercycle=False):
        self.sup = sup
        self.slotId = lcid
        self.powercycle = powercycle

        self.eeprom = None
        self.identify()

    def __str__(self):
        return 'Linecard(%d, %s)' % (self.slotId, self.sku)

    @property
    def sid(self):
        return self.eeprom['SID']

    @property
    def sku(self):
        return self.eeprom['SKU']

    @property
    def supported(self):
        return self.sku in self.SUPPORTED_SKUS

    def getEeprom(self):
        return self.sup.osys.getLinecardEeprom(self.slotId)

    def identify(self):
        log.info('identifying linecard %d', self.slotId)
        self.eeprom = self.getEeprom()
        log.info('found %s in slot %d', self.sku, self.slotId)

    def checkCompatibility(self):
        # TODO: check firmware
        # TODO: check Aboot version?
        log.warning('no checks done for %s in slot %s', self.sku, self.slotId)
        return 0

    def provisionFirmware(self):
        info = self.SUPPORTED_SKUS[self.sku]
        flavor = 'dpe' if info.dpe else 'regular'
        fwpkgName = 'arista-fwpkg-%s-good-%s.tar.gz' % (flavor, self.sku)
        fwpkg = self.sup.artifacts.get(fwpkgName)

        if not os.path.isfile(fwpkg):
            log.error('Firmware package %s could not be found', fwpkg)
            raise ProvisioningError(ERR_PROVISION_FIRMWARE_NOT_FOUND)

        lcpath = os.path.join(self.sup.PROVISION_PATH, str(self.slotId))
        fwdir = os.path.join(lcpath, 'firmware-update')
        maybeMakeDirs(fwdir)

        firmwares = []

        def _processPlatformComponents(data):
            components = list(data['chassis'].values())[0]['component']
            manifest = {}
            for name, info in components.items():
                if not info:
                    continue
                manifest[name] = {
                    'firmware': '/host/firmware-update/%s' % info['firmware'],
                    'status': 'pending',
                }
                firmwares.append(info['firmware'])

            manifestPath = os.path.join(fwdir, 'manifest.json')
            with open(manifestPath, 'w') as f:
                json.dump(manifest, f, indent=4, separators=(',', ': '))

        with tarfile.open(fwpkg, 'r:*') as t:
            firmwares = []
            for member in t.getmembers():
                if member.name.endswith('platform_components.json'):
                    data = json.load(t.extractfile(member))
                    _processPlatformComponents(data)
            for member in t.getmembers():
                if member.name.endswith(tuple(firmwares)):
                    member.path = os.path.basename(member.path)
                    t.extract(member, path=fwdir)

    def provision(self):
        log.info('provisioning linecard %s (%s)', self.slotId, self.sku)
        lcpath = os.path.join(self.sup.PROVISION_PATH, str(self.slotId))
        maybeMakeDirs(lcpath)

        log.debug('%s: hardlink sonic.swi', self)
        swiPath = self.sup.artifacts.get('sonic.swi')
        swiDest = os.path.join(lcpath, 'sonic.swi')

        if os.path.exists(swiDest):
            os.remove(swiDest)

        # NOTE: to avoid maintaining multiple copies of the same SWI use hardlinks
        # Because the initial SWI is on /tmp/ it cannot be linked since it's on a
        # different filesystem, so copy at least one SWI to the flash.
        if self.sup.firstFlashSwiPath is None:
            shutil.copyfile(swiPath, swiDest)
            self.sup.firstFlashSwiPath = swiDest
        else:
            os.link(self.sup.firstFlashSwiPath, swiDest)

        log.debug('%s: copying minigraph.xml', self)
        minigraphPath = self.sup.artifacts.get(
            'minigraph-lc%d.xml' % self.slotId)
        shutil.copy(minigraphPath, os.path.join(lcpath, 'minigraph.xml'))

        log.debug('%s: generating boot-config', self)
        bootPath = os.path.join(lcpath, 'boot-config')
        with io.open(bootPath, 'w', encoding='utf8') as f:
            f.write(u'SWI=flash:sonic.swi\n')

        log.debug('%s: creating .provision', self)
        with io.open(os.path.join(lcpath, '.provision'), 'wb'):
            pass

        # NOTE: necessary otherwise sonic install will prune the firmwares
        log.debug('%s: creating do-not-clean', self)
        with io.open(os.path.join(lcpath, 'do-not-clean'), 'wb'):
            pass

        return self.provisionFirmware()


class SupProvisioning(object):

    SUPPORTED_SKUS = ['DCS-7800-SUP1A']

    def __init__(self, osys):
        self.osys = osys
        self.linecards = []
        self.eeprom = None
        self.slotId = None
        self.firstFlashSwiPath = None
        self.artifacts = ArtifactManager(self)
        self.identify()

    def __str__(self):
        return 'Supervisor(%s)' % self.sku

    @property
    def sku(self):
        return self.eeprom['SKU']

    @property
    def FLASH_PATH(self):
        return self.osys.FLASH_PATH

    @property
    def ARTIFACT_PATH(self):
        return os.path.join('/tmp', 'provision-artifacts')

    @property
    def PROVISION_PATH(self):
        return os.path.join(self.FLASH_PATH, 'provision')

    def identify(self):
        log.info('identifying current supervisor')
        self.eeprom = self.osys.getEeprom()
        self.slotId = self.osys.getSlotId()
        log.info('found %s in slot %d', self.sku, self.slotId)

    def checkCompatibility(self):
        log.info('checking supervisor compatibility')

        sku = self.eeprom.get('SKU')
        if sku not in self.SUPPORTED_SKUS:
            log.error('This supervisor %s in not supported list: %s', sku,
                      self.SUPPORTED_SKUS)
            raise ProvisioningError(ERR_SUPERVISOR_NOT_SUPPORTED)

        if self.slotId != 1:
            log.error('SONiC only supports running on supervisor slot 1')
            raise ProvisioningError(ERR_SUPERVISOR_INVALID_SLOT)

        if self.osys.isPeerInserted():
            log.error('SONiC is not supported in dual sup configuration')
            raise ProvisioningError(ERR_PEER_SUPERVISOR_INSERTED)

    def detectLinecards(self, powercycle=False):
        log.info('detecting inserted linecards for provisioning')
        for slotId in self.osys.getInsertedLinecards():
            lc = LinecardProvisioning(self, slotId, powercycle=powercycle)
            if not lc.supported:
                log.warning('%s is not supported', lc)
                continue
            log.debug('found %s', lc)
            self.linecards.append(lc)
            yield lc

    def downloadFile(self, name, uri):
        maybeMakeDirs(self.ARTIFACT_PATH)
        path = os.path.join(self.ARTIFACT_PATH, name)
        if not uri.startswith('http'):
            log.info('Copying local file %s from %s', path, uri)
            shutil.copy(uri, path)
            return
        log.info('Downloading file %s from %s', path, uri)
        try:
            downloadHttpFile(uri, path)
        except requests.RequestException:
            log.exception('Failed to download %s', uri)
            raise ProvisioningError(ERR_DOWNLOAD_ARTIFACT_FAILED)

    def loadLinecardArtifacts(self):
        self.artifacts.loadArtifacts()
        self.artifacts.expect('sonic.swi', ERR_SWI_MISSING)
        for lc in self.linecards:
            name = 'minigraph-lc%d.xml' % lc.slotId
            self.artifacts.expect(name, ERR_LINECARD_MINIGRAPH_MISSING)

    def loadArtifacts(self):
        log.info('loading artifact folder %s', self.ARTIFACT_PATH)
        self.artifacts.loadArtifacts()
        self.artifacts.expect('sonic.swi', ERR_SWI_MISSING)
        self.artifacts.expect('minigraph-sup.xml',
                              ERR_SUPERVISOR_MINIGRAPH_MISSING)
        self.loadLinecardArtifacts()

    def provisionLinecards(self):
        for lc in self.linecards:
            lc.provision()

    def provision(self):
        log.info('populate provisioning folder %s', self.PROVISION_PATH)
        maybeMakeDirs(self.PROVISION_PATH)

        log.debug('%s: copying minigraph', self)
        srcPath = self.artifacts.get('minigraph-sup.xml')
        destPath = os.path.join(self.FLASH_PATH, 'minigraph.xml')
        shutil.copy(srcPath, destPath)

        return self.provisionLinecards()

    def installSonic(self):
        log.info('installing SONiC on supervisor')
        path = self.artifacts.get('sonic.swi')
        cmd = 'unzip -qop %s boot0 | ' \
              'install=true swipath=%s target_path=/mnt/flash bash' % \
              (path, path)
        subprocess.check_call(cmd, cwd='/tmp', shell=True)

    def bootLinecardsInProvisionMode(self):
        log.info('booting linecards in provision mode')
        for lc in self.linecards:
            log.info('booting %s', lc)
            self.osys.bootLinecard(lc.slotId, powercycle=lc.powercycle)


class ArtifactManager(object):
    def __init__(self, sup):
        self.sup = sup
        self.artifacts = {}

    def expect(self, name, err):
        if name not in self.artifacts:
            raise ProvisioningError(err)

    def get(self, name):
        return self.artifacts[name]

    def maybeAddArtifact(self, name, regex, entry, group=None):
        m = regex.match(entry)
        if m is None:
            return False

        name = name or entry
        if group:
            name = name % int(m.group(group))

        if name in self.artifacts:
            raise ProvisioningError(ERR_DUPLICATE_ARTIFACT)

        self.artifacts[name] = os.path.join(self.sup.ARTIFACT_PATH, entry)
        return True

    def loadArtifacts(self):
        if self.artifacts:
            return

        swiRe = re.compile(r'.*\.swi')
        supMinigraphRe = re.compile(r'.*(sup|SUP)([0-9]+)?\.xml')
        lcMinigraphRe = re.compile(r'.*(lc|LC)([0-9]+).xml')
        fwPkgRe = re.compile(r'arista-fwpkg-.*\.tar\.gz')
        for entry in os.listdir(self.sup.ARTIFACT_PATH):
            if self.maybeAddArtifact('sonic.swi', swiRe, entry):
                continue
            if self.maybeAddArtifact('minigraph-sup.xml', supMinigraphRe, entry):
                continue
            if self.maybeAddArtifact('minigraph-lc%d.xml', lcMinigraphRe, entry, 2):
                continue
            if self.maybeAddArtifact(None, fwPkgRe, entry):
                continue
            log.warning('Unknown artifact %s', entry)


def downloadArtifacts(sup, args):
    if args.swi:
        sup.downloadFile('sonic.swi', args.swi)
    if args.minigraph:
        sup.downloadFile('minigraph-sup.xml', args.minigraph)
    for slotId, minigraph in args.linecard or []:
        sup.downloadFile('minigraph-lc%s.xml' % slotId, minigraph)
    for fwpkg in args.fwpkg or []:
        sup.downloadFile(os.path.basename(fwpkg), fwpkg)


def parseArgs(args):
    parser = argparse.ArgumentParser(
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument('-d', '--dry-run', action='store_true')
    parser.add_argument('-v', '--verbose', action='store_true',
                        help="Increase script verbosity")

    subs = parser.add_subparsers(dest='action')

    sub = subs.add_parser('install-remote',
                          help="Install SONiC from remote artifacts")
    sub.add_argument('-s', '--swi', default=None,
                     help="SONiC SWI to install on supervisor and linecards")
    sub.add_argument('-m', '--minigraph', default=None,
                     help="Supervisor minigraph.xml to use")
    sub.add_argument('-l', '--linecard', nargs=2, action='append', default=[],
                     help="Linecard slotId and associated minigraph.xml to use")
    sub.add_argument('-f', '--fwpkg', action='append', default=[],
                     help="Firmware packages to download")
    sub.add_argument('-c', '--powercycle', action='store_true',
                     help="Powercycle the linecard if it's on (only in SONiC)")

    sub = subs.add_parser('install-local',
                          help="Install SONiC from pre-populated artifacts")
    sub.add_argument('-l', '--linecard', type=int, action='append',
                     help="Linecard to provision (only in SONiC)")
    sub.add_argument('-c', '--powercycle', action='store_true',
                     help="Powercycle the linecard if it's on (only in SONiC)")

    return parser.parse_args(args)


def main(args):
    args = parseArgs(args)

    level = logging.DEBUG if args.verbose else logging.INFO
    fmt = '%(levelname)s: %(message)s'
    logging.basicConfig(level=level, format=fmt)

    if not isRootUser():
        log.error('This script must run as root')
        return ERR_NOT_ROOT_USER

    osys = OperatingSystem.detect()
    if osys is None:
        log.error('This script only runs on EOS or SONiC')
        return ERR_FAILED_OS_DETECTION

    if not osys.isActionSupported(args.action):
        log.error('Action %s not supported on %s', args.action, osys)
        return ERR_ACTION_NOT_SUPPORTED

    log.info('starting chassis provisioning script')

    sup = SupProvisioning(osys)
    try:
        sup.checkCompatibility()
        for lc in sup.detectLinecards(args.powercycle):
            lc.checkCompatibility()
    except ProvisioningError as e:
        log.error('%s', e.msg)
        return e.err

    if not sup.linecards:
        log.info('no linecard to provision')
        return 0

    try:
        if args.action == 'install-remote':
            downloadArtifacts(sup, args)
            args.linecard = [lcId for lcId, _ in args.linecard]

        if args.action in ['install-remote', 'install-local']:
            osys.filterLinecards(sup, args.linecard,
                                 powercycle=args.powercycle)
            if not sup.linecards:
                log.warning('no linecard to provision')
                return 0
            osys.provision(sup)
    except ProvisioningError as e:
        log.error('%s', e.msg)
        return e.err

    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
