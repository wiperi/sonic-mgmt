# How to use
Download the file `get_fib_routes.lua`, `fib_dump.py` and `fib_routes_dump.sh` from repo Networking-Metadata under the path `src/data/Network/SONiC/scripts`. \
And then, execute command `./fib_routes_dump.sh -t 4` or `./fib_routes_dump.sh -t 6` to get ipv4 or ipv6 routes. \
Also, you can get one specific prefix using parameter `-p` like `./fib_routes_dump.sh -p 192.189.160.128/25`.

# Output
You can see the file named like `fib_routes.2023.01.18.02:23:17(timestamp)` under current path. \
Below is the sample output:
```
sonic:~$ ./fib_routes_dump.sh
fib_routes.2023.02.03.07:58:34

sonic:~$ cat fib_routes.2023.02.03.07:58:34
  No.  Vrf    Route               Nexthop                                  Ifname
-----  -----  ------------------  ---------------------------------------  -----------------------------------------------------------
   1          192.168.104.0/25    10.0.0.59,10.0.0.57,10.0.0.61,10.0.0.63  PortChannel102,PortChannel101,PortChannel103,PortChannel104
   2          192.168.104.128/25  10.0.0.59,10.0.0.57,10.0.0.61,10.0.0.63  PortChannel102,PortChannel101,PortChannel103,PortChannel104
   3          192.168.112.0/25    10.0.0.59,10.0.0.57,10.0.0.61,10.0.0.63  PortChannel102,PortChannel101,PortChannel103,PortChannel104
   4          192.168.112.128/25  10.0.0.59,10.0.0.57,10.0.0.61,10.0.0.63  PortChannel102,PortChannel101,PortChannel103,PortChannel104
   5          192.168.120.0/25    10.0.0.59,10.0.0.57,10.0.0.61,10.0.0.63  PortChannel102,PortChannel101,PortChannel103,PortChannel104
   ...
   6411         193.9.96.128/25     10.0.0.59,10.0.0.57,10.0.0.61,10.0.0.63  PortChannel102,PortChannel101,PortChannel103,PortChannel104
   6412         240.127.1.0/24      -                                        docker0
Total number of entries 6412
```

# Return code
If the script executes successfully or show help, you will get the return code 0.

But if something wrong happens, you will get the return code and exit
+ 10: container database exited
+ 20: connect to redis failed
+ 30: got empty value from redis
+ 40: specify the parameter `-p` but not the correct ip perfix format
+ 50: python import error
+ 255: when exectuing python script, something unexpected happens
