#!/usr/bin/env bash
for ns in $(ip netns | awk '{print $1;}')
do
    count=0
    intfs=""
    intfs=$(show int status -n "$ns" | grep Ethernet | awk '{print $1;}')
    count=$(echo "$intfs" | grep -c Ethernet)
    if [[ $count -gt 0 ]]; then
        for intf in $intfs
        do
            echo "Shutting down $intf on asic $ns"
            sudo config interface -n "$ns" shutdown "$intf"
            sleep 2
        done
    fi
done