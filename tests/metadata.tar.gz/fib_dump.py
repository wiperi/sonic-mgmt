import argparse
import sys
import re
import os
import six

import ipaddress
import subprocess
import time

from tabulate import tabulate

RC_DB_EXITED = 10
RC_DB_CONN_FAILED = 20
RC_EMPTY_DATA = 30
RC_INVALID_PREFIX_FORMAT = 40
RC_OTHER = 255


def parser_ip(ip):
    if six.PY3:
        return ipaddress.ip_address(ip)
    else:
        return ipaddress.ip_address(unicode(ip))


class FibBase(object):
    """
       Base class for v4 and v6 FIB entries.
    """
    HEADERS = ["No.", "Vrf", "Route", "Nexthop", "Ifname"]

    def run_cmd(self, cmd):
        out = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
        stdout, stderr = out.communicate()
        return out.returncode, stdout, stderr

    def fetch_fib_data(self):
        """
            Fetch FIB entries from APPL_DB
        """
        self.run_cmd("docker cp get_fib_routes.lua database:/root")

        _, fib_data, _ = self.run_cmd(
            "docker exec database redis-cli --eval /root/get_fib_routes.lua \"ROUTE_TABLE:*\"")
        fib_data = fib_data.decode("utf-8").strip().split('\n')

        if "Error response from daemon" in fib_data[0]:
            print("Container database exited.")
            sys.exit(RC_DB_EXITED)

        if "Connection refused" in fib_data[0]:
            print("Connect to redis failed.")
            sys.exit(RC_DB_CONN_FAILED)

        if "permission denied" in fib_data[0]:
            print("Permission denied while trying to connect to the Docker daemon socket, please use sudo to run the script.")
            sys.exit(RC_DB_CONN_FAILED)

        if fib_data[0] == "3":
            print("Got empty value from redis.")
            sys.exit(RC_EMPTY_DATA)

        return fib_data

    def process_fib_data(self):
        """
            Process FIB entries from APPL_DB
        """
        fib_data = self.fetch_fib_data()
        fib_entry_dict = {}

        pre_index = 0
        for i in range(0, len(fib_data)):
            single_fib_entry_dict = {}
            if fib_data[i] == "*EOL*":
                fib_entry = fib_data[pre_index:i]
                pre_index = i + 1

                prefix = fib_entry[0]
                fib_entry.pop(0)

                for j in range(0, len(fib_entry), 2):
                    single_fib_entry_dict.update({fib_entry[j]: fib_entry[j+1]})
                fib_entry_dict.update({prefix:single_fib_entry_dict})
        return fib_entry_dict

    def display(self, version, arg_prefix):
        """
            Display FIB entries
        """
        fib_entry_dict = self.process_fib_data()
        output = []
        fdb_index = 1
        for key,value in fib_entry_dict.items():
            prefix = key
            if 'VRF' in key:
                vrf = re.match(r"VRF-(.*)", key.split(":")[0]).group(1)
                prefix = key.split(":")[1]
            else:
                vrf = ""
            ip = parser_ip(prefix.split("/")[0])


            if arg_prefix is not None:
                if key == arg_prefix:
                    output.append([fdb_index, vrf, prefix, value["nexthop"], value["ifname"]])
                    fdb_index += 1
                    break
                else:
                    continue
            else:
                if ip.version == 4 and version == "-4":
                    output.append([fdb_index, vrf, prefix, value["nexthop"], value["ifname"]])
                    fdb_index += 1
                elif ip.version == 6 and version == "-6":
                    output.append([fdb_index, vrf, prefix, value["nexthop"], value["ifname"]])
                    fdb_index += 1

        timestamp = time.strftime("%Y.%m.%d.%H:%M:%S", time.gmtime())
        fib_file_name = "fib_routes.{}".format(timestamp)
        fib_file_pattern = r"fib_routes.\d{4}.\d{2}.\d{2}.\d{2}:\d{2}:\d{2}"

        fib_files = []
        path = os.getcwd()
        for file in os.listdir(path):
            if re.search(fib_file_pattern, file):
                fib_files.append(file)

        fib_files.sort()

        for file in fib_files[0:-1]:
            os.system("rm -rf {}".format(file))

        with open(fib_file_name, "w") as file:
            file.write(tabulate(output, self.HEADERS))
            file.write("\nTotal number of entries {0}\n".format(len(output)))

        print(fib_file_name)
        return fib_file_name


def check_valid_ip(ip):
    try:
        parser_ip(ip.strip())
        return True
    except Exception as e:
        return False


def main():
    parser = argparse.ArgumentParser(description='Show dataplane/FIB entries',
                                     formatter_class=argparse.RawTextHelpFormatter)
    group = parser.add_mutually_exclusive_group()
    group.add_argument('-p', '--prefix', type=str,
                       help='dataplane/FIB route for a specific prefix', default=None)
    group.add_argument('v', help='IP Version -4 or -6', nargs="?", default="-4", choices=["-4", "-6"])

    args = parser.parse_args()

    if args.prefix is not None and not check_valid_ip(args.prefix.split("/")[0]):
        print("Invalid ip format")
        sys.exit(RC_INVALID_PREFIX_FORMAT)

    try:
        fib = FibBase()
        fib.display(args.v, args.prefix)
    except Exception as e:
        print(str(e))
        sys.exit(RC_OTHER)


if __name__ == "__main__":
    main()
