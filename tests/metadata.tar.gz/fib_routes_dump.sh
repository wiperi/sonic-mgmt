#!/bin/bash

# USAGE="
#   Usage: ./fib_routes_dump.sh [-h] [-t 4|6] [-p <prefix>]
#   Get dataplane/FIB entries
#   -h -?           : print help
#   -t <ip type>    : specify ip address type:4|6
#   -p <prefix>     : specify ip prefix
# "

show_help()
{
    echo "Usage ${SCRIPT} [options]"
    echo "    Get dataplane/FIB entries"
    echo "    -h -?           : get this help"
    echo "    -t <ip type>    : specify ip address type:4|6"
    echo "    -p <prefix>     : specify ip prefix"
    exit 255
}

execute_fib_cmd()
{
    python_arg=$*

    cmd=`python -c 'import tabulate' 2>&1`
    if [ "$cmd" != "" ] ;then
        python3 fib_dump.py $python_arg
    else
        python fib_dump.py $python_arg

    fi
}

display_fib_routes()
{
    if [ -z "$1" ];then
        execute_fib_cmd
    elif [ -z `echo $1 | egrep "^[0-9]+$"` ];then
        ip_prefix="-p "$1
        execute_fib_cmd $ip_prefix
    else
        ip_type="-"$1
        execute_fib_cmd $ip_type
    fi
}

while getopts "h?t:p:" opt;do
    case ${opt} in
        h|\? )
            show_help
            ;;
        t )
            ip_type=${OPTARG}
            ;;
        p )
            ip_prefix=${OPTARG}
            ;;
    esac
done

display_fib_routes ${ip_type} ${ip_prefix}
